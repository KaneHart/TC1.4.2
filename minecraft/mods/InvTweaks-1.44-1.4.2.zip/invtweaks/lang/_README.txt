|==============================================================|
| INVENTORY TWEAKS Mod - By Jimeo Wan (jimeo.wan at gmail.com) |
| Translations readme                                          |
|==============================================================|

* Want to contibute?

Awesome, thank you in advance! Now please don't edit these files directly,
everything is done through the Crowdin website (exactly like Minecraft itself):

http://crowdin.net/project/invtweaks/