Fihgu's mods
Version: 2.0.0

How to Install:

You need to install "Minecraft Forge 6.0.1.341" BEFORE installing this mod.
fihgu's Core mod need to be installed into your minecraft_server.jar or minecraft.jar.
(open the jar file with winrar , then drop all files inside "fihgu's Core Mod(2.0.0).zip" into the jar.)
Any other mod's zip file you downloaded from fihgu needs go to mods folder under your minecraft directory.

If you are running this mod on a server, then only server need this mod.
Client only need have forge installed.

If you are planning to use it on a LAN server, install it to client with the same way as if it's a server.
also, players who's joining your game doesn't need this mod, they only need minecraft forge.


==============================================================================================

For bug collecting:
fihgu's skype id: fanghan.hu

please add fihgu on skype and report any bug you found in the game.
suggestions are also welcomed.

==============================================================================================

If you want fihgu to develop a mod for you, or you need help on any java related projects,
and you are willing to pay an acceptable price:

please also contact fihgu with skype.