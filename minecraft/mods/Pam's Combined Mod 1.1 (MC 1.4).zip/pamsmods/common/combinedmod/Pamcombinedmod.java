package pamsmods.common.combinedmod;

import java.lang.reflect.Method;
import java.util.logging.Level;

import net.minecraftforge.common.Configuration;
import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.Init;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.Mod.PostInit;
import cpw.mods.fml.common.Mod.PreInit;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.IGuiHandler;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;

import net.minecraftforge.common.EnumHelper;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.oredict.ShapedOreRecipe;
import net.minecraftforge.oredict.ShapelessOreRecipe;
import net.minecraft.src.BlockStairs;
import net.minecraft.src.CraftingManager;
import net.minecraft.src.CreativeTabs;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EnumArmorMaterial;
import net.minecraft.src.EnumToolMaterial;
import net.minecraft.src.MLProp;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Block;
import net.minecraft.src.Material;
import net.minecraft.src.ModLoader;
import net.minecraft.src.World;
import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.IChunkProvider;
import cpw.mods.fml.common.IWorldGenerator;
import net.minecraft.src.WorldGenerator;

import java.util.Random;

import pamsmods.common.CommonProxyPamcombinedmod;
import pamsmods.common.ItemPamSimpleCropSeeds;
import pamsmods.common.Pamsimplehc;

@Mod(modid = "PamCombinedMod", name = "Pam's Combined Mod", version = "1.0")
@NetworkMod(clientSideRequired = true, serverSideRequired = false)


public class Pamcombinedmod implements IGuiHandler // ADDED
{
	@SidedProxy(clientSide = "pamsmods.client.ClientProxyPamcombinedmod", serverSide = "pamsmods.common.CommonProxyPamcombinedmod")
	public static CommonProxyPamcombinedmod proxy;
	
    public static int flowerID = 1250;
    public static int desertplantID = 1251;
    public static int temperateplantID = 1252;
    public static int fruitID = 1253;
    public static int warmfruitID = 1254;
    public static int bushID = 1255;
    public static int warmbushID = 1256;
    public static int coldbushID = 1257;
    public static int mineralID = 1258;
    public static int oreID = 1259;
    public static int gemID = 1260;
    public static int coloredsmoothstoneID = 1261;
    public static int saplingID = 1262;
    public static int warmsaplingID = 1263;
    public static int cropbaseID = 1264;
    
    public static int coloredplankID = 1350;
    public static int coloredwoodfenceID = 1351;
    public static int coloredwoodstairswhiteID = 1352;
    public static int coloredwoodstairsorangeID = 1353;
    public static int coloredwoodstairsmagentaID = 1354;
    public static int coloredwoodstairslightblueID = 1355;
    public static int coloredwoodstairsyellowID = 1356;
    public static int coloredwoodstairslimeID = 1357;
    public static int coloredwoodstairspinkID = 1358;
    public static int coloredwoodstairsdarkgreyID = 1359;
    public static int coloredwoodstairslightgreyID = 1360;
    public static int coloredwoodstairscyanID = 1361;
    public static int coloredwoodstairspurpleID = 1362;
    public static int coloredwoodstairsblueID = 1363;
    public static int coloredwoodstairsbrownID = 1364;
    public static int coloredwoodstairsgreenID = 1365;
    public static int coloredwoodstairsredID = 1366;
    public static int coloredwoodstairsblackID = 1367;
    public static int coloredwoodslabwhiteID = 1368;
    public static int coloredwoodslaborangeID = 1369;
    public static int coloredwoodslabmagentaID = 1370;
    public static int coloredwoodslablightblueID = 1371;
    public static int coloredwoodslabyellowID = 1372;
    public static int coloredwoodslablimeID = 1373;
    public static int coloredwoodslabpinkID = 1374;
    public static int coloredwoodslabdarkgreyID = 1375;
    public static int coloredwoodslablightgreyID = 1376;
    public static int coloredwoodslabcyanID = 1377;
    public static int coloredwoodslabpurpleID = 1378;
    public static int coloredwoodslabblueID = 1379;
    public static int coloredwoodslabbrownID = 1380;
    public static int coloredwoodslabgreenID = 1381;
    public static int coloredwoodslabredID = 1382;
    public static int coloredwoodslabblackID = 1383;
    public static int coloredwoodthinID = 1384;
    public static int coloredwoodfencegatewhiteID = 1385;
    public static int coloredwoodfencegateorangeID = 1386;
    public static int coloredwoodfencegatemagentaID = 1387;
    public static int coloredwoodfencegatelightblueID = 1388;
    public static int coloredwoodfencegateyellowID = 1389;
    public static int coloredwoodfencegatelimeID = 1390;
    public static int coloredwoodfencegatepinkID = 1391;
    public static int coloredwoodfencegatedarkgreyID = 1392;
    public static int coloredwoodfencegatelightgreyID = 1393;
    public static int coloredwoodfencegatecyanID = 1394;
    public static int coloredwoodfencegatepurpleID = 1395;
    public static int coloredwoodfencegateblueID = 1396;
    public static int coloredwoodfencegatebrownID = 1397;
    public static int coloredwoodfencegategreenID = 1398;
    public static int coloredwoodfencegateredID = 1399;
    public static int coloredwoodfencegateblackID = 1400;
    
    public static int coloredcobblestoneID = 1401;
    public static int coloredcobblestonestairswhiteID = 1402;
    public static int coloredcobblestonestairsorangeID = 1403;
    public static int coloredcobblestonestairsmagentaID = 1404;
    public static int coloredcobblestonestairslightblueID = 1405;
    public static int coloredcobblestonestairsyellowID = 1406;
    public static int coloredcobblestonestairslimeID = 1407;
    public static int coloredcobblestonestairspinkID = 1408;
    public static int coloredcobblestonestairsdarkgreyID = 1409;
    public static int coloredcobblestonestairslightgreyID = 1410;
    public static int coloredcobblestonestairscyanID = 1411;
    public static int coloredcobblestonestairspurpleID = 1412;
    public static int coloredcobblestonestairsblueID = 1413;
    public static int coloredcobblestonestairsbrownID = 1414;
    public static int coloredcobblestonestairsgreenID = 1415;
    public static int coloredcobblestonestairsredID = 1416;
    public static int coloredcobblestonestairsblackID = 1417;
    public static int coloredcobblestoneslabwhiteID = 1418;
    public static int coloredcobblestoneslaborangeID = 1419;
    public static int coloredcobblestoneslabmagentaID = 1420;
    public static int coloredcobblestoneslablightblueID = 1421;
    public static int coloredcobblestoneslabyellowID = 1422;
    public static int coloredcobblestoneslablimeID = 1423;
    public static int coloredcobblestoneslabpinkID = 1424;
    public static int coloredcobblestoneslabdarkgreyID = 1425;
    public static int coloredcobblestoneslablightgreyID = 1426;
    public static int coloredcobblestoneslabcyanID = 1427;
    public static int coloredcobblestoneslabpurpleID = 1428;
    public static int coloredcobblestoneslabblueID = 1429;
    public static int coloredcobblestoneslabbrownID = 1430;
    public static int coloredcobblestoneslabgreenID = 1431;
    public static int coloredcobblestoneslabredID = 1432;
    public static int coloredcobblestoneslabblackID = 1433;
    public static int coloredcobblestonethinID = 1434;
    
    public static int coloredclothstairswhiteID = 1435;
    public static int coloredclothstairsorangeID = 1436;
    public static int coloredclothstairsmagentaID = 1437;
    public static int coloredclothstairslightblueID = 1438;
    public static int coloredclothstairsyellowID = 1439;
    public static int coloredclothstairslimeID = 1440;
    public static int coloredclothstairspinkID = 1441;
    public static int coloredclothstairsdarkgreyID = 1442;
    public static int coloredclothstairslightgreyID = 1443;
    public static int coloredclothstairscyanID = 1444;
    public static int coloredclothstairspurpleID = 1445;
    public static int coloredclothstairsblueID = 1446;
    public static int coloredclothstairsbrownID = 1447;
    public static int coloredclothstairsgreenID = 1448;
    public static int coloredclothstairsredID = 1449;
    public static int coloredclothstairsblackID = 1450;
    public static int coloredclothslabwhiteID = 1451;
    public static int coloredclothslaborangeID = 1452;
    public static int coloredclothslabmagentaID = 1453;
    public static int coloredclothslablightblueID = 1454;
    public static int coloredclothslabyellowID = 1455;
    public static int coloredclothslablimeID = 1456;
    public static int coloredclothslabpinkID = 1457;
    public static int coloredclothslabdarkgreyID = 1458;
    public static int coloredclothslablightgreyID = 1459;
    public static int coloredclothslabcyanID = 1460;
    public static int coloredclothslabpurpleID = 1461;
    public static int coloredclothslabblueID = 1462;
    public static int coloredclothslabbrownID = 1463;
    public static int coloredclothslabgreenID = 1464;
    public static int coloredclothslabredID = 1465;
    public static int coloredclothslabblackID = 1466;
    public static int coloredcloththinID = 1467;
    
    public static int metalblockID = 1468;
    public static int gemblockID = 1469;
    public static int coloredclayID = 1470;
    public static int coloredsandID = 1471;
    public static int coloredbookshelfID = 1472;
    public static int coloredleavesID = 1473;
    public static int coloredwoodID = 1474;
    public static int stonepaverID = 1475;
    public static int windowID = 1476;
    public static int coloredglassID = 1477;
    
    public static int churnID; // ADDED
    public static int quernID; // ADDED
    
    public static int cropboxoneID = 1480;
    
    public static int itembaseID = 15000;
	
	public static int flowerTex[] = new int[14];
	public static int desertplantTex[] = new int[16];
	public static int temperateplantTex[] = new int[16];
	public static int fruitTex[] = new int[16];
	public static int warmfruitTex[] = new int[16];
	public static int bushTex[] = new int[16];
	public static int warmbushTex[] = new int[16];
	public static int coldbushTex[] = new int[16];
	public static int mineralTex[] = new int[16];
	public static int oreTex[] = new int[16];
	public static int gemTex[] = new int[16];
	public static int coloredsmoothstoneTex[] = new int[16];
	public static int saplingTex[] = new int[16];
	public static int warmsaplingTex[] = new int[16];
	public static int coloredplankTex[] = new int[16];
	public static int coloredwoodfenceTex[] = new int[16];
	public static int coloredcobblestoneTex[] = new int[16];
	public static int coloredclothTex[] = new int[16];
	public static int metalblockTex[] = new int[16];
	public static int gemblockTex[] = new int[16];
	public static int coloredclayTex[] = new int[16];
	public static int coloredsandTex[] = new int[16];
	public static int coloredbookshelfTex[] = new int[16];
	public static int coloredleavesTex[] = new int[16];
	public static int coloredwoodtopTex[] = new int[16];
	public static int coloredwoodsideTex[] = new int[16];
	public static int stonepaverTex[] = new int[16];
	public static int windowTex[] = new int[16];
	public static int coloredglassTex[] = new int[16];
	
	public static int[] churnTex = { 241, 242 }; // ADDED
    public static int[] quernTex = { 243, 244 }; // ADDED
    
    public static int cropboxoneTex[] = new int[16];
	
    public static int flowerRarity = 20;
    public static int desertplantRarity = 20;
    public static int temperateplantRarity = 20;
    public static int fruittreeRarity = 5;
    public static int warmfruittreeRarity = 5;
    public static int bushRarity = 5;
    public static int warmbushRarity = 5;
    public static int coldbushRarity = 5;
	
	public static int mineralRarity;
    public static int mineralDepth;
    public static int mineralDensity;
    
    public static int oreRarity;
    public static int oreDepth;
    public static int oreDensity;
    
    public static int gemRarity;
    public static int gemDepth;
    public static int gemDensity;

    public static int stoneDensity = 5;
    public static int ediblefruitveggieheal = 1;
    public static int flowerdyerecipeOutput = 8;
    public static int flowerseedrecipeOutput = 2;
	
	public static boolean generateflower = true;
	public static boolean generatedesertplant = true;
	public static boolean generatetemperateplant = true;
	 public static boolean generatefruittree = true;
	 public static boolean generatewarmfruittree = true;
	 public static boolean generatebush = true;
	 public static boolean generatewarmbush = true;
	 public static boolean generatecoldbush = true;
	 public static boolean generatemineral = true;
	 public static boolean generateore = true;
	 public static boolean generategem = true;
	 public static boolean generatecoloredsmoothstone = true;
    public static boolean flowerseedgrassdrop = true;
    public static boolean cropsseedgrassdrop = true;
    
    public static int churnGUI; // ADDED
    public static int quernGUI; // ADDED
    
    public static Pamcombinedmod instance; // ADDED
    
    @PreInit
	public void preInit(FMLPreInitializationEvent event) {
    	instance = this; // ADDED
		Configuration cfg = new Configuration(event.getSuggestedConfigurationFile());
		try {
			cfg.load();
			//Naturally Genning
			flowerID = cfg.getOrCreateBlockIdProperty("flowerID", 1250).getInt(1250);
			desertplantID = cfg.getOrCreateBlockIdProperty("desertplantID", 1251).getInt(1251);
			temperateplantID = cfg.getOrCreateBlockIdProperty("temperateplantID", 1252).getInt(1252);
			fruitID = cfg.getOrCreateBlockIdProperty("fruitID", 1253).getInt(1253);
			warmfruitID = cfg.getOrCreateBlockIdProperty("warmfruitID", 1254).getInt(1254);
			bushID = cfg.getOrCreateBlockIdProperty("bushID", 1255).getInt(1255);
			warmbushID = cfg.getOrCreateBlockIdProperty("warmbushID", 1256).getInt(1256);
			coldbushID = cfg.getOrCreateBlockIdProperty("coldbushID", 1257).getInt(1257);
			mineralID = cfg.getOrCreateBlockIdProperty("mineralID", 1258).getInt(1258);
			oreID = cfg.getOrCreateBlockIdProperty("oreID", 1259).getInt(1259);
			gemID = cfg.getOrCreateBlockIdProperty("gemID", 1260).getInt(1260);
			coloredsmoothstoneID = cfg.getOrCreateBlockIdProperty("coloredsmoothID", 1261).getInt(1261);
			saplingID = cfg.getOrCreateBlockIdProperty("saplingID", 1262).getInt(1262);
			warmsaplingID = cfg.getOrCreateBlockIdProperty("warmsaplingID", 1263).getInt(1263);
			//Crops
			cropbaseID = cfg.getOrCreateBlockIdProperty("cropbaseID", 1264).getInt(1264);
			//Colored Wood
			coloredplankID = cfg.getOrCreateBlockIdProperty("coloredplankID", 1350).getInt(1250);
			coloredwoodfenceID = cfg.getOrCreateBlockIdProperty("coloredwoodfenceID", 1351).getInt(1251);
			coloredwoodstairswhiteID = cfg.getOrCreateBlockIdProperty("coloredwoodstairswhiteID", 1352).getInt(1352);
			coloredwoodstairsorangeID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsorangeID", 1353).getInt(1353);
		    coloredwoodstairsmagentaID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsmagentaID", 1354).getInt(1354);
		    coloredwoodstairslightblueID = cfg.getOrCreateBlockIdProperty("coloredwoodstairslightblueID", 1355).getInt(1355);
		    coloredwoodstairsyellowID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsyellowID", 1356).getInt(1356);
		    coloredwoodstairslimeID = cfg.getOrCreateBlockIdProperty("coloredwoodstairslimeID", 1357).getInt(1357);
		    coloredwoodstairspinkID = cfg.getOrCreateBlockIdProperty("coloredwoodstairspinkID", 1358).getInt(1358);
		    coloredwoodstairsdarkgreyID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsdarkgreyID", 1359).getInt(1359);
		    coloredwoodstairslightgreyID = cfg.getOrCreateBlockIdProperty("coloredwoodstairslightgreyID", 1360).getInt(1360);
		    coloredwoodstairscyanID = cfg.getOrCreateBlockIdProperty("coloredwoodstairscyanID", 1361).getInt(1361);
		    coloredwoodstairspurpleID = cfg.getOrCreateBlockIdProperty("coloredwoodstairspurpleID", 1362).getInt(1362);
		    coloredwoodstairsblueID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsblueID", 1363).getInt(1363);
		    coloredwoodstairsbrownID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsbrownID", 1364).getInt(1364);
		    coloredwoodstairsgreenID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsgreenID", 1365).getInt(1365);
		    coloredwoodstairsredID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsredID", 1366).getInt(1366);
		    coloredwoodstairsblackID = cfg.getOrCreateBlockIdProperty("coloredwoodstairsblackID", 1367).getInt(1367);			
		    coloredwoodslabwhiteID = cfg.getOrCreateBlockIdProperty("coloredwoodslabwhiteID", 1368).getInt(1368);
			coloredwoodslaborangeID = cfg.getOrCreateBlockIdProperty("coloredwoodslaborangeID", 1369).getInt(1369);
		    coloredwoodslabmagentaID = cfg.getOrCreateBlockIdProperty("coloredwoodslabmagentaID", 1370).getInt(1370);
		    coloredwoodslablightblueID = cfg.getOrCreateBlockIdProperty("coloredwoodslablightblueID", 1371).getInt(1371);
		    coloredwoodslabyellowID = cfg.getOrCreateBlockIdProperty("coloredwoodslabyellowID", 1372).getInt(1372);
		    coloredwoodslablimeID = cfg.getOrCreateBlockIdProperty("coloredwoodslablimeID", 1373).getInt(1373);
		    coloredwoodslabpinkID = cfg.getOrCreateBlockIdProperty("coloredwoodslabpinkID", 1374).getInt(1374);
		    coloredwoodslabdarkgreyID = cfg.getOrCreateBlockIdProperty("coloredwoodslabdarkgreyID", 1375).getInt(1375);
		    coloredwoodslablightgreyID = cfg.getOrCreateBlockIdProperty("coloredwoodslablightgreyID", 1376).getInt(1376);
		    coloredwoodslabcyanID = cfg.getOrCreateBlockIdProperty("coloredwoodslabcyanID", 1377).getInt(1377);
		    coloredwoodslabpurpleID = cfg.getOrCreateBlockIdProperty("coloredwoodslabpurpleID", 1378).getInt(1378);
		    coloredwoodslabblueID = cfg.getOrCreateBlockIdProperty("coloredwoodslabblueID", 1379).getInt(1379);
		    coloredwoodslabbrownID = cfg.getOrCreateBlockIdProperty("coloredwoodslabbrownID", 1380).getInt(1380);
		    coloredwoodslabgreenID = cfg.getOrCreateBlockIdProperty("coloredwoodslabgreenID", 1381).getInt(1381);
		    coloredwoodslabredID = cfg.getOrCreateBlockIdProperty("coloredwoodslabredID", 1382).getInt(1382);
		    coloredwoodslabblackID = cfg.getOrCreateBlockIdProperty("coloredwoodslabblackID", 1383).getInt(1383);
		    coloredwoodthinID = cfg.getOrCreateBlockIdProperty("coloredwoodthinID", 1384).getInt(1384);
		    coloredwoodfencegatewhiteID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatewhiteID", 1385).getInt(1385);
			coloredwoodfencegateorangeID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegateorangeID", 1386).getInt(1386);
		    coloredwoodfencegatemagentaID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatemagentaID", 1387).getInt(1387);
		    coloredwoodfencegatelightblueID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatelightblueID", 1388).getInt(1388);
		    coloredwoodfencegateyellowID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegateyellowID", 1389).getInt(1389);
		    coloredwoodfencegatelimeID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatelimeID", 1390).getInt(1390);
		    coloredwoodfencegatepinkID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatepinkID", 1391).getInt(1391);
		    coloredwoodfencegatedarkgreyID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatedarkgreyID", 1392).getInt(1392);
		    coloredwoodfencegatelightgreyID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatelightgreyID", 1393).getInt(1393);
		    coloredwoodfencegatecyanID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatecyanID", 1394).getInt(1394);
		    coloredwoodfencegatepurpleID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatepurpleID", 1395).getInt(1395);
		    coloredwoodfencegateblueID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegateblueID", 1396).getInt(1396);
		    coloredwoodfencegatebrownID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegatebrownID", 1397).getInt(1397);
		    coloredwoodfencegategreenID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegategreenID", 1398).getInt(1398);
		    coloredwoodfencegateredID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegateredID", 1399).getInt(1399);
		    coloredwoodfencegateblackID = cfg.getOrCreateBlockIdProperty("coloredwoodfencegateblackID", 1400).getInt(1400);
		    //Colored Cobblestone
			coloredcobblestoneID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneID", 1401).getInt(1401);
			coloredcobblestonestairswhiteID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairswhiteID", 1402).getInt(1402);
			coloredcobblestonestairsorangeID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsorangeID", 1403).getInt(1403);
		    coloredcobblestonestairsmagentaID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsmagentaID", 1404).getInt(1404);
		    coloredcobblestonestairslightblueID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairslightblueID", 1405).getInt(1405);
		    coloredcobblestonestairsyellowID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsyellowID", 1406).getInt(1406);
		    coloredcobblestonestairslimeID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairslimeID", 1407).getInt(1407);
		    coloredcobblestonestairspinkID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairspinkID", 1408).getInt(1408);
		    coloredcobblestonestairsdarkgreyID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsdarkgreyID", 1409).getInt(1409);
		    coloredcobblestonestairslightgreyID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairslightgreyID", 1410).getInt(1410);
		    coloredcobblestonestairscyanID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairscyanID", 1411).getInt(1411);
		    coloredcobblestonestairspurpleID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairspurpleID", 1412).getInt(1412);
		    coloredcobblestonestairsblueID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsblueID", 1413).getInt(1413);
		    coloredcobblestonestairsbrownID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsbrownID", 1414).getInt(1414);
		    coloredcobblestonestairsgreenID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsgreenID", 1415).getInt(1415);
		    coloredcobblestonestairsredID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsredID", 1416).getInt(1416);
		    coloredcobblestonestairsblackID = cfg.getOrCreateBlockIdProperty("coloredcobblestonestairsblackID", 1417).getInt(1417);			
		    coloredcobblestoneslabwhiteID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabwhiteID", 1418).getInt(1418);
			coloredcobblestoneslaborangeID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslaborangeID", 1419).getInt(1419);
		    coloredcobblestoneslabmagentaID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabmagentaID", 1420).getInt(1420);
		    coloredcobblestoneslablightblueID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslablightblueID", 1421).getInt(1421);
		    coloredcobblestoneslabyellowID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabyellowID", 1422).getInt(1422);
		    coloredcobblestoneslablimeID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslablimeID", 1423).getInt(1423);
		    coloredcobblestoneslabpinkID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabpinkID", 1424).getInt(1424);
		    coloredcobblestoneslabdarkgreyID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabdarkgreyID", 1425).getInt(1425);
		    coloredcobblestoneslablightgreyID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslablightgreyID", 1426).getInt(1426);
		    coloredcobblestoneslabcyanID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabcyanID", 1427).getInt(1427);
		    coloredcobblestoneslabpurpleID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabpurpleID", 1428).getInt(1428);
		    coloredcobblestoneslabblueID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabblueID", 1429).getInt(1429);
		    coloredcobblestoneslabbrownID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabbrownID", 1430).getInt(1430);
		    coloredcobblestoneslabgreenID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabgreenID", 1431).getInt(1431);
		    coloredcobblestoneslabredID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabredID", 1432).getInt(1432);
		    coloredcobblestoneslabblackID = cfg.getOrCreateBlockIdProperty("coloredcobblestoneslabblackID", 1433).getInt(1433);
		    coloredcobblestonethinID = cfg.getOrCreateBlockIdProperty("coloredcobblestonethinID", 1434).getInt(1434);
		    //Colored Cloth
		    coloredclothstairswhiteID = cfg.getOrCreateBlockIdProperty("coloredclothstairswhiteID", 1435).getInt(1435);
			coloredclothstairsorangeID = cfg.getOrCreateBlockIdProperty("coloredclothstairsorangeID", 1436).getInt(1436);
		    coloredclothstairsmagentaID = cfg.getOrCreateBlockIdProperty("coloredclothstairsmagentaID", 1437).getInt(1437);
		    coloredclothstairslightblueID = cfg.getOrCreateBlockIdProperty("coloredclothstairslightblueID", 1438).getInt(1438);
		    coloredclothstairsyellowID = cfg.getOrCreateBlockIdProperty("coloredclothstairsyellowID", 1439).getInt(1439);
		    coloredclothstairslimeID = cfg.getOrCreateBlockIdProperty("coloredclothstairslimeID", 1440).getInt(1440);
		    coloredclothstairspinkID = cfg.getOrCreateBlockIdProperty("coloredclothstairspinkID", 1441).getInt(1441);
		    coloredclothstairsdarkgreyID = cfg.getOrCreateBlockIdProperty("coloredclothstairsdarkgreyID", 1442).getInt(1442);
		    coloredclothstairslightgreyID = cfg.getOrCreateBlockIdProperty("coloredclothstairslightgreyID", 1443).getInt(1443);
		    coloredclothstairscyanID = cfg.getOrCreateBlockIdProperty("coloredclothstairscyanID", 1444).getInt(1444);
		    coloredclothstairspurpleID = cfg.getOrCreateBlockIdProperty("coloredclothstairspurpleID", 1445).getInt(1445);
		    coloredclothstairsblueID = cfg.getOrCreateBlockIdProperty("coloredclothstairsblueID", 1446).getInt(1446);
		    coloredclothstairsbrownID = cfg.getOrCreateBlockIdProperty("coloredclothstairsbrownID", 1447).getInt(1447);
		    coloredclothstairsgreenID = cfg.getOrCreateBlockIdProperty("coloredclothstairsgreenID", 1448).getInt(1448);
		    coloredclothstairsredID = cfg.getOrCreateBlockIdProperty("coloredclothstairsredID", 1449).getInt(1449);
		    coloredclothstairsblackID = cfg.getOrCreateBlockIdProperty("coloredclothstairsblackID", 1450).getInt(1450);			
		    coloredclothslabwhiteID = cfg.getOrCreateBlockIdProperty("coloredclothslabwhiteID", 1451).getInt(1451);
			coloredclothslaborangeID = cfg.getOrCreateBlockIdProperty("coloredclothslaborangeID", 1452).getInt(1452);
		    coloredclothslabmagentaID = cfg.getOrCreateBlockIdProperty("coloredclothslabmagentaID", 1453).getInt(1453);
		    coloredclothslablightblueID = cfg.getOrCreateBlockIdProperty("coloredclothslablightblueID", 1454).getInt(1454);
		    coloredclothslabyellowID = cfg.getOrCreateBlockIdProperty("coloredclothslabyellowID", 1455).getInt(1455);
		    coloredclothslablimeID = cfg.getOrCreateBlockIdProperty("coloredclothslablimeID", 1456).getInt(1456);
		    coloredclothslabpinkID = cfg.getOrCreateBlockIdProperty("coloredclothslabpinkID", 1457).getInt(1457);
		    coloredclothslabdarkgreyID = cfg.getOrCreateBlockIdProperty("coloredclothslabdarkgreyID", 1458).getInt(1458);
		    coloredclothslablightgreyID = cfg.getOrCreateBlockIdProperty("coloredclothslablightgreyID", 1459).getInt(1459);
		    coloredclothslabcyanID = cfg.getOrCreateBlockIdProperty("coloredclothslabcyanID", 1460).getInt(1460);
		    coloredclothslabpurpleID = cfg.getOrCreateBlockIdProperty("coloredclothslabpurpleID", 1461).getInt(1461);
		    coloredclothslabblueID = cfg.getOrCreateBlockIdProperty("coloredclothslabblueID", 1462).getInt(1462);
		    coloredclothslabbrownID = cfg.getOrCreateBlockIdProperty("coloredclothslabbrownID", 1463).getInt(1463);
		    coloredclothslabgreenID = cfg.getOrCreateBlockIdProperty("coloredclothslabgreenID", 1464).getInt(1464);
		    coloredclothslabredID = cfg.getOrCreateBlockIdProperty("coloredclothslabredID", 1465).getInt(1465);
		    coloredclothslabblackID = cfg.getOrCreateBlockIdProperty("coloredclothslabblackID", 1466).getInt(1466);
		    coloredcloththinID = cfg.getOrCreateBlockIdProperty("coloredcloththinID", 1467).getInt(1467);
		    //Misc 
		    metalblockID = cfg.getOrCreateBlockIdProperty("metalblockID", 1468).getInt(1468);
		    gemblockID = cfg.getOrCreateBlockIdProperty("gemblockID", 1469).getInt(1469);
		    coloredclayID = cfg.getOrCreateBlockIdProperty("coloredclayID", 1470).getInt(1470);
		    coloredsandID = cfg.getOrCreateBlockIdProperty("coloredsandID", 1471).getInt(1471);
		    coloredbookshelfID = cfg.getOrCreateBlockIdProperty("coloredbookshelfID", 1472).getInt(1472);
		    coloredleavesID = cfg.getOrCreateBlockIdProperty("coloredleavesID", 1473).getInt(1473);
		    coloredwoodID = cfg.getOrCreateBlockIdProperty("coloredwoodID", 1474).getInt(1474);
		    stonepaverID = cfg.getOrCreateBlockIdProperty("stonepaverID", 1475).getInt(1475);
		    windowID = cfg.getOrCreateBlockIdProperty("windowID", 1476).getInt(1476);
		    coloredglassID = cfg.getOrCreateBlockIdProperty("coloredglassID", 1477).getInt(1477);
		    churnID = Integer.parseInt(cfg.getOrCreateBlockIdProperty("Churn", 1478).value); // ADDED
            quernID = Integer.parseInt(cfg.getOrCreateBlockIdProperty("Quern", 1479).value); // ADDED
            cropboxoneID = cfg.getOrCreateBlockIdProperty("cropboxoneID", 1480).getInt(1480);

			itembaseID = cfg.getOrCreateIntProperty("itembaseID", Configuration.CATEGORY_ITEM, 15000).getInt(15000);
			flowerRarity = cfg.getOrCreateIntProperty("flowerRarity", Configuration.CATEGORY_GENERAL, 20).getInt(20);
			desertplantRarity = cfg.getOrCreateIntProperty("desertplantRarity", Configuration.CATEGORY_GENERAL, 20).getInt(20);
			temperateplantRarity = cfg.getOrCreateIntProperty("temperateplantRarity", Configuration.CATEGORY_GENERAL, 20).getInt(20);
			fruittreeRarity = cfg.getOrCreateIntProperty("fruittreeRarity", Configuration.CATEGORY_GENERAL, 5).getInt(5);
			bushRarity = cfg.getOrCreateIntProperty("bushRarity", Configuration.CATEGORY_GENERAL, 5).getInt(5);
			warmbushRarity = cfg.getOrCreateIntProperty("warmbushRarity", Configuration.CATEGORY_GENERAL, 5).getInt(5);
			coldbushRarity = cfg.getOrCreateIntProperty("coldbushRarity", Configuration.CATEGORY_GENERAL, 5).getInt(5);
			stoneDensity = cfg.getOrCreateIntProperty("stoneDensity", Configuration.CATEGORY_GENERAL, 5).getInt(5);
			ediblefruitveggieheal = cfg.getOrCreateIntProperty("ediblefruitveggieheal", Configuration.CATEGORY_GENERAL, 1).getInt(1);
			flowerdyerecipeOutput = cfg.getOrCreateIntProperty("flowerdyerecipeOutput", Configuration.CATEGORY_GENERAL, 8).getInt(8);
			flowerseedrecipeOutput = cfg.getOrCreateIntProperty("flowerseedrecipeOutput", Configuration.CATEGORY_GENERAL, 2).getInt(2);
			generateflower = cfg.getOrCreateBooleanProperty("generateflower", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatedesertplant = cfg.getOrCreateBooleanProperty("generatedesertplant", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatetemperateplant = cfg.getOrCreateBooleanProperty("generatetemperateplant", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatefruittree = cfg.getOrCreateBooleanProperty("generatefruittree", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatewarmfruittree = cfg.getOrCreateBooleanProperty("generatewarmfruittree", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatebush = cfg.getOrCreateBooleanProperty("generatebush", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatewarmbush = cfg.getOrCreateBooleanProperty("generatewarmbush", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatecoldbush = cfg.getOrCreateBooleanProperty("generatecoldbush", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatemineral = cfg.getOrCreateBooleanProperty("generatemineral", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generateore = cfg.getOrCreateBooleanProperty("generateore", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generategem = cfg.getOrCreateBooleanProperty("generategem", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			generatecoloredsmoothstone = cfg.getOrCreateBooleanProperty("generatecoloredsmoothstone", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			flowerseedgrassdrop = cfg.getOrCreateBooleanProperty("flowerseedgrassdrop", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			cropsseedgrassdrop = cfg.getOrCreateBooleanProperty("cropsseedgrassdrop", Configuration.CATEGORY_GENERAL, true).getBoolean(true);
			churnGUI = Integer.parseInt(cfg.getOrCreateIntProperty("Churn GUI id", Configuration.CATEGORY_GENERAL, 105).value); // ADDED
            quernGUI = Integer.parseInt(cfg.getOrCreateIntProperty("Quern GUI id", Configuration.CATEGORY_GENERAL, 106).value); // ADDED
		} catch (Exception e) {
			FMLLog.log(Level.SEVERE, e, "Pamcombinedmod has a problem loading it's configuration");
		} finally {
			cfg.save();
		}
	}
	
	public static Block pamFlower;
	public static Block pamdesertPlant;
	public static Block pamtemperatePlant;
	public static Block pamFruit;
	public static Block pamwarmFruit;
	public static Block pamBush;
	public static Block pamwarmBush;
	public static Block pamcoldBush;
	public static Block pamMineral;
	public static Block pamOre;
	public static Block pamGem;
	public static Block pamcoloredSmoothstone;
	public static Block pamSapling;
	public static Block pamwarmSapling;
	public static Block pamcoloredPlank;
	public static Block pamcoloredwoodFence;
	public static Block pamcoloredwoodstairsWhite;
	public static Block pamcoloredwoodstairsOrange;
    public static Block pamcoloredwoodstairsMagenta;
    public static Block pamcoloredwoodstairsLightblue;
    public static Block pamcoloredwoodstairsYellow;
    public static Block pamcoloredwoodstairsLime;
    public static Block pamcoloredwoodstairsPink;
    public static Block pamcoloredwoodstairsDarkgrey;
    public static Block pamcoloredwoodstairsLightgrey;
    public static Block pamcoloredwoodstairsCyan;
    public static Block pamcoloredwoodstairsPurple;
    public static Block pamcoloredwoodstairsBlue;
    public static Block pamcoloredwoodstairsBrown;
    public static Block pamcoloredwoodstairsGreen;
    public static Block pamcoloredwoodstairsRed;
    public static Block pamcoloredwoodstairsBlack;
	public static Block pamcoloredwoodslabWhite;
	public static Block pamcoloredwoodslabOrange;
    public static Block pamcoloredwoodslabMagenta;
    public static Block pamcoloredwoodslabLightblue;
    public static Block pamcoloredwoodslabYellow;
    public static Block pamcoloredwoodslabLime;
    public static Block pamcoloredwoodslabPink;
    public static Block pamcoloredwoodslabDarkgrey;
    public static Block pamcoloredwoodslabLightgrey;
    public static Block pamcoloredwoodslabCyan;
    public static Block pamcoloredwoodslabPurple;
    public static Block pamcoloredwoodslabBlue;
    public static Block pamcoloredwoodslabBrown;
    public static Block pamcoloredwoodslabGreen;
    public static Block pamcoloredwoodslabRed;
    public static Block pamcoloredwoodslabBlack;
    public static Block pamcoloredwoodThin;
	public static Block pamcoloredwoodfencegateWhite;
	public static Block pamcoloredwoodfencegateOrange;
    public static Block pamcoloredwoodfencegateMagenta;
    public static Block pamcoloredwoodfencegateLightblue;
    public static Block pamcoloredwoodfencegateYellow;
    public static Block pamcoloredwoodfencegateLime;
    public static Block pamcoloredwoodfencegatePink;
    public static Block pamcoloredwoodfencegateDarkgrey;
    public static Block pamcoloredwoodfencegateLightgrey;
    public static Block pamcoloredwoodfencegateCyan;
    public static Block pamcoloredwoodfencegatePurple;
    public static Block pamcoloredwoodfencegateBlue;
    public static Block pamcoloredwoodfencegateBrown;
    public static Block pamcoloredwoodfencegateGreen;
    public static Block pamcoloredwoodfencegateRed;
    public static Block pamcoloredwoodfencegateBlack;
    public static Block pamcoloredCobblestone;
	public static Block pamcoloredcobblestonestairsWhite;
	public static Block pamcoloredcobblestonestairsOrange;
    public static Block pamcoloredcobblestonestairsMagenta;
    public static Block pamcoloredcobblestonestairsLightblue;
    public static Block pamcoloredcobblestonestairsYellow;
    public static Block pamcoloredcobblestonestairsLime;
    public static Block pamcoloredcobblestonestairsPink;
    public static Block pamcoloredcobblestonestairsDarkgrey;
    public static Block pamcoloredcobblestonestairsLightgrey;
    public static Block pamcoloredcobblestonestairsCyan;
    public static Block pamcoloredcobblestonestairsPurple;
    public static Block pamcoloredcobblestonestairsBlue;
    public static Block pamcoloredcobblestonestairsBrown;
    public static Block pamcoloredcobblestonestairsGreen;
    public static Block pamcoloredcobblestonestairsRed;
    public static Block pamcoloredcobblestonestairsBlack;
	public static Block pamcoloredcobblestoneslabWhite;
	public static Block pamcoloredcobblestoneslabOrange;
    public static Block pamcoloredcobblestoneslabMagenta;
    public static Block pamcoloredcobblestoneslabLightblue;
    public static Block pamcoloredcobblestoneslabYellow;
    public static Block pamcoloredcobblestoneslabLime;
    public static Block pamcoloredcobblestoneslabPink;
    public static Block pamcoloredcobblestoneslabDarkgrey;
    public static Block pamcoloredcobblestoneslabLightgrey;
    public static Block pamcoloredcobblestoneslabCyan;
    public static Block pamcoloredcobblestoneslabPurple;
    public static Block pamcoloredcobblestoneslabBlue;
    public static Block pamcoloredcobblestoneslabBrown;
    public static Block pamcoloredcobblestoneslabGreen;
    public static Block pamcoloredcobblestoneslabRed;
    public static Block pamcoloredcobblestoneslabBlack;
    public static Block pamcoloredcobblestoneThin;
    public static Block pamcoloredclothstairsWhite;
	public static Block pamcoloredclothstairsOrange;
    public static Block pamcoloredclothstairsMagenta;
    public static Block pamcoloredclothstairsLightblue;
    public static Block pamcoloredclothstairsYellow;
    public static Block pamcoloredclothstairsLime;
    public static Block pamcoloredclothstairsPink;
    public static Block pamcoloredclothstairsDarkgrey;
    public static Block pamcoloredclothstairsLightgrey;
    public static Block pamcoloredclothstairsCyan;
    public static Block pamcoloredclothstairsPurple;
    public static Block pamcoloredclothstairsBlue;
    public static Block pamcoloredclothstairsBrown;
    public static Block pamcoloredclothstairsGreen;
    public static Block pamcoloredclothstairsRed;
    public static Block pamcoloredclothstairsBlack;
	public static Block pamcoloredclothslabWhite;
	public static Block pamcoloredclothslabOrange;
    public static Block pamcoloredclothslabMagenta;
    public static Block pamcoloredclothslabLightblue;
    public static Block pamcoloredclothslabYellow;
    public static Block pamcoloredclothslabLime;
    public static Block pamcoloredclothslabPink;
    public static Block pamcoloredclothslabDarkgrey;
    public static Block pamcoloredclothslabLightgrey;
    public static Block pamcoloredclothslabCyan;
    public static Block pamcoloredclothslabPurple;
    public static Block pamcoloredclothslabBlue;
    public static Block pamcoloredclothslabBrown;
    public static Block pamcoloredclothslabGreen;
    public static Block pamcoloredclothslabRed;
    public static Block pamcoloredclothslabBlack;
    public static Block pamcoloredclothThin;
    
    public static Block pammetalBlock;
    public static Block pamgemBlock;
    public static Block pamcoloredClay;
    public static Block pamcoloredSand;
    public static Block pamcoloredBookshelf;
    public static Block pamcoloredLeaves;
    public static Block pamcoloredWood;
    public static Block pamstonePaver;
    public static Block pamWindow;
    public static Block pamcoloredGlass;
    
    public static Block pamChurn; // ADDED
    public static Block pamQuern; // ADDED
    
    public static Block pamcropboxOne;
	
	public static Block pamwhiteflowerCrop;
	public static Block pamorangeflowerCrop;
	public static Block pammagentaflowerCrop;
	public static Block pamlightblueflowerCrop;
	public static Block pamyellowflowerCrop;
	public static Block pamlimeflowerCrop;
	public static Block pampinkflowerCrop;
	public static Block pamlightgreyflowerCrop;
	public static Block pamdarkgreyflowerCrop;
	public static Block pamcyanflowerCrop;
	public static Block pampurpleflowerCrop;
	public static Block pamblueflowerCrop;
	public static Block pambrownflowerCrop;
	public static Block pamgreenflowerCrop;
	public static Block pamredflowerCrop;
	public static Block pamblackflowerCrop;
	
	public static Block pamtomatoCrop;
	public static Block pampotatoCrop;
	public static Block pamlettuceCrop;
	public static Block pamonionCrop;
	public static Block pamcarrotCrop;
	public static Block pamcornCrop;
	public static Block pampeanutCrop;
	public static Block pamcucumberCrop;
	public static Block pamriceCrop;
	public static Block pambeansCrop;
	public static Block pambellpepperCrop;
	public static Block pameggplantCrop;
	public static Block pamteaCrop;
	public static Block pamcoffeeCrop;
	public static Block pambeetCrop;
	public static Block pambroccoliCrop;
	public static Block pamsweetpotatoCrop;
	public static Block pampeasCrop;
	public static Block pampineappleCrop;
	public static Block pamturnipCrop;
	public static Block pamgingerCrop;
	public static Block pammustardCrop;
	public static Block pamgarlicCrop;
	public static Block pamrottenmeatCrop;
	public static Block pamharvestwheatCrop;
	public static Block pamblueberryCrop;
	public static Block pamblackberryCrop;
	public static Block pamraspberryCrop;
	public static Block pamkiwiCrop;
	public static Block pamstrawberryCrop;
	public static Block pamgrapeCrop;
	public static Block pamsunflowerCrop;
	public static Block pamwhitemushroomCrop;
	public static Block pamcottonCrop;
	public static Block pamcandleberryCrop;
	public static Block pamcactusfruitCrop;
	public static Block pamradishCrop;
	public static Block pamceleryCrop;
	public static Block pamzucchiniCrop;
	public static Block pamchilipepperCrop;
	public static Block pamcantaloupeCrop;
	public static Block pamasparagusCrop;
	public static Block pamcranberryCrop;
	public static Block pamspiceleafCrop;
	
	public static Item whiteflowerseedItem;
    public static Item orangeflowerseedItem;
    public static Item magentaflowerseedItem;
    public static Item lightblueflowerseedItem;
    public static Item yellowflowerseedItem;
    public static Item limeflowerseedItem;
    public static Item pinkflowerseedItem;
    public static Item lightgreyflowerseedItem;
    public static Item darkgreyflowerseedItem;
    public static Item cyanflowerseedItem;
    public static Item purpleflowerseedItem;
    public static Item blueflowerseedItem;
    public static Item brownflowerseedItem;
    public static Item greenflowerseedItem;
    public static Item redflowerseedItem;
    public static Item blackflowerseedItem;
    
    public static Item cactusPick;
    public static Item cactusShovel;
    public static Item cactusAxe;
    public static Item cactusHoe;
    public static Item cactusSword;

    public static Item sandstonePick;
    public static Item sandstoneShovel;
    public static Item sandstoneAxe;
    public static Item sandstoneHoe;
    public static Item sandstoneSword;

    public static Item glasssteelPick;
    public static Item glasssteelShovel;
    public static Item glasssteelAxe;
    public static Item glasssteelHoe;
    public static Item glasssteelSword;

    public static Item cactusstickItem;
    public static Item glasssteelItem;
    public static Item cactusfruitItem;
    public static Item cactusfruitseedItem;
    
    public static Item bonePick;
    public static Item boneShovel;
    public static Item boneAxe;
    public static Item boneHoe;
    public static Item boneSword;

    static EnumArmorMaterial armorBone = EnumHelper.addArmorMaterial("BONE", 15, new int[] {2, 5, 4, 1}, 12);

    public static Item boneHelm;
    public static Item boneChest;
    public static Item boneLegs;
    public static Item boneBoots;

    public static Item bananaItem;
    public static Item cherryItem;
    public static Item coconutItem;
    public static Item lemonItem;
    public static Item orangeItem;
    public static Item peachItem;
    public static Item limeItem;
    public static Item mangoItem;
    public static Item walnutItem;
    public static Item pearItem;
    public static Item plumItem;
    public static Item oliveItem;
    public static Item cinnamonItem;
    public static Item honeyItem;
    public static Item avacadoItem;
    public static Item nutmegItem;
    public static Item pomegranateItem;
    public static Item vanillabeanItem;
    public static Item papayaItem;
    public static Item starfruitItem;
    public static Item peppercornItem;

    public static Item tomatoseedItem;
    public static Item potatoseedItem;
    public static Item lettuceseedItem;
    public static Item onionseedItem;
    public static Item carrotseedItem;
    public static Item cornseedItem;
    public static Item strawberryseedItem;
    public static Item cucumberseedItem;
    public static Item riceseedItem;
    public static Item beansseedItem;
    public static Item bellpepperseedItem;
    public static Item eggplantseedItem;
    public static Item teaseedItem;
    public static Item coffeeseedItem;
    public static Item beetseedItem;
    public static Item broccoliseedItem;
    public static Item sweetpotatoseedItem;
    public static Item peasseedItem;
    public static Item pineappleseedItem;
    public static Item turnipseedItem;
    public static Item gingerseedItem;
    public static Item blueberryseedItem;
    public static Item blackberryseedItem;
    public static Item raspberryseedItem;
    public static Item kiwiseedItem;
    public static Item grapeseedItem;
    public static Item peanutseedItem;
    public static Item sunflowerseedItem;
    public static Item mustardseedItem;
    public static Item garlicseedItem;
    public static Item rottenseedItem;
    public static Item whitemushroomseedItem;
    public static Item harvestwheatseedItem;
    public static Item cottonseedItem;
    public static Item candleberryseedItem;
    public static Item radishseedItem;
	public static Item celeryseedItem;
	public static Item zucchiniseedItem;
	public static Item chilipepperseedItem;
	public static Item cantaloupeseedItem;
	public static Item asparagusseedItem;
	public static Item cranberryseedItem;
	public static Item spiceleafseedItem;

    public static Item tomatoseedpacketItem;
    public static Item potatoseedpacketItem;
    public static Item lettuceseedpacketItem;
    public static Item onionseedpacketItem;
    public static Item carrotseedpacketItem;
    public static Item cornseedpacketItem;
    public static Item strawberryseedpacketItem;
    public static Item cucumberseedpacketItem;
    public static Item riceseedpacketItem;
    public static Item beansseedpacketItem;
    public static Item bellpepperseedpacketItem;
    public static Item eggplantseedpacketItem;
    public static Item teaseedpacketItem;
    public static Item coffeeseedpacketItem;
    public static Item beetseedpacketItem;
    public static Item broccoliseedpacketItem;
    public static Item sweetpotatoseedpacketItem;
    public static Item peasseedpacketItem;
    public static Item pineappleseedpacketItem;
    public static Item turnipseedpacketItem;
    public static Item gingerseedpacketItem;
    public static Item blueberryseedpacketItem;
    public static Item blackberryseedpacketItem;
    public static Item raspberryseedpacketItem;
    public static Item kiwiseedpacketItem;
    public static Item grapeseedpacketItem;
    public static Item peanutseedpacketItem;
    public static Item sunflowerseedpacketItem;
    public static Item mustardseedpacketItem;
    public static Item garlicseedpacketItem;
    public static Item rottenseedpacketItem;
    public static Item whitemushroomseedpacketItem;
    public static Item harvestwheatseedpacketItem;
    public static Item cottonseedpacketItem;
    public static Item candleberryseedpacketItem;
    public static Item cactusfruitseedpacketItem;
    public static Item radishseedpacketItem;
	public static Item celeryseedpacketItem;
	public static Item zucchiniseedpacketItem;
	public static Item chilipepperseedpacketItem;
	public static Item cantaloupeseedpacketItem;
	public static Item asparagusseedpacketItem;
	public static Item cranberryseedpacketItem;
	public static Item spiceleafseedpacketItem;

    public static Item tomatoseedboxItem;
    public static Item potatoseedboxItem;
    public static Item lettuceseedboxItem;
    public static Item onionseedboxItem;
    public static Item carrotseedboxItem;
    public static Item cornseedboxItem;
    public static Item strawberryseedboxItem;
    public static Item cucumberseedboxItem;
    public static Item riceseedboxItem;
    public static Item beansseedboxItem;
    public static Item bellpepperseedboxItem;
    public static Item eggplantseedboxItem;
    public static Item teaseedboxItem;
    public static Item coffeeseedboxItem;
    public static Item beetseedboxItem;
    public static Item broccoliseedboxItem;
    public static Item sweetpotatoseedboxItem;
    public static Item peasseedboxItem;
    public static Item pineappleseedboxItem;
    public static Item turnipseedboxItem;
    public static Item gingerseedboxItem;
    public static Item blueberryseedboxItem;
    public static Item blackberryseedboxItem;
    public static Item raspberryseedboxItem;
    public static Item kiwiseedboxItem;
    public static Item grapeseedboxItem;
    public static Item peanutseedboxItem;
    public static Item sunflowerseedboxItem;
    public static Item mustardseedboxItem;
    public static Item garlicseedboxItem;
    public static Item rottenseedboxItem;
    public static Item whitemushroomseedboxItem;
    public static Item harvestwheatseedboxItem;
    public static Item cottonseedboxItem;
    public static Item candleberryseedboxItem;
    public static Item cactusfruitseedboxItem;
    public static Item radishseedboxItem;
	public static Item celeryseedboxItem;
	public static Item zucchiniseedboxItem;
	public static Item chilipepperseedboxItem;
	public static Item cantaloupeseedboxItem;
	public static Item asparagusseedboxItem;
	public static Item cranberryseedboxItem;
	public static Item spiceleafseedboxItem;

    public static Item tomatoItem;
    public static Item potatoItem;
    public static Item lettuceItem;
    public static Item onionItem;
    public static Item carrotItem;
    public static Item cornItem;
    public static Item peanutItem;
    public static Item cucumberItem;
    public static Item riceItem;
    public static Item beansItem;
    public static Item bellpepperItem;
    public static Item eggplantItem;
    public static Item tealeafItem;
    public static Item coffeebeanItem;
    public static Item beetItem;
    public static Item broccoliItem;
    public static Item sweetpotatoItem;
    public static Item peasItem;
    public static Item pineappleItem;
    public static Item turnipItem;
    public static Item gingerItem;
    public static Item mustardseedsItem;
    public static Item garlicItem;
    public static Item harvestwheatItem;
    public static Item blueberryItem;
    public static Item blackberryItem;
    public static Item raspberryItem;
    public static Item kiwiItem;
    public static Item strawberryItem;
    public static Item grapeItem;
    public static Item sunflowerseedsItem;
    public static Item whitemushroomItem;
    public static Item cottonItem;
    public static Item candleberryItem;
    public static Item radishItem;
	public static Item celeryItem;
	public static Item zucchiniItem;
	public static Item chilipepperItem;
	public static Item cantaloupeItem;
	public static Item asparagusItem;
	public static Item cranberryItem;
	public static Item spiceleafItem;

    public static Item wovenclothItem;
    static EnumArmorMaterial armorCotton = EnumHelper.addArmorMaterial("COTTON", 5, new int[] {1, 3, 2, 1}, 15);
    public static Item cottonHelm;
    public static Item cottonChest;
    public static Item cottonLegs;
    public static Item cottonBoots;

    public static Item hardenedleatherItem;
    static EnumArmorMaterial armorHardenedLeather = EnumHelper.addArmorMaterial("HARDENEDLEATHER", 15, new int[] {2, 6, 5, 2}, 9);
    public static Item hardenedleatherHelm;
    public static Item hardenedleatherChest;
    public static Item hardenedleatherLegs;
    public static Item hardenedleatherBoots;
    
    public static  Item saltItem;
    public static  Item butterItem;
    public static  Item cheeseItem;
    public static  Item doughItem;
    public static  Item bakedpotatoItem;
    public static  Item butteredpotatoItem;
    public static  Item loadedpotatoItem;
    public static  Item friedeggsItem;
    public static  Item friedpotatoesItem;
    public static  Item saladItem;
    public static  Item saltedcookedfishItem;
    public static  Item pumpkinpieItem;
    public static  Item pizzaItem;
    public static  Item spagettiItem;
    public static  Item pastaItem;
    public static  Item friedonionringsItem;
    public static  Item applepieItem;
    public static  Item applesauceItem;
    public static  Item toastItem;
    public static  Item grilledcheeseItem;
    public static  Item bltsandwichItem;
    public static  Item macncheeseItem;
    public static  Item fishsticksItem;
    public static  Item mashedpotatoesItem;
    public static  Item fishsandwichItem;
    public static  Item cerealItem;
    public static  Item popcornItem;
    public static  Item butteredpopcornItem;
    public static  Item cornonthecobItem;
    public static  Item saltedpeanutsItem;
    public static  Item pbnjsandwichItem;
    public static  Item raisinsItem;
    public static  Item cornbreadmuffinsItem;
    public static  Item tacoItem;
    public static  Item nachosItem;
    public static  Item strawberrypieItem;
    public static  Item peanutbrittleItem;
    public static  Item chocolatebarItem;
    public static  Item driedappleslicesItem;
    public static  Item driedstrawberriesItem;
    public static  Item trailmixItem;
    public static  Item icecreamItem;
    public static  Item chocolateicecreamItem;
    public static  Item strawberryicecreamItem;
    public static  Item picklesItem;
    public static  Item chocolatecoveredfruitItem;
    public static  Item flourItem;
    public static  Item cornmealdoughItem;
    public static  Item cornmuffinmixItem;
    public static  Item tortillaItem;
    public static  Item bottleItem;
    public static  Item mayoItem;
    public static  Item vinegarItem;
    public static  Item peanutbutterItem;
    public static  Item grapejellyItem;
    public static  Item strawberryjamItem;
    public static  Item stockItem;
    public static  Item noodlesoupItem;
    public static  Item hambonesoupItem;
    public static  Item cheesesoupItem;
    public static  Item vegetablesoupItem;
    public static  Item onionsoupItem;
    public static  Item peanutsoupItem;
    public static  Item cucumbersoupItem;
    public static  Item carrotsoupItem;
    public static  Item pumpkinsoupItem;
    public static  Item wheatsoupItem;
    public static  Item potatosoupItem;
    public static  Item oatmealItem;
    public static  Item friedpicklesItem;
    public static  Item shepardpieItem;
    public static  Item strawberryiceItem;
    public static  Item sidesaladItem;
    public static  Item breakfastsandwichItem;
    public static  Item coleslawItem;
    public static  Item fishlettucewrapItem;
    public static  Item fishtacoItem;
    public static  Item porklettucewrapItem;
    public static  Item pastasaladItem;
    public static  Item potatosaladItem;
    public static  Item chocolatepeanutsItem;
    public static  Item pumpkinbreadItem;

    //Food
    public static  Item scrambledeggsItem;
    public static  Item omeletItem;
    public static  Item sushiItem;
    public static  Item porkfriedriceItem;
    public static  Item fiestariceItem;
    public static  Item stuffedpepperItem;
    public static  Item beansandriceItem;
    public static  Item ricecakeItem;
    public static  Item beanburritoItem;
    public static  Item chiliItem;
    public static  Item bakedbeansItem;
    public static  Item supremepizzaItem;
    public static  Item ricesoupItem;
    public static  Item veggiestirfryItem;
    public static  Item carrotpilafItem;
    public static  Item cornricemedleyItem;
    public static  Item mushroomrisottoItem;
    public static  Item refriedbeansItem;

    //ForageCraft Ingrediants
    public static  Item batterItem;
    public static  Item syrupItem;
    public static  Item berrysyrupItem;

    //ForageCraft Foods
    public static  Item wafflesItem;
    public static  Item fancywafflesItem;
    public static  Item pancakesItem;
    public static  Item fancypancakesItem;
    public static  Item frenchtoastItem;
    public static  Item berrysaladItem;
    public static  Item blueberrymuffinsItem;
    public static  Item raspberrytartItem;
    public static  Item blackberrycobblerItem;

    public static  Item peachcobblerItem;
    public static  Item cherrypieItem;
    public static  Item lemonpieItem;
    public static  Item bananasplitItem;
    public static  Item toastedcoconutItem;
    public static  Item fruitsaladItem;
    public static  Item fruitjuiceItem;
    public static  Item lemonaideItem;

    public static  Item grilledeggplantItem;
    public static  Item eggplantparmItem;
    public static  Item stuffedeggplantItem;
    public static  Item teaItem;
    public static  Item raspberryicedteaItem;
    public static  Item chaiteaItem;
    public static  Item coffeeItem;
    public static  Item mochaicecreamItem;
    public static  Item espressoItem;
    public static  Item pickledbeetsItem;
    public static  Item beetsaladItem;
    public static  Item beetsoupItem;
    public static  Item broccolimacItem;
    public static  Item broccolindipItem;
    public static  Item creamedbroccolisoupItem;
    public static  Item grilledsweetpotatoItem;
    public static  Item sweetpotatopieItem;
    public static  Item candiedsweetpotatoesItem;
    public static  Item marshmellowsItem;
    public static  Item splitpeasoupItem;
    public static  Item pineapplehamItem;
    public static  Item turnipsoupItem;
    public static  Item banananutbreadItem;

    public static  Item breadedchickenItem;
    public static  Item chickenparmItem;
    public static  Item chickensandwichItem;
    public static  Item chickennoodlesoupItem;
    public static  Item hamburgerItem;
    public static  Item cheeseburgerItem;
    public static  Item baconcheeseburgerItem;
    public static  Item spagettiandmeatballsItem;

    public static  Item curryriceItem;
    public static  Item donutItem;
    public static  Item chocolatedonutItem;
    public static  Item powdereddonutItem;
    public static  Item jellydonutItem;
    public static  Item frosteddonutItem;
    public static  Item seedsoupItem;
    public static  Item oliveoilItem;

    public static  Item spidereyesoupItem;
    public static  Item zombiejerkyItem;
    public static  Item gingerbreadItem;
    public static  Item gingersnapsItem;
    public static  Item candiedgingerItem;
    public static  Item saltedsunflowerseedsItem;
    public static  Item sunflowerwheatrollsItem;
    public static  Item sunflowerbroccolisaladItem;

    public static  Item mustardItem;
    public static  Item softpretzelItem;
    public static  Item softpretzelandmustardItem;
    public static  Item spicymustardporkItem;
    public static  Item spicymustardgreensItem;

    public static  Item veggiepizzaItem;
    public static  Item cheesecakeItem;
    public static  Item toppingcheesecakeItem;
    public static  Item chocolatecheesecakeItem;
    public static  Item pumpkincheesecakeItem;

    public static  Item barrelItem;
    public static  Item waterbarrelItem;
    public static  Item milkbarrelItem;

    public static  Item buttermilkItem;

    public static  Item cafeconlecheItem;

    public static  Item garlicmashedpotatoesItem;
    public static  Item garlicchickenItem;
    public static  Item garlictoastItem;
    
    public static  Item nutmegspiceItem;
    public static  Item vanillaItem;
    public static  Item blackpepperItem;
    public static  Item beeswaxItem;
    public static  Item pressedwaxItem;
    
    public static  Item cocoapowderItem;
    public static  Item powderedsugarItem;
    public static  Item tablesaltItem;
    public static  Item cornmealItem;
    public static  Item cinnamonspiceItem;
    public static  Item groundcoffeeItem;
    
    public static Item zincoreItem;
    public static Item tinoreItem;
    public static Item copperoreItem;
    public static Item silveroreItem;
    public static Item cobaltoreItem;
    public static Item platinumoreItem;
    public static Item titaniumoreItem;
    public static Item mithriloreItem;

    public static Item flawedquartzgemItem;
    public static Item flawedcitrinegemItem;
    public static Item flawedtanzanitegemItem;
    public static Item flawedsapphiregemItem;
    public static Item flawedtopazgemItem;
    public static Item flawedagategemItem;
    public static Item flawedgarnetgemItem;
    public static Item flawedhematitegemItem;
    public static Item flawedmoonstonegemItem;
    public static Item flawedaquamarinegemItem;
    public static Item flawedamethystgemItem;
    public static Item flawedtigerseyegemItem;
    public static Item flawedemeraldgemItem;
    public static Item flawedrubygemItem;
    public static Item flawedonyxgemItem;
    
    public static Item cutquartzgemItem;
    public static Item cutcitrinegemItem;
    public static Item cuttanzanitegemItem;
    public static Item cutsapphiregemItem;
    public static Item cuttopazgemItem;
    public static Item cutagategemItem;
    public static Item cutgarnetgemItem;
    public static Item cuthematitegemItem;
    public static Item cutmoonstonegemItem;
    public static Item cutaquamarinegemItem;
    public static Item cutamethystgemItem;
    public static Item cuttigerseyegemItem;
    public static Item cutemeraldgemItem;
    public static Item cutrubygemItem;
    public static Item cutonyxgemItem;
    public static Item cutlapislazuligemItem;
    
    public static Item refinedquartzgemItem;
    public static Item refinedcitrinegemItem;
    public static Item refinedtanzanitegemItem;
    public static Item refinedsapphiregemItem;
    public static Item refinedtopazgemItem;
    public static Item refinedagategemItem;
    public static Item refinedgarnetgemItem;
    public static Item refinedhematitegemItem;
    public static Item refinedmoonstonegemItem;
    public static Item refinedaquamarinegemItem;
    public static Item refinedamethystgemItem;
    public static Item refinedtigerseyegemItem;
    public static Item refinedemeraldgemItem;
    public static Item refinedrubygemItem;
    public static Item refinedonyxgemItem;
    public static Item refinedlapislazuligemItem;
    
    public static Item brilliantquartzgemItem;
    public static Item brilliantcitrinegemItem;
    public static Item brillianttanzanitegemItem;
    public static Item brilliantsapphiregemItem;
    public static Item brillianttopazgemItem;
    public static Item brilliantagategemItem;
    public static Item brilliantgarnetgemItem;
    public static Item brillianthematitegemItem;
    public static Item brilliantmoonstonegemItem;
    public static Item brilliantaquamarinegemItem;
    public static Item brilliantamethystgemItem;
    public static Item brillianttigerseyegemItem;
    public static Item brilliantemeraldgemItem;
    public static Item brilliantrubygemItem;
    public static Item brilliantonyxgemItem;
    public static Item brilliantlapislazuligemItem;
    
    public static Item perfectquartzgemItem;
    public static Item perfectcitrinegemItem;
    public static Item perfecttanzanitegemItem;
    public static Item perfectsapphiregemItem;
    public static Item perfecttopazgemItem;
    public static Item perfectagategemItem;
    public static Item perfectgarnetgemItem;
    public static Item perfecthematitegemItem;
    public static Item perfectmoonstonegemItem;
    public static Item perfectaquamarinegemItem;
    public static Item perfectamethystgemItem;
    public static Item perfecttigerseyegemItem;
    public static Item perfectemeraldgemItem;
    public static Item perfectrubygemItem;
    public static Item perfectonyxgemItem;
    public static Item perfectlapislazuligemItem;

    public static Item zincingotItem;
    public static Item tiningotItem;
    public static Item copperingotItem;
    public static Item silveringotItem;
    public static Item cobaltingotItem;
    public static Item platinumingotItem;
    public static Item titaniumingotItem;
    public static Item mithrilingotItem;

    public static Item bronzealloyItem;
    public static Item bronzeingotItem;
    public static Item steelalloyItem;
    public static Item steelingotItem;
    
    public static Item saltpeterItem;
    public static Item sulphurItem;

    public static Item copperPick;
    public static Item copperShovel;
    public static Item copperAxe;
    public static Item copperHoe;
    public static Item copperSword;
    public static Item copperHelm;
    public static Item copperChest;
    public static Item copperLegs;
    public static Item copperBoots;

    public static Item tinPick;
    public static Item tinShovel;
    public static Item tinAxe;
    public static Item tinHoe;
    public static Item tinSword;
    public static Item tinHelm;
    public static Item tinChest;
    public static Item tinLegs;
    public static Item tinBoots;

    public static Item bronzePick;
    public static Item bronzeShovel;
    public static Item bronzeAxe;
    public static Item bronzeHoe;
    public static Item bronzeSword;
    public static Item bronzeHelm;
    public static Item bronzeChest;
    public static Item bronzeLegs;
    public static Item bronzeBoots;

    public static Item silverPick;
    public static Item silverShovel;
    public static Item silverAxe;
    public static Item silverHoe;
    public static Item silverSword;
    public static Item silverHelm;
    public static Item silverChest;
    public static Item silverLegs;
    public static Item silverBoots;

    public static Item cobaltPick;
    public static Item cobaltShovel;
    public static Item cobaltAxe;
    public static Item cobaltHoe;
    public static Item cobaltSword;
    public static Item cobaltHelm;
    public static Item cobaltChest;
    public static Item cobaltLegs;
    public static Item cobaltBoots;

    public static Item steelPick;
    public static Item steelShovel;
    public static Item steelAxe;
    public static Item steelHoe;
    public static Item steelSword;
    public static Item steelHelm;
    public static Item steelChest;
    public static Item steelLegs;
    public static Item steelBoots;

    public static Item platinumPick;
    public static Item platinumShovel;
    public static Item platinumAxe;
    public static Item platinumHoe;
    public static Item platinumSword;
    public static Item platinumHelm;
    public static Item platinumChest;
    public static Item platinumLegs;
    public static Item platinumBoots;

    public static Item titaniumPick;
    public static Item titaniumShovel;
    public static Item titaniumAxe;
    public static Item titaniumHoe;
    public static Item titaniumSword;
    public static Item titaniumHelm;
    public static Item titaniumChest;
    public static Item titaniumLegs;
    public static Item titaniumBoots;

    public static Item mithrilPick;
    public static Item mithrilShovel;
    public static Item mithrilAxe;
    public static Item mithrilHoe;
    public static Item mithrilSword;
    public static Item mithrilHelm;
    public static Item mithrilChest;
    public static Item mithrilLegs;
    public static Item mithrilBoots;


    static EnumArmorMaterial armorCopper = EnumHelper.addArmorMaterial("COPPER", 7, new int[] {2, 5, 4, 1}, 25);
    static EnumArmorMaterial armorTin = EnumHelper.addArmorMaterial("TIN", 9, new int[] {2, 5, 4, 1}, 12);
    static EnumArmorMaterial armorBronze = EnumHelper.addArmorMaterial("BRONZE", 12, new int[] {2, 5, 4, 1}, 12);
    static EnumArmorMaterial armorSilver = EnumHelper.addArmorMaterial("SILVER", 7, new int[] {2, 6, 5, 2}, 25);
    static EnumArmorMaterial armorCobalt = EnumHelper.addArmorMaterial("COBALT", 19, new int[] {2, 6, 5, 2}, 9);
    static EnumArmorMaterial armorSteel = EnumHelper.addArmorMaterial("STEEL", 24, new int[] {2, 6, 5, 2}, 9);
    static EnumArmorMaterial armorPlatinum = EnumHelper.addArmorMaterial("PLATINUM", 7, new int[] {2, 6, 5, 2}, 25);
    static EnumArmorMaterial armorTitanium = EnumHelper.addArmorMaterial("TITANIUM", 29, new int[] {2, 6, 5, 2}, 9);
    static EnumArmorMaterial armorMithril = EnumHelper.addArmorMaterial("MITHRIL", 7, new int[] {3, 8, 6, 3}, 25);
    
    
    
    @Init
    public void load(FMLInitializationEvent event) 
    {
    	proxy.registerRenderThings();
    	
    	
    	
    	pamFlower = new BlockPamFlower(flowerID, 0);
    	pamdesertPlant = new BlockPamDesertPlant(desertplantID, 0);
    	pamtemperatePlant = new BlockPamTemperatePlant(temperateplantID, 0);
    	pamFruit = new BlockPamFruit(fruitID);
    	pamwarmFruit = new BlockPamWarmFruit(warmfruitID);
    	pamBush = new BlockPamBush(bushID, 0);
    	pamwarmBush = new BlockPamWarmBush(warmbushID, 0);
    	pamcoldBush = new BlockPamColdBush(coldbushID, 0);
    	pamMineral = new BlockPamMineral(mineralID, 0).setHardness(1.5F).setResistance(10F);
    	pamOre = new BlockPamOre(oreID, 0).setHardness(3F).setResistance(5F);
    	pamGem = new BlockPamGem(gemID, 0).setHardness(3F).setResistance(5F);
    	pamcoloredSmoothstone = new BlockPamColoredSmoothstone(coloredsmoothstoneID, 0).setHardness(1.5F).setResistance(10F);
    	pamSapling = new BlockPamSapling(saplingID, 0);
    	pamwarmSapling = new BlockPamWarmSapling(warmsaplingID, 0);
    	
    	pamcoloredPlank = new BlockPamColoredPlank(coloredplankID, 0).setHardness(2.0F).setResistance(5.0F);
    	pamcoloredwoodFence = new BlockPamColoredWoodFence(coloredwoodfenceID, 0).setHardness(2.0F).setResistance(5.0F);
    	pamcoloredwoodstairsWhite = (new BlockPamColoredStairs(coloredwoodstairswhiteID, pamcoloredPlank, 0)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsWhite");
    	pamcoloredwoodstairsOrange = (new BlockPamColoredStairs(coloredwoodstairsorangeID, pamcoloredPlank, 1)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsOrange");
    	pamcoloredwoodstairsMagenta = (new BlockPamColoredStairs(coloredwoodstairsmagentaID, pamcoloredPlank, 2)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsMagenta");
    	pamcoloredwoodstairsLightblue = (new BlockPamColoredStairs(coloredwoodstairslightblueID, pamcoloredPlank, 3)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsLightblue");
    	pamcoloredwoodstairsYellow = (new BlockPamColoredStairs(coloredwoodstairsyellowID, pamcoloredPlank, 4)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsYellow");
    	pamcoloredwoodstairsLime = (new BlockPamColoredStairs(coloredwoodstairslimeID, pamcoloredPlank, 5)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsLime");
    	pamcoloredwoodstairsPink = (new BlockPamColoredStairs(coloredwoodstairspinkID, pamcoloredPlank, 6)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsPink");
    	pamcoloredwoodstairsDarkgrey = (new BlockPamColoredStairs(coloredwoodstairsdarkgreyID, pamcoloredPlank, 7)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsDarkgrey");
    	pamcoloredwoodstairsLightgrey = (new BlockPamColoredStairs(coloredwoodstairslightgreyID, pamcoloredPlank, 8)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsLightgrey");
    	pamcoloredwoodstairsCyan = (new BlockPamColoredStairs(coloredwoodstairscyanID, pamcoloredPlank, 9)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsCyan");
    	pamcoloredwoodstairsPurple = (new BlockPamColoredStairs(coloredwoodstairspurpleID, pamcoloredPlank, 10)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsPurple");
    	pamcoloredwoodstairsBlue = (new BlockPamColoredStairs(coloredwoodstairsblueID, pamcoloredPlank, 11)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsBlue");
    	pamcoloredwoodstairsBrown = (new BlockPamColoredStairs(coloredwoodstairsbrownID, pamcoloredPlank, 12)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsBrown");
    	pamcoloredwoodstairsGreen = (new BlockPamColoredStairs(coloredwoodstairsgreenID, pamcoloredPlank, 13)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsGreen");
    	pamcoloredwoodstairsRed = (new BlockPamColoredStairs(coloredwoodstairsredID, pamcoloredPlank, 14)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsRed");
    	pamcoloredwoodstairsBlack = (new BlockPamColoredStairs(coloredwoodstairsblackID, pamcoloredPlank, 15)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodstairsBlack");
    	pamcoloredwoodslabWhite = (new BlockPamColoredWoodSlab(coloredwoodslabwhiteID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabWhite");
    	pamcoloredwoodslabOrange = (new BlockPamColoredWoodSlab(coloredwoodslaborangeID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabOrange");
    	pamcoloredwoodslabMagenta = (new BlockPamColoredWoodSlab(coloredwoodslabmagentaID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabMagenta");
    	pamcoloredwoodslabLightblue = (new BlockPamColoredWoodSlab(coloredwoodslablightblueID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabLightblue");
    	pamcoloredwoodslabYellow = (new BlockPamColoredWoodSlab(coloredwoodslabyellowID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabYellow");
    	pamcoloredwoodslabLime = (new BlockPamColoredWoodSlab(coloredwoodslablimeID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabLime");
    	pamcoloredwoodslabPink = (new BlockPamColoredWoodSlab(coloredwoodslabpinkID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabPink");
    	pamcoloredwoodslabDarkgrey = (new BlockPamColoredWoodSlab(coloredwoodslabdarkgreyID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabDarkgrey");
    	pamcoloredwoodslabLightgrey = (new BlockPamColoredWoodSlab(coloredwoodslablightgreyID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabLightgrey");
    	pamcoloredwoodslabCyan = (new BlockPamColoredWoodSlab(coloredwoodslabcyanID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabCyan");
    	pamcoloredwoodslabPurple = (new BlockPamColoredWoodSlab(coloredwoodslabpurpleID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabPurple");
    	pamcoloredwoodslabBlue = (new BlockPamColoredWoodSlab(coloredwoodslabblueID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabBlue");
    	pamcoloredwoodslabBrown = (new BlockPamColoredWoodSlab(coloredwoodslabbrownID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabBrown");
    	pamcoloredwoodslabGreen = (new BlockPamColoredWoodSlab(coloredwoodslabgreenID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabGreen");
    	pamcoloredwoodslabRed = (new BlockPamColoredWoodSlab(coloredwoodslabredID, false)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodslabRed");
    	pamcoloredwoodslabBlack = (new BlockPamColoredWoodSlab(coloredwoodslabblackID, false)).setBlockName("pamcoloredwoodslabBlack");
    	pamcoloredwoodThin = new BlockPamColoredWoodThin(coloredwoodthinID, 0).setHardness(2.0F).setResistance(5.0F);
    	pamcoloredwoodfencegateWhite = (new BlockPamColoredWoodFencegate(coloredwoodfencegatewhiteID, 0)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateWhite");
    	pamcoloredwoodfencegateOrange = (new BlockPamColoredWoodFencegate(coloredwoodfencegateorangeID, 1)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateOrange");
    	pamcoloredwoodfencegateMagenta = (new BlockPamColoredWoodFencegate(coloredwoodfencegatemagentaID, 2)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateMagenta");
    	pamcoloredwoodfencegateLightblue = (new BlockPamColoredWoodFencegate(coloredwoodfencegatelightblueID, 3)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateLightblue");
    	pamcoloredwoodfencegateYellow = (new BlockPamColoredWoodFencegate(coloredwoodfencegateyellowID, 4)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateYellow");
    	pamcoloredwoodfencegateLime = (new BlockPamColoredWoodFencegate(coloredwoodfencegatelimeID, 5)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateLime");
    	pamcoloredwoodfencegatePink = (new BlockPamColoredWoodFencegate(coloredwoodfencegatepinkID, 6)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegatePink");
    	pamcoloredwoodfencegateDarkgrey = (new BlockPamColoredWoodFencegate(coloredwoodfencegatedarkgreyID, 7)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateDarkgrey");
    	pamcoloredwoodfencegateLightgrey = (new BlockPamColoredWoodFencegate(coloredwoodfencegatelightgreyID, 8)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateLightgrey");
    	pamcoloredwoodfencegateCyan = (new BlockPamColoredWoodFencegate(coloredwoodfencegatecyanID, 9)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateCyan");
    	pamcoloredwoodfencegatePurple = (new BlockPamColoredWoodFencegate(coloredwoodfencegatepurpleID, 10)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegatePurple");
    	pamcoloredwoodfencegateBlue = (new BlockPamColoredWoodFencegate(coloredwoodfencegateblueID, 11)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateBlue");
    	pamcoloredwoodfencegateBrown = (new BlockPamColoredWoodFencegate(coloredwoodfencegatebrownID, 12)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateBrown");
    	pamcoloredwoodfencegateGreen = (new BlockPamColoredWoodFencegate(coloredwoodfencegategreenID, 13)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateGreen");
    	pamcoloredwoodfencegateRed = (new BlockPamColoredWoodFencegate(coloredwoodfencegateredID, 14)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateRed");
    	pamcoloredwoodfencegateBlack = (new BlockPamColoredWoodFencegate(coloredwoodfencegateblackID, 15)).setHardness(2.0F).setResistance(5.0F).setBlockName("pamcoloredwoodfencegateBlack");
    	
    	pamcoloredCobblestone = new BlockPamColoredCobblestone(coloredcobblestoneID, 0).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredCobblestone");
    	pamcoloredcobblestonestairsWhite = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairswhiteID, pamcoloredCobblestone, 0)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsWhite");
    	pamcoloredcobblestonestairsOrange = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsorangeID, pamcoloredCobblestone, 1)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsOrange");
    	pamcoloredcobblestonestairsMagenta = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsmagentaID, pamcoloredCobblestone, 2)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsMagenta");
    	pamcoloredcobblestonestairsLightblue = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairslightblueID, pamcoloredCobblestone, 3)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsLightblue");
    	pamcoloredcobblestonestairsYellow = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsyellowID, pamcoloredCobblestone, 4)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsYellow");
    	pamcoloredcobblestonestairsLime = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairslimeID, pamcoloredCobblestone, 5)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsLime");
    	pamcoloredcobblestonestairsPink = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairspinkID, pamcoloredCobblestone, 6)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsPink");
    	pamcoloredcobblestonestairsDarkgrey = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsdarkgreyID, pamcoloredCobblestone, 7)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsDarkgrey");
    	pamcoloredcobblestonestairsLightgrey = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairslightgreyID, pamcoloredCobblestone, 8)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsLightgrey");
    	pamcoloredcobblestonestairsCyan = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairscyanID, pamcoloredCobblestone, 9)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsCyan");
    	pamcoloredcobblestonestairsPurple = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairspurpleID, pamcoloredCobblestone, 10)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsPurple");
    	pamcoloredcobblestonestairsBlue = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsblueID, pamcoloredCobblestone, 11)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsBlue");
    	pamcoloredcobblestonestairsBrown = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsbrownID, pamcoloredCobblestone, 12)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsBrown");
    	pamcoloredcobblestonestairsGreen = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsgreenID, pamcoloredCobblestone, 13)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsGreen");
    	pamcoloredcobblestonestairsRed = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsredID, pamcoloredCobblestone, 14)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsRed");
    	pamcoloredcobblestonestairsBlack = (new BlockPamColoredCobblestoneStairs(coloredcobblestonestairsblackID, pamcoloredCobblestone, 15)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestonestairsBlack");
    	pamcoloredcobblestoneslabWhite = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabwhiteID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabWhite");
    	pamcoloredcobblestoneslabOrange = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslaborangeID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabOrange");
    	pamcoloredcobblestoneslabMagenta = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabmagentaID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabMagenta");
    	pamcoloredcobblestoneslabLightblue = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslablightblueID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabLightblue");
    	pamcoloredcobblestoneslabYellow = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabyellowID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabYellow");
    	pamcoloredcobblestoneslabLime = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslablimeID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabLime");
    	pamcoloredcobblestoneslabPink = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabpinkID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabPink");
    	pamcoloredcobblestoneslabDarkgrey = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabdarkgreyID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabDarkgrey");
    	pamcoloredcobblestoneslabLightgrey = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslablightgreyID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabLightgrey");
    	pamcoloredcobblestoneslabCyan = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabcyanID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabCyan");
    	pamcoloredcobblestoneslabPurple = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabpurpleID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabPurple");
    	pamcoloredcobblestoneslabBlue = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabblueID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabBlue");
    	pamcoloredcobblestoneslabBrown = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabbrownID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabBrown");
    	pamcoloredcobblestoneslabGreen = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabgreenID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabGreen");
    	pamcoloredcobblestoneslabRed = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabredID, false)).setHardness(2.0F).setResistance(10.0F).setBlockName("pamcoloredcobblestoneslabRed");
    	pamcoloredcobblestoneslabBlack = (new BlockPamColoredCobblestoneSlab(coloredcobblestoneslabblackID, false)).setBlockName("pamcoloredcobblestoneslabBlack");
    	pamcoloredcobblestoneThin = new BlockPamColoredCobblestoneThin(coloredcobblestonethinID, 0).setHardness(2.0F).setResistance(10.0F);
    	
    	pamcoloredclothstairsWhite = (new BlockPamColoredClothStairs(coloredclothstairswhiteID, Block.cloth, 0)).setHardness(0.8F).setBlockName("pamcoloredclothstairsWhite");
    	pamcoloredclothstairsOrange = (new BlockPamColoredClothStairs(coloredclothstairsorangeID, Block.cloth, 1)).setHardness(0.8F).setBlockName("pamcoloredclothstairsOrange");
    	pamcoloredclothstairsMagenta = (new BlockPamColoredClothStairs(coloredclothstairsmagentaID, Block.cloth, 2)).setHardness(0.8F).setBlockName("pamcoloredclothstairsMagenta");
    	pamcoloredclothstairsLightblue = (new BlockPamColoredClothStairs(coloredclothstairslightblueID, Block.cloth, 3)).setHardness(0.8F).setBlockName("pamcoloredclothstairsLightblue");
    	pamcoloredclothstairsYellow = (new BlockPamColoredClothStairs(coloredclothstairsyellowID, Block.cloth, 4)).setHardness(0.8F).setBlockName("pamcoloredclothstairsYellow");
    	pamcoloredclothstairsLime = (new BlockPamColoredClothStairs(coloredclothstairslimeID, Block.cloth, 5)).setHardness(0.8F).setBlockName("pamcoloredclothstairsLime");
    	pamcoloredclothstairsPink = (new BlockPamColoredClothStairs(coloredclothstairspinkID, Block.cloth, 6)).setHardness(0.8F).setBlockName("pamcoloredclothstairsPink");
    	pamcoloredclothstairsDarkgrey = (new BlockPamColoredClothStairs(coloredclothstairsdarkgreyID, Block.cloth, 7)).setHardness(0.8F).setBlockName("pamcoloredclothstairsDarkgrey");
    	pamcoloredclothstairsLightgrey = (new BlockPamColoredClothStairs(coloredclothstairslightgreyID, Block.cloth, 8)).setHardness(0.8F).setBlockName("pamcoloredclothstairsLightgrey");
    	pamcoloredclothstairsCyan = (new BlockPamColoredClothStairs(coloredclothstairscyanID, Block.cloth, 9)).setHardness(0.8F).setBlockName("pamcoloredclothstairsCyan");
    	pamcoloredclothstairsPurple = (new BlockPamColoredClothStairs(coloredclothstairspurpleID, Block.cloth, 10)).setHardness(0.8F).setBlockName("pamcoloredclothstairsPurple");
    	pamcoloredclothstairsBlue = (new BlockPamColoredClothStairs(coloredclothstairsblueID, Block.cloth, 11)).setHardness(0.8F).setBlockName("pamcoloredclothstairsBlue");
    	pamcoloredclothstairsBrown = (new BlockPamColoredClothStairs(coloredclothstairsbrownID, Block.cloth, 12)).setHardness(0.8F).setBlockName("pamcoloredclothstairsBrown");
    	pamcoloredclothstairsGreen = (new BlockPamColoredClothStairs(coloredclothstairsgreenID, Block.cloth, 13)).setHardness(0.8F).setBlockName("pamcoloredclothstairsGreen");
    	pamcoloredclothstairsRed = (new BlockPamColoredClothStairs(coloredclothstairsredID, Block.cloth, 14)).setHardness(0.8F).setBlockName("pamcoloredclothstairsRed");
    	pamcoloredclothstairsBlack = (new BlockPamColoredClothStairs(coloredclothstairsblackID, Block.cloth, 15)).setHardness(0.8F).setBlockName("pamcoloredclothstairsBlack");
    	pamcoloredclothslabWhite = (new BlockPamColoredClothSlab(coloredclothslabwhiteID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabWhite");
    	pamcoloredclothslabOrange = (new BlockPamColoredClothSlab(coloredclothslaborangeID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabOrange");
    	pamcoloredclothslabMagenta = (new BlockPamColoredClothSlab(coloredclothslabmagentaID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabMagenta");
    	pamcoloredclothslabLightblue = (new BlockPamColoredClothSlab(coloredclothslablightblueID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabLightblue");
    	pamcoloredclothslabYellow = (new BlockPamColoredClothSlab(coloredclothslabyellowID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabYellow");
    	pamcoloredclothslabLime = (new BlockPamColoredClothSlab(coloredclothslablimeID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabLime");
    	pamcoloredclothslabPink = (new BlockPamColoredClothSlab(coloredclothslabpinkID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabPink");
    	pamcoloredclothslabDarkgrey = (new BlockPamColoredClothSlab(coloredclothslabdarkgreyID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabDarkgrey");
    	pamcoloredclothslabLightgrey = (new BlockPamColoredClothSlab(coloredclothslablightgreyID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabLightgrey");
    	pamcoloredclothslabCyan = (new BlockPamColoredClothSlab(coloredclothslabcyanID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabCyan");
    	pamcoloredclothslabPurple = (new BlockPamColoredClothSlab(coloredclothslabpurpleID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabPurple");
    	pamcoloredclothslabBlue = (new BlockPamColoredClothSlab(coloredclothslabblueID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabBlue");
    	pamcoloredclothslabBrown = (new BlockPamColoredClothSlab(coloredclothslabbrownID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabBrown");
    	pamcoloredclothslabGreen = (new BlockPamColoredClothSlab(coloredclothslabgreenID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabGreen");
    	pamcoloredclothslabRed = (new BlockPamColoredClothSlab(coloredclothslabredID, false)).setHardness(0.8F).setBlockName("pamcoloredclothslabRed");
    	pamcoloredclothslabBlack = (new BlockPamColoredClothSlab(coloredclothslabblackID, false)).setBlockName("pamcoloredclothslabBlack");
    	pamcoloredclothThin = new BlockPamColoredClothThin(coloredcloththinID, 0).setHardness(0.8F);
    	
        pammetalBlock = new BlockPamMetalBlock(metalblockID, 0).setHardness(5.0F).setResistance(10.0F).setBlockName("pammetalBlock");
        pamgemBlock = new BlockPamGemBlock(gemblockID, 0).setHardness(5.0F).setResistance(10.0F).setBlockName("pamgemBlock");
        pamcoloredClay = new BlockPamColoredClay(coloredclayID, 0).setHardness(0.6F).setBlockName("pamcoloredClay");
        pamcoloredSand = new BlockPamColoredSand(coloredsandID, 0).setHardness(0.5F).setBlockName("pamcoloredSand");
        pamcoloredBookshelf = new BlockPamColoredBookshelf(coloredbookshelfID, 0).setHardness(1.5F).setBlockName("pamcoloredBookshelf");
        pamcoloredLeaves = new BlockPamColoredLeaves(coloredleavesID, 0).setHardness(0.2F).setLightOpacity(1).setBlockName("pamcoloredLeaves");
        pamcoloredWood = new BlockPamColoredWood(coloredwoodID, 0).setHardness(2.0F).setBlockName("pamcoloredWood");
        pamstonePaver = new BlockPamStonePaver(stonepaverID, 0).setHardness(2.0F).setResistance(10.0F).setBlockName("pamstonePaver");
        pamWindow = new BlockPamWindow(windowID, 0, Material.glass, false).setHardness(0.3F).setBlockName("pamWindow");
        pamcoloredGlass = new BlockPamColoredGlass(coloredglassID, 0, Material.glass, false).setHardness(0.3F).setBlockName("pamcoloredGlass");
    	
        pamChurn = (new BlockPamChurn(churnID, false)).setHardness(2.0F).setResistance(10.0F).setStepSound(Block.soundWoodFootstep).setBlockName("pamChurn").setCreativeTab(CreativeTabs.tabDeco); // ADDED
        pamQuern = (new BlockPamQuern(quernID, false)).setHardness(2.0F).setResistance(10.0F).setStepSound(Block.soundStoneFootstep).setBlockName("pamQuern").setCreativeTab(CreativeTabs.tabDeco); // ADDED
        
        pamcropboxOne = new BlockPamCropBoxOne(cropboxoneID, 0).setHardness(0.2F).setBlockName("pamcropboxOne");
        
    	MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamMineral, "pickaxe", 0);
    	MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamOre, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamGem, "pickaxe", 2);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredSmoothstone, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredPlank, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodFence, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsWhite, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsOrange, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsMagenta, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsLightblue, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsYellow, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsLime, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsPink, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsDarkgrey, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsLightgrey, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsCyan, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsPurple, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsBlue, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsBrown, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsGreen, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsRed, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodstairsBlack, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabWhite, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabOrange, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabMagenta, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabLightblue, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabYellow, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabLime, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabPink, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabDarkgrey, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabLightgrey, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabCyan, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabPurple, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabBlue, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabBrown, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabGreen, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabRed, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodslabBlack, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodThin, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateWhite, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateOrange, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateMagenta, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateLightblue, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateYellow, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateLime, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegatePink, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateDarkgrey, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateLightgrey, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateCyan, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegatePurple, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateBlue, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateBrown, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateGreen, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateRed, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredwoodfencegateBlack, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredCobblestone, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsWhite, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsOrange, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsMagenta, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsLightblue, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsYellow, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsLime, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsPink, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsDarkgrey, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsLightgrey, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsCyan, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsPurple, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsBlue, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsBrown, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsGreen, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsRed, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestonestairsBlack, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabWhite, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabOrange, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabMagenta, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabLightblue, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabYellow, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabLime, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabPink, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabDarkgrey, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabLightgrey, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabCyan, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabPurple, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabBlue, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabBrown, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabGreen, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabRed, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneslabBlack, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredcobblestoneThin, "pickaxe", 0);
        
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pammetalBlock, "pickaxe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamgemBlock, "pickaxe", 2);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredClay, "spade", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredSand, "spade", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredBookshelf, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamcoloredWood, "axe", 0);
        MinecraftForge.setBlockHarvestLevel(Pamcombinedmod.pamstonePaver, "pickaxe", 0);
    	
    	pamwhiteflowerCrop = new BlockPamWhiteFlowerCrop(cropbaseID, 0);
    	pamorangeflowerCrop = new BlockPamOrangeFlowerCrop(cropbaseID + 1, 0);
    	pammagentaflowerCrop = new BlockPamMagentaFlowerCrop(cropbaseID + 2, 0);
    	pamlightblueflowerCrop = new BlockPamLightBlueFlowerCrop(cropbaseID + 3, 0);
    	pamyellowflowerCrop = new BlockPamYellowFlowerCrop(cropbaseID + 4, 0);
    	pamlimeflowerCrop = new BlockPamLimeFlowerCrop(cropbaseID + 5, 0);
    	pampinkflowerCrop = new BlockPamPinkFlowerCrop(cropbaseID + 6, 0);
    	pamlightgreyflowerCrop = new BlockPamLightGreyFlowerCrop(cropbaseID + 7, 0);
    	pamdarkgreyflowerCrop = new BlockPamDarkGreyFlowerCrop(cropbaseID + 8, 0);
    	pamcyanflowerCrop = new BlockPamCyanFlowerCrop(cropbaseID + 9, 0);
    	pampurpleflowerCrop = new BlockPamPurpleFlowerCrop(cropbaseID + 10, 0);
    	pamblueflowerCrop = new BlockPamBlueFlowerCrop(cropbaseID + 11, 0);
    	pambrownflowerCrop = new BlockPamBrownFlowerCrop(cropbaseID + 12, 0);
    	pamgreenflowerCrop = new BlockPamGreenFlowerCrop(cropbaseID + 13, 0);
    	pamredflowerCrop = new BlockPamRedFlowerCrop(cropbaseID + 14, 0);
    	pamblackflowerCrop = new BlockPamBlackFlowerCrop(cropbaseID + 15, 0);
    	
    	pamtomatoCrop = new BlockPamTomatoCrop(cropbaseID + 16, 0);
    	pampotatoCrop = new BlockPamPotatoCrop(cropbaseID + 17, 0);
    	pamlettuceCrop = new BlockPamLettuceCrop(cropbaseID + 18, 0);
    	pamonionCrop = new BlockPamOnionCrop(cropbaseID + 19, 0);
    	pamcarrotCrop = new BlockPamCarrotCrop(cropbaseID + 20, 0);
    	pamcornCrop = new BlockPamCornCrop(cropbaseID + 21, 0);
    	pampeanutCrop = new BlockPamPeanutCrop(cropbaseID + 22, 0);
    	pamcucumberCrop = new BlockPamCucumberCrop(cropbaseID + 23, 0);
    	pamriceCrop = new BlockPamRiceCrop(cropbaseID + 24, 0);
    	pambeansCrop = new BlockPamBeansCrop(cropbaseID + 25, 0);
    	pambellpepperCrop = new BlockPamBellpepperCrop(cropbaseID + 26, 0);
    	pameggplantCrop = new BlockPamEggplantCrop(cropbaseID + 27, 0);
    	pamteaCrop = new BlockPamTeaCrop(cropbaseID + 28, 0);
    	pamcoffeeCrop = new BlockPamCoffeeCrop(cropbaseID + 29, 0);
    	pambeetCrop = new BlockPamBeetCrop(cropbaseID + 30, 0);
    	pambroccoliCrop = new BlockPamBroccoliCrop(cropbaseID + 31, 0);
    	pamsweetpotatoCrop = new BlockPamSweetPotatoCrop(cropbaseID + 32, 0);
    	pampeasCrop = new BlockPamPeasCrop(cropbaseID + 33, 0);
    	pampineappleCrop = new BlockPamPineappleCrop(cropbaseID + 34, 0);
    	pamturnipCrop = new BlockPamTurnipCrop(cropbaseID + 35, 0);
    	pamgingerCrop = new BlockPamGingerCrop(cropbaseID + 36, 0);
    	pammustardCrop = new BlockPamMustardCrop(cropbaseID + 37, 0);
    	pamgarlicCrop = new BlockPamGarlicCrop(cropbaseID + 38, 0);
    	pamrottenmeatCrop = new BlockPamRottenmeatCrop(cropbaseID + 39, 0);
    	pamharvestwheatCrop = new BlockPamHarvestwheatCrop(cropbaseID + 40, 0);
    	pamblueberryCrop = new BlockPamBlueberryCrop(cropbaseID + 41, 0);
    	pamblackberryCrop = new BlockPamBlackberryCrop(cropbaseID + 42, 0);
    	pamraspberryCrop = new BlockPamRaspberryCrop(cropbaseID + 43, 0);
    	pamkiwiCrop = new BlockPamKiwiCrop(cropbaseID + 44, 0);
    	pamstrawberryCrop = new BlockPamStrawberryCrop(cropbaseID + 45, 0);
    	pamgrapeCrop = new BlockPamGrapeCrop(cropbaseID + 46, 0);
    	pamsunflowerCrop = new BlockPamSunflowerCrop(cropbaseID + 47, 0);
    	pamwhitemushroomCrop = new BlockPamWhitemushroomCrop(cropbaseID + 48, 0);
    	pamcottonCrop = new BlockPamCottonCrop(cropbaseID + 49, 0);
    	pamcandleberryCrop = new BlockPamCandleberryCrop(cropbaseID + 50, 0);
    	pamcactusfruitCrop = new BlockPamCactusfruitCrop(cropbaseID + 51, 0);
    	pamradishCrop = new BlockPamRadishCrop(cropbaseID + 52, 0);
    	pamceleryCrop = new BlockPamCeleryCrop(cropbaseID + 53, 0);
    	pamzucchiniCrop = new BlockPamZucchiniCrop(cropbaseID + 54, 0);
    	pamchilipepperCrop = new BlockPamChilipepperCrop(cropbaseID + 55, 0);
    	pamcantaloupeCrop = new BlockPamCantaloupeCrop(cropbaseID + 56, 0);
    	pamasparagusCrop = new BlockPamAsparagusCrop(cropbaseID + 57, 0);
    	pamcranberryCrop = new BlockPamCranberryCrop(cropbaseID + 58, 0);
    	pamspiceleafCrop = new BlockPamSpiceleafCrop(cropbaseID + 59, 0);
    	
    	//Across, Down
    	whiteflowerseedItem = new ItemPamSeeds(itembaseID, Pamcombinedmod.pamwhiteflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(0, 12).setItemName("whiteflowerseedItem");
        orangeflowerseedItem = new ItemPamSeeds(itembaseID + 1, Pamcombinedmod.pamorangeflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(1, 12).setItemName("orangeflowerseedItem");
        magentaflowerseedItem = new ItemPamSeeds(itembaseID + 2, Pamcombinedmod.pammagentaflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(2, 12).setItemName("magentaflowerseedItem");
        lightblueflowerseedItem = new ItemPamSeeds(itembaseID + 3, Pamcombinedmod.pamlightblueflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(3, 12).setItemName("lightblueflowerseedItem");
        yellowflowerseedItem = new ItemPamSeeds(itembaseID + 4, Pamcombinedmod.pamyellowflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(4, 12).setItemName("yellowflowerseedItem");
        limeflowerseedItem = new ItemPamSeeds(itembaseID + 5, Pamcombinedmod.pamlimeflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(5, 12).setItemName("limeflowerseedItem");
        pinkflowerseedItem = new ItemPamSeeds(itembaseID + 6, Pamcombinedmod.pampinkflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(6, 12).setItemName("pinkflowerseedItem");
        lightgreyflowerseedItem = new ItemPamSeeds(itembaseID + 7, Pamcombinedmod.pamlightgreyflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(7, 12).setItemName("greyflowerseedItem");
        darkgreyflowerseedItem = new ItemPamSeeds(itembaseID + 8, Pamcombinedmod.pamdarkgreyflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(8, 12).setItemName("lightgreyflowerseedItem");
        cyanflowerseedItem = new ItemPamSeeds(itembaseID + 9, Pamcombinedmod.pamcyanflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(9, 12).setItemName("cyanflowerseedItem");
        purpleflowerseedItem = new ItemPamSeeds(itembaseID + 10, Pamcombinedmod.pampurpleflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(10, 12).setItemName("purpleflowerseedItem");
        blueflowerseedItem = new ItemPamSeeds(itembaseID + 11, Pamcombinedmod.pamblueflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(11, 12).setItemName("blueflowerseedItem");
        brownflowerseedItem = new ItemPamSeeds(itembaseID + 12, Pamcombinedmod.pambrownflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(12, 12).setItemName("brownflowerseedItem");
        greenflowerseedItem = new ItemPamSeeds(itembaseID + 13, Pamcombinedmod.pamgreenflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(13, 12).setItemName("greenflowerseedItem");
        redflowerseedItem = new ItemPamSeeds(itembaseID + 14, Pamcombinedmod.pamredflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(14, 12).setItemName("redflowerseedItem");
        blackflowerseedItem = new ItemPamSeeds(itembaseID + 15, Pamcombinedmod.pamblackflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(15, 12).setItemName("blackflowerseedItem");
    	
    	cactusPick = new ItemPamPickaxe(itembaseID + 16, EnumToolMaterial.WOOD).setIconCoord(6, 0).setItemName("cactusPick");
        cactusShovel = new ItemPamSpade(itembaseID + 17, EnumToolMaterial.WOOD).setIconCoord(7, 0).setItemName("cactusShovel");
        cactusAxe = new ItemPamAxe(itembaseID + 18, EnumToolMaterial.WOOD).setIconCoord(4, 0).setItemName("cactusAxe");
        cactusHoe = new ItemPamHoe(itembaseID + 19, EnumToolMaterial.WOOD).setIconCoord(5, 0).setItemName("cactusHoe");
        cactusSword = new ItemPamSword(itembaseID + 20, EnumToolMaterial.WOOD).setIconCoord(8, 0).setItemName("cactusSword");
        sandstonePick = new ItemPamPickaxe(itembaseID + 21, EnumToolMaterial.STONE).setIconCoord(6, 1).setItemName("sandstonePick");
        sandstoneShovel = new ItemPamSpade(itembaseID + 22, EnumToolMaterial.STONE).setIconCoord(7, 1).setItemName("sandstoneShovel");
        sandstoneAxe = new ItemPamAxe(itembaseID + 23, EnumToolMaterial.STONE).setIconCoord(4, 1).setItemName("sandstoneAxe");
        sandstoneHoe = new ItemPamHoe(itembaseID + 24, EnumToolMaterial.STONE).setIconCoord(5, 1).setItemName("sandstoneHoe");
        sandstoneSword = new ItemPamSword(itembaseID + 25, EnumToolMaterial.STONE).setIconCoord(8, 1).setItemName("sandstoneSword");
        glasssteelPick = new ItemPamPickaxe(itembaseID + 26, EnumToolMaterial.GOLD).setIconCoord(11, 1).setItemName("glasssteelPick");
        glasssteelShovel = new ItemPamSpade(itembaseID + 27, EnumToolMaterial.GOLD).setIconCoord(12, 1).setItemName("glasssteelShovel");
        glasssteelAxe = new ItemPamAxe(itembaseID + 28, EnumToolMaterial.GOLD).setIconCoord(9, 1).setItemName("glasssteelAxe");
        glasssteelHoe = new ItemPamHoe(itembaseID + 29, EnumToolMaterial.GOLD).setIconCoord(10, 1).setItemName("glasssteelHoe");
        glasssteelSword = new ItemPamSword(itembaseID + 30, EnumToolMaterial.GOLD).setIconCoord(13, 1).setItemName("glasssteelSword");
        cactusstickItem  = new ItemPamCraftingMats(itembaseID + 31).setIconCoord(1, 0).setItemName("cactusstickItem");
        glasssteelItem = new ItemPamCraftingMats(itembaseID + 32).setIconCoord(2, 0).setItemName("glasssteelItem");
        cactusfruitItem = new ItemPamFoodCrops(itembaseID + 33, 4, 0.4F, false).setIconCoord(10, 8).setItemName("cactusfruitItem");
        cactusfruitseedItem = new ItemPamSeeds(itembaseID + 34, Pamcombinedmod.pamcactusfruitCrop.blockID, Block.sand.blockID).setIconCoord(10, 9).setItemName("cactusfruitseedItem");
    	
    	bonePick = new ItemPamPickaxe(itembaseID + 35, EnumToolMaterial.IRON).setIconCoord(11, 2).setItemName("bonePick");
        boneShovel = new ItemPamSpade(itembaseID + 36, EnumToolMaterial.IRON).setIconCoord(12, 2).setItemName("boneShovel");
        boneAxe = new ItemPamAxe(itembaseID + 37, EnumToolMaterial.IRON).setIconCoord(9, 2).setItemName("boneAxe");
        boneHoe = new ItemPamHoe(itembaseID + 38, EnumToolMaterial.IRON).setIconCoord(10, 2).setItemName("boneHoe");
        boneSword = new ItemPamSword(itembaseID + 39, EnumToolMaterial.IRON).setIconCoord(13, 2).setItemName("boneSword");
        boneHelm = (new ItemPamArmorBo(itembaseID + 40, armorBone, 5, 0).setIconCoord(11, 0).setItemName("boneHelm"));
        boneChest = (new ItemPamArmorBo(itembaseID + 41, armorBone, 5, 1).setIconCoord(10, 0).setItemName("boneChest"));
        boneLegs = (new ItemPamArmorBo(itembaseID + 42, armorBone, 5, 2).setIconCoord(12, 0).setItemName("boneLegs"));
        boneBoots = (new ItemPamArmorBo(itembaseID + 43, armorBone, 5, 3).setIconCoord(9, 0).setItemName("boneBoots"));
    	
    	wovenclothItem = new ItemPamCraftingMats(itembaseID + 44).setIconCoord(0, 0).setItemName("wovenclothItem");
        cottonHelm = (new ItemPamArmorCl(itembaseID + 45, armorCotton, 6, 0).setIconCoord(2, 0).setItemName("cottonHelm"));
        cottonChest = (new ItemPamArmorCl(itembaseID + 46, armorCotton, 6, 1).setIconCoord(1, 0).setItemName("cottonChest"));
        cottonLegs = (new ItemPamArmorCl(itembaseID + 47, armorCotton, 6, 2).setIconCoord(3, 0).setItemName("cottonLegs"));
        cottonBoots = (new ItemPamArmorCl(itembaseID + 48, armorCotton, 6, 3).setIconCoord(0, 0).setItemName("cottonBoots"));
        hardenedleatherItem = new ItemPamCraftingMats(itembaseID + 49).setIconCoord(3, 0).setItemName("hardenedleatherItem");
        hardenedleatherHelm = (new ItemPamArmorWa(itembaseID + 50, armorHardenedLeather, 7, 0).setIconCoord(2, 1).setItemName("hardenedleatherHelm"));
        hardenedleatherChest = (new ItemPamArmorWa(itembaseID + 51, armorHardenedLeather, 7, 1).setIconCoord(1, 1).setItemName("hardenedleatherChest"));
        hardenedleatherLegs = (new ItemPamArmorWa(itembaseID + 52, armorHardenedLeather, 7, 2).setIconCoord(3, 1).setItemName("hardenedleatherLegs"));
        hardenedleatherBoots = (new ItemPamArmorWa(itembaseID + 53, armorHardenedLeather, 7, 3).setIconCoord(0, 1).setItemName("hardenedleatherBoots"));
        
        tomatoseedItem = new ItemPamSeeds(itembaseID + 54, Pamcombinedmod.pamtomatoCrop.blockID, Block.tilledField.blockID).setIconCoord(0, 1).setItemName("tomatoseedItem");
        potatoseedItem = new ItemPamSeeds(itembaseID + 55, Pamcombinedmod.pampotatoCrop.blockID, Block.tilledField.blockID).setIconCoord(1, 1).setItemName("potatoseedItem");
        lettuceseedItem = new ItemPamSeeds(itembaseID + 56, Pamcombinedmod.pamlettuceCrop.blockID, Block.tilledField.blockID).setIconCoord(2, 1).setItemName("lettuceseedItem");
        onionseedItem = new ItemPamSeeds(itembaseID + 57, Pamcombinedmod.pamonionCrop.blockID, Block.tilledField.blockID).setIconCoord(3, 1).setItemName("onionseedItem");
        carrotseedItem = new ItemPamSeeds(itembaseID + 58, Pamcombinedmod.pamcarrotCrop.blockID, Block.tilledField.blockID).setIconCoord(4, 1).setItemName("carrotseedItem");
        cornseedItem = new ItemPamSeeds(itembaseID + 59, Pamcombinedmod.pamcornCrop.blockID, Block.tilledField.blockID).setIconCoord(5, 1).setItemName("cornseedItem");
        peanutseedItem = new ItemPamSeeds(itembaseID + 60, Pamcombinedmod.pampeanutCrop.blockID, Block.tilledField.blockID).setIconCoord(6, 1).setItemName("peanutseedItem");
        cucumberseedItem = new ItemPamSeeds(itembaseID + 61, Pamcombinedmod.pamcucumberCrop.blockID, Block.tilledField.blockID).setIconCoord(7, 1).setItemName("cucumberseedItem");
        riceseedItem = new ItemPamSeeds(itembaseID + 62, Pamcombinedmod.pamriceCrop.blockID, Block.tilledField.blockID).setIconCoord(8, 1).setItemName("riceseedItem");
        beansseedItem = new ItemPamSeeds(itembaseID + 63, Pamcombinedmod.pambeansCrop.blockID, Block.tilledField.blockID).setIconCoord(9, 1).setItemName("beansseedItem");
        bellpepperseedItem = new ItemPamSeeds(itembaseID + 64, Pamcombinedmod.pambellpepperCrop.blockID, Block.tilledField.blockID).setIconCoord(10, 1).setItemName("bellpepperseedItem");
        eggplantseedItem = new ItemPamSeeds(itembaseID + 65, Pamcombinedmod.pameggplantCrop.blockID, Block.tilledField.blockID).setIconCoord(11, 1).setItemName("eggplantseedItem");
        teaseedItem = new ItemPamSeeds(itembaseID + 66, Pamcombinedmod.pamteaCrop.blockID, Block.tilledField.blockID).setIconCoord(12, 1).setItemName("teaseedItem");
        coffeeseedItem = new ItemPamSeeds(itembaseID + 67, Pamcombinedmod.pamcoffeeCrop.blockID, Block.tilledField.blockID).setIconCoord(13, 1).setItemName("coffeeseedItem");
        beetseedItem = new ItemPamSeeds(itembaseID + 68, Pamcombinedmod.pambeetCrop.blockID, Block.tilledField.blockID).setIconCoord(14, 1).setItemName("beetseedItem");
        broccoliseedItem = new ItemPamSeeds(itembaseID + 69, Pamcombinedmod.pambroccoliCrop.blockID, Block.tilledField.blockID).setIconCoord(15, 1).setItemName("broccoliseedItem");
        sweetpotatoseedItem = new ItemPamSeeds(itembaseID + 70, Pamcombinedmod.pamsweetpotatoCrop.blockID, Block.tilledField.blockID).setIconCoord(0, 5).setItemName("sweetpotatoseedItem");
        peasseedItem = new ItemPamSeeds(itembaseID + 71, Pamcombinedmod.pampeasCrop.blockID, Block.tilledField.blockID).setIconCoord(1, 5).setItemName("peasseedItem");
        pineappleseedItem = new ItemPamSeeds(itembaseID + 72, Pamcombinedmod.pampineappleCrop.blockID, Block.tilledField.blockID).setIconCoord(2, 5).setItemName("pineappleseedItem");
        turnipseedItem = new ItemPamSeeds(itembaseID + 73, Pamcombinedmod.pamturnipCrop.blockID, Block.tilledField.blockID).setIconCoord(3, 5).setItemName("turnipseedItem");
        gingerseedItem = new ItemPamSeeds(itembaseID + 74, Pamcombinedmod.pamgingerCrop.blockID, Block.tilledField.blockID).setIconCoord(4, 5).setItemName("gingerseedItem");
        mustardseedItem = new ItemPamSeeds(itembaseID + 75, Pamcombinedmod.pammustardCrop.blockID, Block.tilledField.blockID).setIconCoord(5, 5).setItemName("mustardseedItem");
        garlicseedItem = new ItemPamSeeds(itembaseID + 76, Pamcombinedmod.pamgarlicCrop.blockID, Block.tilledField.blockID).setIconCoord(6, 5).setItemName("garlicseedItem");
        rottenseedItem = new ItemPamSeeds(itembaseID + 77, Pamcombinedmod.pamrottenmeatCrop.blockID, Block.tilledField.blockID).setIconCoord(7, 5).setItemName("rottenseedItem");
        harvestwheatseedItem = new ItemPamSeeds(itembaseID + 78, Pamcombinedmod.pamharvestwheatCrop.blockID, Block.tilledField.blockID).setIconCoord(8, 5).setItemName("harvestwheatseedItem");
        blueberryseedItem = new ItemPamSeeds(itembaseID + 79, Pamcombinedmod.pamblueberryCrop.blockID, Block.tilledField.blockID).setIconCoord(0, 9).setItemName("blueberryseedItem");
        blackberryseedItem = new ItemPamSeeds(itembaseID + 80, Pamcombinedmod.pamblackberryCrop.blockID, Block.tilledField.blockID).setIconCoord(1, 9).setItemName("blackberryseedItem");
        raspberryseedItem = new ItemPamSeeds(itembaseID + 81, Pamcombinedmod.pamraspberryCrop.blockID, Block.tilledField.blockID).setIconCoord(2, 9).setItemName("raspberryseedItem");
        kiwiseedItem = new ItemPamSeeds(itembaseID + 82, Pamcombinedmod.pamkiwiCrop.blockID, Block.tilledField.blockID).setIconCoord(3, 9).setItemName("kiwiseedItem");
        strawberryseedItem = new ItemPamSeeds(itembaseID + 83, Pamcombinedmod.pamstrawberryCrop.blockID, Block.tilledField.blockID).setIconCoord(4, 9).setItemName("strawberryseedItem");
        grapeseedItem = new ItemPamSeeds(itembaseID + 84, Pamcombinedmod.pamgrapeCrop.blockID, Block.tilledField.blockID).setIconCoord(5, 9).setItemName("grapeseedItem");
        sunflowerseedItem = new ItemPamSeeds(itembaseID + 85, Pamcombinedmod.pamsunflowerCrop.blockID, Block.tilledField.blockID).setIconCoord(6, 9).setItemName("sunflowerseedItem");
        whitemushroomseedItem = new ItemPamSeeds(itembaseID + 86, Pamcombinedmod.pamwhitemushroomCrop.blockID, Block.tilledField.blockID).setIconCoord(7, 9).setItemName("whitemushroomseedItem");
        cottonseedItem = new ItemPamSeeds(itembaseID + 87, Pamcombinedmod.pamcottonCrop.blockID, Block.tilledField.blockID).setIconCoord(8, 9).setItemName("cottonseedItem");
        candleberryseedItem = new ItemPamSeeds(itembaseID + 88, Pamcombinedmod.pamcandleberryCrop.blockID, Block.tilledField.blockID).setIconCoord(9, 9).setItemName("candleberryseedItem");
        radishseedItem = new ItemPamSeeds(itembaseID + 89, Pamcombinedmod.pamradishCrop.blockID, Block.tilledField.blockID).setIconCoord(9, 5).setItemName("radishseedItem");
        celeryseedItem = new ItemPamSeeds(itembaseID + 90, Pamcombinedmod.pamceleryCrop.blockID, Block.tilledField.blockID).setIconCoord(10, 5).setItemName("celeryseedItem");
        zucchiniseedItem = new ItemPamSeeds(itembaseID + 91, Pamcombinedmod.pamzucchiniCrop.blockID, Block.tilledField.blockID).setIconCoord(11, 5).setItemName("zucchiniseedItem");
        chilipepperseedItem = new ItemPamSeeds(itembaseID + 92, Pamcombinedmod.pamchilipepperCrop.blockID, Block.tilledField.blockID).setIconCoord(12, 5).setItemName("chilipepperseedItem");
        cantaloupeseedItem = new ItemPamSeeds(itembaseID + 93, Pamcombinedmod.pamcantaloupeCrop.blockID, Block.tilledField.blockID).setIconCoord(13, 5).setItemName("cantaloupeseedItem");
        asparagusseedItem = new ItemPamSeeds(itembaseID + 94, Pamcombinedmod.pamasparagusCrop.blockID, Block.tilledField.blockID).setIconCoord(14, 5).setItemName("asparagusseedItem");
        cranberryseedItem = new ItemPamSeeds(itembaseID + 95, Pamcombinedmod.pamcranberryCrop.blockID, Block.tilledField.blockID).setIconCoord(11, 9).setItemName("cranberryseedItem");
        spiceleafseedItem = new ItemPamSeeds(itembaseID + 96, Pamcombinedmod.pamspiceleafCrop.blockID, Block.tilledField.blockID).setIconCoord(12, 9).setItemName("spiceleafseedItem");
        //itembaseID + 97 --- 139
       
        tomatoItem = new ItemPamFoodCrops(itembaseID + 140, ediblefruitveggieheal, 0.4F, false).setIconCoord(0, 0).setItemName("tomatoItem");
        potatoItem = new ItemPamCrops(itembaseID + 141).setIconCoord(1, 0).setItemName("potatoItem");
        lettuceItem = new ItemPamFoodCrops(itembaseID + 142, ediblefruitveggieheal, 0.4F, false).setIconCoord(2, 0).setItemName("lettuceItem");
        onionItem = new ItemPamCrops(itembaseID + 143).setIconCoord(3, 0).setItemName("onionItem");
        carrotItem = new ItemPamFoodCrops(itembaseID + 144, ediblefruitveggieheal, 0.4F, false).setIconCoord(4, 0).setItemName("carrotItem");
        cornItem = new ItemPamCrops(itembaseID + 145).setIconCoord(5, 0).setItemName("cornItem");
        peanutItem = new ItemPamFoodCrops(itembaseID + 146, ediblefruitveggieheal, 0.4F, false).setIconCoord(6, 0).setItemName("peanutItem");
        cucumberItem = new ItemPamFoodCrops(itembaseID + 147, ediblefruitveggieheal, 0.4F, false).setIconCoord(7, 0).setItemName("cucumberItem");
        riceItem = new ItemPamCrops(itembaseID + 148).setIconCoord(8, 0).setItemName("riceItem");
        beansItem = new ItemPamCrops(itembaseID + 149).setIconCoord(9, 0).setItemName("beansItem");
        bellpepperItem = new ItemPamCrops(itembaseID + 150).setIconCoord(10, 0).setItemName("bellpepperItem");
        eggplantItem = new ItemPamCrops(itembaseID + 151).setIconCoord(11, 0).setItemName("eggplantItem");
        tealeafItem = new ItemPamCrops(itembaseID + 152).setIconCoord(12, 0).setItemName("tealeafItem");
        coffeebeanItem = new ItemPamCrops(itembaseID + 153).setIconCoord(13, 0).setItemName("coffeebeanItem");
        beetItem = new ItemPamCrops(itembaseID + 154).setIconCoord(14, 0).setItemName("beetItem");
        broccoliItem = new ItemPamFoodCrops(itembaseID + 155, ediblefruitveggieheal, 0.4F, false).setIconCoord(15, 0).setItemName("broccoliItem");
        sweetpotatoItem = new ItemPamCrops(itembaseID + 156).setIconCoord(0, 4).setItemName("sweetpotatoItem");
        peasItem = new ItemPamCrops(itembaseID + 157).setIconCoord(1, 4).setItemName("peasItem");
        pineappleItem = new ItemPamFoodCrops(itembaseID + 158, ediblefruitveggieheal, 0.4F, false).setIconCoord(2, 4).setItemName("pineappleItem");
        turnipItem = new ItemPamCrops(itembaseID + 159).setIconCoord(3, 4).setItemName("turnipItem");
        gingerItem = new ItemPamCrops(itembaseID + 160).setIconCoord(4, 4).setItemName("gingerItem");
        mustardseedsItem = new ItemPamCrops(itembaseID + 161).setIconCoord(5, 4).setItemName("mustardseedsItem");
        garlicItem = new ItemPamCrops(itembaseID + 162).setIconCoord(6, 4).setItemName("garlicItem");
        harvestwheatItem = new ItemPamCrops(itembaseID + 163).setIconCoord(8, 4).setItemName("harvestwheatItem");
        blueberryItem = new ItemPamFoodCrops(itembaseID + 166, ediblefruitveggieheal, 0.4F, false).setIconCoord(0, 8).setItemName("blueberryItem");
        blackberryItem = new ItemPamFoodCrops(itembaseID + 167, ediblefruitveggieheal, 0.4F, false).setIconCoord(1, 8).setItemName("blackberryItem");
        raspberryItem = new ItemPamFoodCrops(itembaseID + 168, ediblefruitveggieheal, 0.4F, false).setIconCoord(2, 8).setItemName("raspberryItem");
        kiwiItem = new ItemPamFoodCrops(itembaseID + 169, ediblefruitveggieheal, 0.4F, false).setIconCoord(3, 8).setItemName("kiwiItem");
        strawberryItem = new ItemPamFoodCrops(itembaseID + 170, ediblefruitveggieheal, 0.4F, false).setIconCoord(4, 8).setItemName("strawberryItem");
        grapeItem = new ItemPamFoodCrops(itembaseID + 171, ediblefruitveggieheal, 0.4F, false).setIconCoord(5, 8).setItemName("grapeItem");
        sunflowerseedsItem = new ItemPamFoodCrops(itembaseID + 172, ediblefruitveggieheal, 0.4F, false).setIconCoord(6, 8).setItemName("sunflowerseedsItem");
        whitemushroomItem = new ItemPamFoodCrops(itembaseID + 173, ediblefruitveggieheal, 0.4F, false).setIconCoord(7, 8).setItemName("whitemushroomItem");
        cottonItem = new ItemPamCrops(itembaseID + 174).setIconCoord(8, 8).setItemName("cottonItem");
        candleberryItem = new ItemPamCrops(itembaseID + 175).setIconCoord(9, 8).setItemName("candleberryItem");
        radishItem = new ItemPamCrops(itembaseID + 176).setIconCoord(9, 4).setItemName("radishItem");
        celeryItem = new ItemPamFoodCrops(itembaseID + 177, ediblefruitveggieheal, 0.4F, false).setIconCoord(10, 4).setItemName("celeryItem");
        zucchiniItem = new ItemPamFoodCrops(itembaseID + 178, ediblefruitveggieheal, 0.4F, false).setIconCoord(11, 4).setItemName("zucchiniItem");
        chilipepperItem = new ItemPamCrops(itembaseID + 179).setIconCoord(12, 4).setItemName("chilipepperItem");
        cantaloupeItem = new ItemPamFoodCrops(itembaseID + 180, ediblefruitveggieheal, 0.4F, false).setIconCoord(13, 4).setItemName("cataloupeItem");
        asparagusItem = new ItemPamCrops(itembaseID + 181).setIconCoord(14, 4).setItemName("asparagusItem");
        cranberryItem = new ItemPamCrops(itembaseID + 182).setIconCoord(11, 8).setItemName("cranberryItem");
        spiceleafItem = new ItemPamCrops(itembaseID + 183).setIconCoord(12, 8).setItemName("spiceleafItem");
        //itembaseID + 184 --- 226
        
        cherryItem = new ItemPamFoodFruit(itembaseID + 228, ediblefruitveggieheal, 0.4F, false).setIconCoord(0, 0).setItemName("cherryItem");
        walnutItem = new ItemPamFoodFruit(itembaseID + 235, ediblefruitveggieheal, 0.4F, false).setIconCoord(1, 0).setItemName("walnutItem");
        pearItem = new ItemPamFoodFruit(itembaseID + 236, ediblefruitveggieheal, 0.4F, false).setIconCoord(2, 0).setItemName("pearItem");
        plumItem = new ItemPamFoodFruit(itembaseID + 237, ediblefruitveggieheal, 0.4F, false).setIconCoord(3, 0).setItemName("plumItem");
        avacadoItem = new ItemPamFoodFruit(itembaseID + 241, ediblefruitveggieheal, 0.4F, false).setIconCoord(4, 0).setItemName("avacadoItem");
        nutmegItem = new ItemPamFruit(itembaseID + 242).setIconCoord(5, 0).setItemName("nutmegItem");
        
        bananaItem = new ItemPamFoodFruit(itembaseID + 227, ediblefruitveggieheal, 0.4F, false).setIconCoord(0, 1).setItemName("bananaItem");
        coconutItem = new ItemPamFoodFruit(itembaseID + 229, ediblefruitveggieheal, 0.4F, false).setIconCoord(1, 1).setItemName("coconutItem");
        lemonItem = new ItemPamFoodFruit(itembaseID + 230, ediblefruitveggieheal, 0.4F, false).setIconCoord(2, 1).setItemName("lemonItem");
        orangeItem = new ItemPamFoodFruit(itembaseID + 231, ediblefruitveggieheal, 0.4F, false).setIconCoord(3, 1).setItemName("orangeItem");
        peachItem = new ItemPamFoodFruit(itembaseID + 232, ediblefruitveggieheal, 0.4F, false).setIconCoord(4, 1).setItemName("peachItem");
        limeItem = new ItemPamFoodFruit(itembaseID + 233, ediblefruitveggieheal, 0.4F, false).setIconCoord(5, 1).setItemName("limeItem");
        mangoItem = new ItemPamFoodFruit(itembaseID + 234, ediblefruitveggieheal, 0.4F, false).setIconCoord(6, 1).setItemName("mangoItem");
        oliveItem = new ItemPamFruit(itembaseID + 238).setIconCoord(7, 1).setItemName("oliveItem");
        pomegranateItem = new ItemPamFoodFruit(itembaseID + 243, ediblefruitveggieheal, 0.4F, false).setIconCoord(8, 1).setItemName("pomegranateItem");
        vanillabeanItem = new ItemPamFruit(itembaseID + 244).setIconCoord(9, 1).setItemName("vanillabeanItem");
        peppercornItem = new ItemPamFruit(itembaseID + 247).setIconCoord(10,1).setItemName("peppercornItem");
        papayaItem = new ItemPamFoodFruit(itembaseID + 245, ediblefruitveggieheal, 0.4F, false).setIconCoord(11, 1).setItemName("papayaItem");
        starfruitItem = new ItemPamFoodFruit(itembaseID + 246, ediblefruitveggieheal, 0.4F, false).setIconCoord(12, 1).setItemName("starfruitItem");
        cinnamonItem = new ItemPamFruit(itembaseID + 239).setIconCoord(13, 1).setItemName("cinnamonItem");
        honeyItem = new ItemPamFruit(itembaseID + 240).setIconCoord(0, 3).setItemName("honeyItem");
        //itembaseID + 248 --- 278
        
        //Seed Packets/Boxes
        tomatoseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 279).setIconCoord(0, 2).setItemName("tomatoseedpacketItem");
        potatoseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 280).setIconCoord(1, 2).setItemName("potatoseedpacketItem");
        lettuceseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 281).setIconCoord(2, 2).setItemName("lettuceseedpacketItem");
        onionseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 282).setIconCoord(3, 2).setItemName("onionseedpacketItem");
        carrotseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 283).setIconCoord(4, 2).setItemName("carrotseedpacketItem");
        cornseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 284).setIconCoord(5, 2).setItemName("cornseedpacketItem");
        peanutseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 285).setIconCoord(6, 2).setItemName("peanutseedpacketItem");
        cucumberseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 286).setIconCoord(7, 2).setItemName("cucumberseedpacketItem");
        riceseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 287).setIconCoord(8, 2).setItemName("riceseedpacketItem");
        beansseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 288).setIconCoord(9, 2).setItemName("beansseedpacketItem");
        bellpepperseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 289).setIconCoord(10, 2).setItemName("bellpepperseedpacketItem");
        eggplantseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 290).setIconCoord(11, 2).setItemName("eggplantseedpacketItem");
        teaseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 291).setIconCoord(12, 2).setItemName("teaseedpacketItem");
        coffeeseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 292).setIconCoord(13, 2).setItemName("coffeeseedpacketItem");
        beetseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 293).setIconCoord(14, 2).setItemName("beetseedpacketItem");
        broccoliseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 294).setIconCoord(15, 2).setItemName("broccoliseedpacketItem");
        sweetpotatoseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 295).setIconCoord(0, 6).setItemName("sweetpotatoseedpacketItem");
        peasseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 296).setIconCoord(1, 6).setItemName("peasseedpacketItem");
        pineappleseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 297).setIconCoord(2, 6).setItemName("pineappleseedpacketItem");
        turnipseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 298).setIconCoord(3, 6).setItemName("turnipseedpacketItem");
        gingerseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 299).setIconCoord(4, 6).setItemName("gingerseedpacketItem");
        mustardseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 300).setIconCoord(5, 6).setItemName("mustardseedpacketItem");
        garlicseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 301).setIconCoord(6, 6).setItemName("garlicseedpacketItem");
        rottenseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 302).setIconCoord(7, 6).setItemName("rottenseedpacketItem");
        harvestwheatseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 303).setIconCoord(8, 6).setItemName("havestwheatseedpacketItem");
        blueberryseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 304).setIconCoord(0, 10).setItemName("blueberryseedpacketItem");
        blackberryseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 305).setIconCoord(1, 10).setItemName("blackberryseedpacketItem");
        raspberryseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 306).setIconCoord(2, 10).setItemName("raspberryseedpacketItem");
        kiwiseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 307).setIconCoord(3, 10).setItemName("kiwiseedpacketItem");
        strawberryseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 308).setIconCoord(4, 10).setItemName("strawberryseedpacketItem");
        grapeseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 309).setIconCoord(5, 10).setItemName("grapeseedpacketItem");
        sunflowerseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 310).setIconCoord(6, 10).setItemName("sunflowerseedpacketItem");
        whitemushroomseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 311).setIconCoord(7, 10).setItemName("whitemushroomseedpacketItem");
        cottonseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 312).setIconCoord(8, 10).setItemName("cottonseedpacketItem");
        candleberryseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 313).setIconCoord(9, 10).setItemName("candleberryseedpacketItem");
        cactusfruitseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 314).setIconCoord(10, 10).setItemName("cactusfruitseedpacketItem");
        radishseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 315).setIconCoord(9, 6).setItemName("radishseedpacketItem");
        celeryseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 316).setIconCoord(10, 6).setItemName("celeryseedpacketItem");
        zucchiniseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 317).setIconCoord(11, 6).setItemName("zucchiniseedpacketItem");
        chilipepperseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 318).setIconCoord(12, 6).setItemName("chilipepperseedpacketItem");
        cantaloupeseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 319).setIconCoord(13, 6).setItemName("cantaloupeseedpacketItem");
        asparagusseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 320).setIconCoord(14, 6).setItemName("asparagusseedpacketItem");
        cranberryseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 321).setIconCoord(11, 10).setItemName("cranberryseedpacketItem");
        spiceleafseedpacketItem = new ItemPamSeedPacketBox(itembaseID + 322).setIconCoord(12, 10).setItemName("spiceleafpacketItem");
        //itembaseID 323 --- 365
        
        tomatoseedboxItem = new ItemPamSeedPacketBox(itembaseID + 366).setIconCoord(0, 3).setItemName("tomatoseedboxItem");
        potatoseedboxItem = new ItemPamSeedPacketBox(itembaseID + 367).setIconCoord(1, 3).setItemName("potatoseedboxItem");
        lettuceseedboxItem = new ItemPamSeedPacketBox(itembaseID + 368).setIconCoord(2, 3).setItemName("lettuceseedboxItem");
        onionseedboxItem = new ItemPamSeedPacketBox(itembaseID + 369).setIconCoord(3, 3).setItemName("onionseedboxItem");
        carrotseedboxItem = new ItemPamSeedPacketBox(itembaseID + 370).setIconCoord(4, 3).setItemName("carrotseedboxItem");
        cornseedboxItem = new ItemPamSeedPacketBox(itembaseID + 371).setIconCoord(5, 3).setItemName("cornseedboxItem");
        peanutseedboxItem = new ItemPamSeedPacketBox(itembaseID + 372).setIconCoord(6, 3).setItemName("peanutseedboxItem");
        cucumberseedboxItem = new ItemPamSeedPacketBox(itembaseID + 373).setIconCoord(7, 3).setItemName("cucumberseedboxItem");
        riceseedboxItem = new ItemPamSeedPacketBox(itembaseID + 374).setIconCoord(8, 3).setItemName("riceseedboxItem");
        beansseedboxItem = new ItemPamSeedPacketBox(itembaseID + 375).setIconCoord(9, 3).setItemName("beansseedboxItem");
        bellpepperseedboxItem = new ItemPamSeedPacketBox(itembaseID + 376).setIconCoord(10, 3).setItemName("bellpepperseedboxItem");
        eggplantseedboxItem = new ItemPamSeedPacketBox(itembaseID + 377).setIconCoord(11, 3).setItemName("eggplantseedboxItem");
        teaseedboxItem = new ItemPamSeedPacketBox(itembaseID + 378).setIconCoord(12, 3).setItemName("teaseedboxItem");
        coffeeseedboxItem = new ItemPamSeedPacketBox(itembaseID + 379).setIconCoord(13, 3).setItemName("coffeeseedboxItem");
        beetseedboxItem = new ItemPamSeedPacketBox(itembaseID + 380).setIconCoord(14, 3).setItemName("beetseedboxItem");
        broccoliseedboxItem = new ItemPamSeedPacketBox(itembaseID + 381).setIconCoord(15, 3).setItemName("broccoliseedboxItem");
        sweetpotatoseedboxItem = new ItemPamSeedPacketBox(itembaseID + 382).setIconCoord(0, 7).setItemName("sweetpotatoseedboxItem");
        peasseedboxItem = new ItemPamSeedPacketBox(itembaseID + 383).setIconCoord(1, 7).setItemName("peasseedboxItem");
        pineappleseedboxItem = new ItemPamSeedPacketBox(itembaseID + 384).setIconCoord(2, 7).setItemName("pineappleseedboxItem");
        turnipseedboxItem = new ItemPamSeedPacketBox(itembaseID + 385).setIconCoord(3, 7).setItemName("turnipseedboxItem");
        gingerseedboxItem = new ItemPamSeedPacketBox(itembaseID + 386).setIconCoord(4, 7).setItemName("gingerseedboxItem");
        mustardseedboxItem = new ItemPamSeedPacketBox(itembaseID + 387).setIconCoord(5, 7).setItemName("mustardseedboxItem");
        garlicseedboxItem = new ItemPamSeedPacketBox(itembaseID + 388).setIconCoord(6, 7).setItemName("garlicseedboxItem");
        rottenseedboxItem = new ItemPamSeedPacketBox(itembaseID + 389).setIconCoord(7, 7).setItemName("rottenseedboxItem");
        harvestwheatseedboxItem = new ItemPamSeedPacketBox(itembaseID + 390).setIconCoord(8, 7).setItemName("havestwheatseedboxItem");
        blueberryseedboxItem = new ItemPamSeedPacketBox(itembaseID + 391).setIconCoord(0, 11).setItemName("blueberryseedboxItem");
        blackberryseedboxItem = new ItemPamSeedPacketBox(itembaseID + 392).setIconCoord(1, 11).setItemName("blackberryseedboxItem");
        raspberryseedboxItem = new ItemPamSeedPacketBox(itembaseID + 393).setIconCoord(2, 11).setItemName("raspberryseedboxItem");
        kiwiseedboxItem = new ItemPamSeedPacketBox(itembaseID + 394).setIconCoord(3, 11).setItemName("kiwiseedboxItem");
        strawberryseedboxItem = new ItemPamSeedPacketBox(itembaseID + 395).setIconCoord(4, 11).setItemName("strawberryseedboxItem");
        grapeseedboxItem = new ItemPamSeedPacketBox(itembaseID + 396).setIconCoord(5, 11).setItemName("grapeseedboxItem");
        sunflowerseedboxItem = new ItemPamSeedPacketBox(itembaseID + 397).setIconCoord(6, 11).setItemName("sunflowerseedboxItem");
        whitemushroomseedboxItem = new ItemPamSeedPacketBox(itembaseID + 398).setIconCoord(7, 11).setItemName("whitemushroomseedboxItem");
        cottonseedboxItem = new ItemPamSeedPacketBox(itembaseID + 399).setIconCoord(8, 11).setItemName("cottonseedboxItem");
        candleberryseedboxItem = new ItemPamSeedPacketBox(itembaseID + 400).setIconCoord(9, 11).setItemName("candleberryseedboxItem");
        cactusfruitseedboxItem = new ItemPamSeedPacketBox(itembaseID + 401).setIconCoord(10, 11).setItemName("cactusfruitseedboxItem");
        radishseedboxItem = new ItemPamSeedPacketBox(itembaseID + 402).setIconCoord(9, 7).setItemName("radishseedboxItem");
        celeryseedboxItem = new ItemPamSeedPacketBox(itembaseID + 403).setIconCoord(10, 7).setItemName("celeryseedboxItem");
        zucchiniseedboxItem = new ItemPamSeedPacketBox(itembaseID + 404).setIconCoord(11, 7).setItemName("zucchiniseedboxItem");
        chilipepperseedboxItem = new ItemPamSeedPacketBox(itembaseID + 405).setIconCoord(12, 7).setItemName("chilipepperseedboxItem");
        cantaloupeseedboxItem = new ItemPamSeedPacketBox(itembaseID + 406).setIconCoord(13, 7).setItemName("cantaloupeseedboxItem");
        asparagusseedboxItem = new ItemPamSeedPacketBox(itembaseID + 407).setIconCoord(14, 7).setItemName("asparagusseedboxItem");
        cranberryseedboxItem = new ItemPamSeedPacketBox(itembaseID + 408).setIconCoord(11, 11).setItemName("cranberryseedboxItem");
        spiceleafseedboxItem = new ItemPamSeedPacketBox(itembaseID + 409).setIconCoord(12, 11).setItemName("spiceleafboxItem");
        //itembaseID + 410 --- 452
        
         saltItem = new ItemPamCraftingMats(itembaseID + 453).setIconCoord(0, 3).setItemName("saltItem");
         butterItem = new ItemPamFo(itembaseID + 454).setIconCoord(14, 3).setItemName("butterItem");
         cheeseItem = new ItemPamFo(itembaseID + 455).setIconCoord(4, 4).setItemName("cheeseItem");
         doughItem = new ItemPamFo(itembaseID + 456).setIconCoord(8, 5).setItemName("doughItem");
         bakedpotatoItem = new ItemPamFoodFo(itembaseID + 457, 4, 0.4F, false).setIconCoord(12, 2).setItemName("bakedpotatoItem");
         butteredpotatoItem = new ItemPamFoodFo(itembaseID + 458, 6, 0.6F, false).setIconCoord(13, 3).setItemName("butteredpotatoItem");
         loadedpotatoItem = new ItemPamFoodFo(itembaseID + 459, 12, 1.2F, false).setIconCoord(1, 7).setItemName("loadedpotatoItem");
         friedeggsItem = new ItemPamBowlFoodFo(itembaseID + 460, 8).setIconCoord(4, 6).setItemName("friedeggsItem");
         friedpotatoesItem = new ItemPamBowlFoodFo(itembaseID + 461, 6).setIconCoord(7, 6).setItemName("friedpotatoesItem");
         saladItem = new ItemPamBowlFoodFo(itembaseID + 462, 6).setIconCoord(13, 9).setItemName("saladItem");
         saltedcookedfishItem = new ItemPamFoodFo(itembaseID + 463, 8, 0.8F, false).setIconCoord(14, 9).setItemName("saltedcookedfishItem");
         pumpkinpieItem = new ItemPamFoodFo(itembaseID + 464, 6, 0.6F, false).setIconCoord(3, 9).setItemName("pumpkinpieItem");
         pizzaItem = new ItemPamFoodFo(itembaseID + 465, 12, 1.2F, false).setIconCoord(10, 8).setItemName("pizzaItem");
         spagettiItem = new ItemPamBowlFoodFo(itembaseID + 466, 10).setIconCoord(4, 10).setItemName("spagettiItem");
         pastaItem = new ItemPamFo(itembaseID + 467).setIconCoord(14, 7).setItemName("pastaItem");
         friedonionringsItem = new ItemPamFoodFo(itembaseID + 468, 6, 0.6F, false).setIconCoord(5, 6).setItemName("friedonionringsItem");
         applepieItem = new ItemPamFoodFo(itembaseID + 469, 8, 0.8F, false).setIconCoord(9, 2).setItemName("applepieItem");
         applesauceItem = new ItemPamBowlFoodFo(itembaseID + 470, 6).setIconCoord(10, 2).setItemName("applesauceItem");
         toastItem = new ItemPamFoodFo(itembaseID + 471, 6, 0.6F, false).setIconCoord(1, 11).setItemName("toastItem");
         grilledcheeseItem = new ItemPamFoodFo(itembaseID + 472, 10, 1.0F, false).setIconCoord(12, 6).setItemName("grilledcheeseItem");
         bltsandwichItem = new ItemPamFoodFo(itembaseID + 473, 14, 1.4F, false).setIconCoord(7, 3).setItemName("bltsandwichItem");
         macncheeseItem = new ItemPamBowlFoodFo(itembaseID + 474, 8).setIconCoord(2, 7).setItemName("macncheeseItem");
         fishsticksItem = new ItemPamFoodFo(itembaseID + 475, 10, 1.0F, false).setIconCoord(0, 6).setItemName("fishsticksItem");
         mashedpotatoesItem = new ItemPamBowlFoodFo(itembaseID + 476, 8).setIconCoord(3, 7).setItemName("mashedpotatoesItem");
         fishsandwichItem = new ItemPamFoodFo(itembaseID + 477, 10, 1.0F, false).setIconCoord(15, 5).setItemName("fishsandwichItem");
         cerealItem = new ItemPamBowlFoodFo(itembaseID + 478, 6).setIconCoord(2, 4).setItemName("cerealItem");
         popcornItem = new ItemPamFoodFo(itembaseID + 479, 4, 0.4F, false).setIconCoord(11, 8).setItemName("popcornitem");
         butteredpopcornItem = new ItemPamFoodFo(itembaseID + 480, 6, 0.6F, false).setIconCoord(12, 3).setItemName("butteredpopcornItem");
         cornonthecobItem = new ItemPamFoodFo(itembaseID + 481, 6, 0.6F, false).setIconCoord(1, 5).setItemName("cornonthecobItem");
         saltedpeanutsItem = new ItemPamFoodFo(itembaseID + 482, 4, 0.4F, false).setIconCoord(15, 9).setItemName("saltedpeanutsItem");
         pbnjsandwichItem = new ItemPamFoodFo(itembaseID + 483, 10, 1.0F, false).setIconCoord(0, 8).setItemName("pbnjsandwichItem");
         raisinsItem = new ItemPamFoodFo(itembaseID + 484, 4, 0.4F, false).setIconCoord(6, 9).setItemName("raisinsItem");
         cornbreadmuffinsItem = new ItemPamFoodFo(itembaseID + 485, 6, 0.6F, false).setIconCoord(13, 4).setItemName("cornbreadmuffinsItem");
         tacoItem = new ItemPamFoodFo(itembaseID + 486, 12, 1.2F, false).setIconCoord(0, 11).setItemName("tacoItem");
         nachosItem = new ItemPamBowlFoodFo(itembaseID + 487, 6).setIconCoord(6, 7).setItemName("nachosItem");
         strawberrypieItem = new ItemPamFoodFo(itembaseID + 488, 8, 0.8F, false).setIconCoord(10, 10).setItemName("strawberrypieItem");
         peanutbrittleItem = new ItemPamFoodFo(itembaseID + 489, 6, 0.6F, false).setIconCoord(1, 8).setItemName("peanutbrittleItem");
         chocolatebarItem = new ItemPamFoodFo(itembaseID + 490, 4, 0.4F, false).setIconCoord(7, 4).setItemName("chocolatebarItem");
         driedappleslicesItem = new ItemPamFoodFo(itembaseID + 491, 6, 0.6F, false).setIconCoord(9, 5).setItemName("driedappleslicesItem");
         driedstrawberriesItem = new ItemPamFoodFo(itembaseID + 492, 4, 0.4F, false).setIconCoord(10, 5).setItemName("driedstrawberriesItem");
         trailmixItem = new ItemPamFoodFo(itembaseID + 493, 10, 1.0F, false).setIconCoord(5, 11).setItemName("trailmixItem");
         icecreamItem = new ItemPamBowlFoodFo(itembaseID + 494, 4).setIconCoord(14, 6).setItemName("icecreamItem");
         chocolateicecreamItem = new ItemPamBowlFoodFo(itembaseID + 495, 6).setIconCoord(9, 4).setItemName("chocolateicecreamItem");
         strawberryicecreamItem = new ItemPamBowlFoodFo(itembaseID + 496, 6).setIconCoord(6, 10).setItemName("strawberryicecreamItem");
         picklesItem = new ItemPamFoodFo(itembaseID + 497, 6, 0.6F, false).setIconCoord(9, 8).setItemName("picklesItem");
         chocolatecoveredfruitItem = new ItemPamFoodFo(itembaseID + 498, 6, 0.6F, false).setIconCoord(8, 4).setItemName("chocolatecoveredfruitItem");
         flourItem = new ItemPamFo(itembaseID + 499).setIconCoord(2, 6).setItemName("flourItem");
         cornmealdoughItem = new ItemPamFo(itembaseID + 500).setIconCoord(15, 4).setItemName("cornmealdoughItem");
         cornmuffinmixItem = new ItemPamFo(itembaseID + 501).setIconCoord(0, 5).setItemName("cornmuffinmixItem");
         tortillaItem = new ItemPamFo(itembaseID + 502).setIconCoord(4, 11).setItemName("tortillaItem");
         bottleItem = new ItemPamFo(itembaseID + 503).setIconCoord(10, 3).setItemName("bottleItem");
         mayoItem = new ItemPamFo(itembaseID + 504).setIconCoord(4, 7).setItemName("mayoItem").setContainerItem(Item.glassBottle);
         vinegarItem = new ItemPamFo(itembaseID + 505).setIconCoord(8, 11).setItemName("vinegarItem").setContainerItem(Item.glassBottle);
         peanutbutterItem = new ItemPamFo(itembaseID + 506).setIconCoord(2, 8).setItemName("peanutbutterItem").setContainerItem(Item.glassBottle);
         grapejellyItem = new ItemPamFo(itembaseID + 507).setIconCoord(9, 6).setItemName("grapejellyItem").setContainerItem(Item.glassBottle);
         strawberryjamItem = new ItemPamFo(itembaseID + 508).setIconCoord(9, 10).setItemName("strawberryjamItem").setContainerItem(Item.glassBottle);
         stockItem = new ItemPamFo(itembaseID + 509).setIconCoord(5, 10).setItemName("stockItem");
         noodlesoupItem = new ItemPamBowlFoodFo(itembaseID + 510, 4).setIconCoord(7, 7).setItemName("noodlesoupItem");
         hambonesoupItem = new ItemPamBowlFoodFo(itembaseID + 511, 8).setIconCoord(13, 6).setItemName("hambonesoupItem");
         cheesesoupItem = new ItemPamBowlFoodFo(itembaseID + 512, 8).setIconCoord(5, 4).setItemName("cheesesoupItem");
         vegetablesoupItem = new ItemPamBowlFoodFo(itembaseID + 513, 8).setIconCoord(6, 11).setItemName("vegetablesoupItem");
         onionsoupItem = new ItemPamBowlFoodFo(itembaseID + 514, 8).setIconCoord(12, 7).setItemName("onionsoupItem");
         peanutsoupItem = new ItemPamBowlFoodFo(itembaseID + 515, 8).setIconCoord(5, 8).setItemName("peanutsoupItem");
         cucumbersoupItem = new ItemPamBowlFoodFo(itembaseID + 516, 8).setIconCoord(7, 5).setItemName("cucumbersoupItem");
         carrotsoupItem = new ItemPamBowlFoodFo(itembaseID + 517, 8).setIconCoord(2, 4).setItemName("carrotsoupItem");
         pumpkinsoupItem = new ItemPamBowlFoodFo(itembaseID + 518, 8).setIconCoord(5, 9).setItemName("pumpkinsoupItem");
         wheatsoupItem = new ItemPamBowlFoodFo(itembaseID + 519, 8).setIconCoord(10, 11).setItemName("wheatsoupItem");
         potatosoupItem = new ItemPamBowlFoodFo(itembaseID + 520, 8).setIconCoord(1, 9).setItemName("potatosoupItem");
         oatmealItem = new ItemPamBowlFoodFo(itembaseID + 521, 6).setIconCoord(8, 7).setItemName("oatmealItem");
         friedpicklesItem = new ItemPamFoodFo(itembaseID + 522, 8, 0.8F, false).setIconCoord(6, 6).setItemName("friedpicklesItem");
         shepardpieItem = new ItemPamFoodFo(itembaseID + 523, 14, 1.4F, false).setIconCoord(2, 10).setItemName("shepardpieItem");
         strawberryiceItem = new ItemPamBowlFoodFo(itembaseID + 524, 4).setIconCoord(7, 10).setItemName("strawberryiceItem");
         sidesaladItem = new ItemPamFoodFo(itembaseID + 525, 16, 1.6F, false).setIconCoord(3, 10).setItemName("sidesaladItem");
         breakfastsandwichItem = new ItemPamFoodFo(itembaseID + 526, 14, 1.4F, false).setIconCoord(11, 3).setItemName("breakfastsandwichItem");
         coleslawItem = new ItemPamBowlFoodFo(itembaseID + 527, 8).setIconCoord(0, 4).setItemName("coleslawItem");
         fishlettucewrapItem = new ItemPamFoodFo(itembaseID + 528, 8, 0.8F, false).setIconCoord(14, 5).setItemName("fishlettucewrapItem");
         fishtacoItem = new ItemPamFoodFo(itembaseID + 529, 10, 1.0F, false).setIconCoord(1, 6).setItemName("fishtacoItem");
         porklettucewrapItem = new ItemPamFoodFo(itembaseID + 530, 12, 1.2F, false).setIconCoord(13, 8).setItemName("porklettucewrapItem");
         pastasaladItem = new ItemPamBowlFoodFo(itembaseID + 531, 10).setIconCoord(15, 7).setItemName("pastasaladItem");
         potatosaladItem = new ItemPamBowlFoodFo(itembaseID + 532, 8).setIconCoord(15, 8).setItemName("potatosaladItem");
         chocolatepeanutsItem = new ItemPamFoodFo(itembaseID + 533, 2, 0.2F, false).setIconCoord(10, 4).setItemName("chocolatepeanutsItem");
         pumpkinbreadItem = new ItemPamFoodFo(itembaseID + 534, 6, 0.6F, false).setIconCoord(2, 9).setItemName("pumpkinbreadItem");
         scrambledeggsItem = new ItemPamFoodFo(itembaseID + 535, 4, 0.4F, false).setIconCoord(1, 10).setItemName("scrambledeggsItem");
         omeletItem = new ItemPamFoodFo(itembaseID + 536, 10, 1.0F, false).setIconCoord(9, 7).setItemName("omeletItem");
         sushiItem = new ItemPamFoodFo(itembaseID + 537, 4, 0.4F, false).setIconCoord(14, 10).setItemName("sushiItem");
         porkfriedriceItem = new ItemPamBowlFoodFo(itembaseID + 538, 10).setIconCoord(12, 8).setItemName("porkfriedriceItem");
         fiestariceItem = new ItemPamBowlFoodFo(itembaseID + 539, 6).setIconCoord(13, 5).setItemName("fiestariceItem");
         stuffedpepperItem = new ItemPamFoodFo(itembaseID + 540, 8, 0.8F, false).setIconCoord(12, 10).setItemName("stuffedpepperItem");
         beansandriceItem = new ItemPamFoodFo(itembaseID + 541, 12, 1.2F, false).setIconCoord(15, 2).setItemName("beansandriceItem");
         ricecakeItem = new ItemPamFoodFo(itembaseID + 542, 4, 0.4F, false).setIconCoord(9, 9).setItemName("ricecakeItem");
         beanburritoItem = new ItemPamFoodFo(itembaseID + 543, 8, 0.8F, false).setIconCoord(14, 2).setItemName("beanburritoItem");
         chiliItem = new ItemPamBowlFoodFo(itembaseID + 544, 12).setIconCoord(6, 4).setItemName("chiliItem");
         bakedbeansItem = new ItemPamBowlFoodFo(itembaseID + 545, 10).setIconCoord(11, 2).setItemName("bakedbeansItem");
         supremepizzaItem = new ItemPamFoodFo(itembaseID + 546, 14, 1.4F, false).setIconCoord(13, 10).setItemName("supremepizzaItem");
         ricesoupItem = new ItemPamBowlFoodFo(itembaseID + 547, 6).setIconCoord(12, 9).setItemName("ricesoupItem");
         veggiestirfryItem = new ItemPamBowlFoodFo(itembaseID + 548, 14).setIconCoord(7, 11).setItemName("veggiestirfryItem");
         carrotpilafItem = new ItemPamBowlFoodFo(itembaseID + 549, 8).setIconCoord(1, 5).setItemName("carrotpilafItem");
         cornricemedleyItem = new ItemPamBowlFoodFo(itembaseID + 550, 8).setIconCoord(2, 5).setItemName("cornricemedleyItem");
         mushroomrisottoItem = new ItemPamBowlFoodFo(itembaseID + 551, 8).setIconCoord(5, 7).setItemName("mushroomrisottoItem");
         refriedbeansItem = new ItemPamBowlFoodFo(itembaseID + 552, 8).setIconCoord(8, 9).setItemName("refriedbeansItem");
         batterItem = new ItemPamFo(itembaseID + 553).setIconCoord(13, 2).setItemName("batterItem");
         syrupItem = new ItemPamFo(itembaseID + 554).setIconCoord(15, 10).setItemName("syrupItem").setContainerItem(Item.glassBottle);
         berrysyrupItem = new ItemPamFo(itembaseID + 555).setIconCoord(5, 3).setItemName("berrysyrupItem").setContainerItem(Item.glassBottle);
         wafflesItem = new ItemPamFoodFo(itembaseID + 556, 6, 0.6F, false).setIconCoord(9, 11).setItemName("wafflesItem");
         fancywafflesItem = new ItemPamFoodFo(itembaseID + 557, 10, 1.0F, false).setIconCoord(12, 5).setItemName("fancywafflesItem");
         pancakesItem = new ItemPamFoodFo(itembaseID + 558, 6, 0.6F, false).setIconCoord(13, 7).setItemName("pancakesItem");
         fancypancakesItem = new ItemPamFoodFo(itembaseID + 559, 10, 1.0F, false).setIconCoord(11, 5).setItemName("fancypancakesItem");
         frenchtoastItem = new ItemPamFoodFo(itembaseID + 560, 8, 0.8F, false).setIconCoord(3, 6).setItemName("frenchtoastItem");
         berrysaladItem = new ItemPamBowlFoodFo(itembaseID + 561, 14).setIconCoord(4, 3).setItemName("berrysaladItem");
         blueberrymuffinsItem = new ItemPamFoodFo(itembaseID + 562, 2, 0.2F, false).setIconCoord(9, 3).setItemName("blueberrymuffinsItem");
         raspberrytartItem = new ItemPamFoodFo(itembaseID + 563, 8, 0.8F, false).setIconCoord(7, 9).setItemName("raspberrytartItem");
         blackberrycobblerItem = new ItemPamFoodFo(itembaseID + 564, 8, 0.8F, false).setIconCoord(6, 3).setItemName("blackberrycobblerItem");
         peachcobblerItem = new ItemPamFoodFo(itembaseID + 565, 8, 0.8F, false).setIconCoord(1, 3).setItemName("peachcobblerItem");
         cherrypieItem = new ItemPamFoodFo(itembaseID + 566, 8, 0.8F, false).setIconCoord(2, 3).setItemName("cherrypieItem");
         lemonpieItem = new ItemPamFoodFo(itembaseID + 567, 8, 0.8F, false).setIconCoord(3, 3).setItemName("lemonpieItem");
         bananasplitItem = new ItemPamFoodFo(itembaseID + 568, 14, 1.4F, false).setIconCoord(8, 3).setItemName("bananasplitItem");
         toastedcoconutItem = new ItemPamFoodFo(itembaseID + 569, 4, 0.4F, false).setIconCoord(1, 4).setItemName("toastedcoconutItem");
         fruitsaladItem = new ItemPamFoodFo(itembaseID + 570, 16, 1.6F, false).setIconCoord(11, 4).setItemName("fruitsaladItem");
         fruitjuiceItem = new ItemPamFoodFo(itembaseID + 571, 6, 0.6F, false).setIconCoord(14, 4).setItemName("fruitjuiceItem").setContainerItem(Item.glassBottle);
         lemonaideItem = new ItemPamFoodFo(itembaseID + 572, 8, 0.8F, false).setIconCoord(3, 5).setItemName("lemonaideItem").setContainerItem(Item.glassBottle);
         grilledeggplantItem = new ItemPamFoodFo(itembaseID + 573, 4, 0.4F, false).setIconCoord(0, 0).setItemName("friedeggplantItem");
         eggplantparmItem = new ItemPamBowlFoodFo(itembaseID + 574, 8).setIconCoord(1, 0).setItemName("eggplantparmItem");
         stuffedeggplantItem = new ItemPamFoodFo(itembaseID + 575, 8, 0.8F, false).setIconCoord(2, 0).setItemName("stuffedeggplantItem");
         teaItem = new ItemPamFoodFo(itembaseID + 576, 4, 0.4F, false).setIconCoord(3, 0).setItemName("teaItem");
         raspberryicedteaItem = new ItemPamFoodFo(itembaseID + 577, 8, 0.8F, false).setIconCoord(4, 0).setItemName("raspberryicedteaItem");
         chaiteaItem = new ItemPamFoodFo(itembaseID + 578, 6, 0.6F, false).setIconCoord(5, 0).setItemName("chaiteaItem");
         coffeeItem = new ItemPamFoodFo(itembaseID + 579, 4, 0.4F, false).setIconCoord(6, 0).setItemName("coffeeItem");
         mochaicecreamItem = new ItemPamBowlFoodFo(itembaseID + 580, 8).setIconCoord(7, 0).setItemName("mochaicecreamItem");
         espressoItem = new ItemPamFoodFo(itembaseID + 581, 8, 0.8F, false).setIconCoord(8, 0).setItemName("espressoItem");
         pickledbeetsItem = new ItemPamFoodFo(itembaseID + 582, 6, 0.6F, false).setIconCoord(9, 0).setItemName("pickledbeetsItem");
         beetsaladItem = new ItemPamBowlFoodFo(itembaseID + 583, 10).setIconCoord(10, 0).setItemName("beetsaladItem");
         beetsoupItem = new ItemPamBowlFoodFo(itembaseID + 584, 8).setIconCoord(11, 0).setItemName("beetsoupItem");
         broccolimacItem = new ItemPamBowlFoodFo(itembaseID + 585, 10).setIconCoord(12, 0).setItemName("broccolimacItem");
         broccolindipItem = new ItemPamBowlFoodFo(itembaseID + 586, 6).setIconCoord(13, 0).setItemName("broccolindipItem");
         creamedbroccolisoupItem = new ItemPamBowlFoodFo(itembaseID + 587, 8).setIconCoord(14, 0).setItemName("creamedbroccolisoupItem");
         grilledsweetpotatoItem = new ItemPamFoodFo(itembaseID + 588, 4, 0.4F, false).setIconCoord(15, 0).setItemName("grilledsweetpotatoItem");
         sweetpotatopieItem = new ItemPamFoodFo(itembaseID + 589, 10, 1.0F, false).setIconCoord(0, 1).setItemName("sweetpotatopieItem");
         candiedsweetpotatoesItem = new ItemPamFoodFo(itembaseID + 590, 6, 0.6F, false).setIconCoord(1, 1).setItemName("candiedsweetpotatoesItem");
         marshmellowsItem = new ItemPamFoodFo(itembaseID + 591, 4, 0.4F, false).setIconCoord(2, 1).setItemName("marshmellowsItem");
         splitpeasoupItem = new ItemPamBowlFoodFo(itembaseID + 592, 8).setIconCoord(3, 1).setItemName("splitpeasoupItem");
         pineapplehamItem = new ItemPamFoodFo(itembaseID + 593, 10, 1.0F, false).setIconCoord(4, 1).setItemName("pineapplehamItem");
         turnipsoupItem = new ItemPamBowlFoodFo(itembaseID + 594, 8).setIconCoord(5, 1).setItemName("turnipsoupItem");
         banananutbreadItem = new ItemPamFoodFo(itembaseID + 595, 8, 0.8F, false).setIconCoord(6, 1).setItemName("banananutbreadItem");
         breadedchickenItem = new ItemPamFoodFo(itembaseID + 596, 6, 0.6F, false).setIconCoord(7, 1).setItemName("breadedchickenItem");
         chickenparmItem = new ItemPamBowlFoodFo(itembaseID + 597, 10).setIconCoord(8, 1).setItemName("chickenparmItem");
         chickensandwichItem = new ItemPamFoodFo(itembaseID + 598, 12, 1.2F, false).setIconCoord(9, 1).setItemName("chickensandwichItem");
         chickennoodlesoupItem = new ItemPamBowlFoodFo(itembaseID + 599, 12).setIconCoord(10, 1).setItemName("chickennoodlesoupItem");
         hamburgerItem = new ItemPamFoodFo(itembaseID + 600, 12, 1.2F, false).setIconCoord(11, 1).setItemName("hamburgerItem");
         cheeseburgerItem = new ItemPamFoodFo(itembaseID + 601, 14, 1.4F, false).setIconCoord(12, 1).setItemName("cheeseburgerItem");
         baconcheeseburgerItem = new ItemPamFoodFo(itembaseID + 602, 16, 1.6F, false).setIconCoord(13, 1).setItemName("baconcheeseburgerItem");
         spagettiandmeatballsItem = new ItemPamBowlFoodFo(itembaseID + 603, 14).setIconCoord(14, 1).setItemName("spagettiandmeatballsItem");
         curryriceItem = new ItemPamBowlFoodFo(itembaseID + 604, 6).setIconCoord(0, 2).setItemName("curryriceItem");
         donutItem = new ItemPamFoodFo(itembaseID + 605, 4, 0.4F, false).setIconCoord(1, 2).setItemName("donutItem");
         chocolatedonutItem = new ItemPamFoodFo(itembaseID + 606, 8, 0.8F, false).setIconCoord(2, 2).setItemName("chocolatedonutItem");
         powdereddonutItem = new ItemPamFoodFo(itembaseID + 607, 6, 0.6F, false).setIconCoord(3, 2).setItemName("powdereddonutItem");
         jellydonutItem = new ItemPamFoodFo(itembaseID + 608, 8, 0.8F, false).setIconCoord(4, 2).setItemName("jellydonutItem");
         frosteddonutItem = new ItemPamFoodFo(itembaseID + 609, 8, 0.8F, false).setIconCoord(5, 2).setItemName("frosteddonutItem");
         seedsoupItem = new ItemPamBowlFoodFo(itembaseID + 610, 1).setIconCoord(6, 2).setItemName("seedsoupItem");
         oliveoilItem = new ItemPamFo(itembaseID + 611).setIconCoord(7, 2).setItemName("oliveoilItem").setContainerItem(Item.glassBottle);
         spidereyesoupItem = new ItemPamBowlFoodFo(itembaseID + 612, 8).setIconCoord(15, 3).setItemName("spidereyesoupItem");
         zombiejerkyItem = new ItemPamFoodFo(itembaseID + 613, 4, 0.4F, false).setIconCoord(4, 5).setItemName("zombiejerkyItem");
         gingerbreadItem = new ItemPamFoodFo(itembaseID + 614, 10, 1.0F, false).setIconCoord(5, 5).setItemName("gingerbreadItem");
         gingersnapsItem = new ItemPamFoodFo(itembaseID + 615, 6, 0.6F, false).setIconCoord(6, 5).setItemName("gingersnapsItem");
         candiedgingerItem = new ItemPamFo(itembaseID + 616).setIconCoord(8, 6).setItemName("candiedgingerItem");
         saltedsunflowerseedsItem = new ItemPamFoodFo(itembaseID + 617, 4, 0.4F, false).setIconCoord(10, 6).setItemName("saltedsunflowerseedsItem");
         sunflowerwheatrollsItem = new ItemPamFoodFo(itembaseID + 618, 8, 0.8F, false).setIconCoord(11, 6).setItemName("sunflowerwheatrollsItem");
         sunflowerbroccolisaladItem = new ItemPamFoodFo(itembaseID + 619, 12, 1.2F, false).setIconCoord(0, 7).setItemName("sunflowerbroccolisaladItem");
         mustardItem = new ItemPamFo(itembaseID + 620).setIconCoord(10, 7).setItemName("mustardItem").setContainerItem(Item.glassBottle);
         softpretzelItem = new ItemPamFoodFo(itembaseID + 621, 6, 0.6F, false).setIconCoord(11, 7).setItemName("softpretzelItem");
         softpretzelandmustardItem = new ItemPamBowlFoodFo(itembaseID + 622, 8).setIconCoord(3, 8).setItemName("softpretzelandmustardItem");
         spicymustardporkItem = new ItemPamFoodFo(itembaseID + 623, 10, 1.0F, false).setIconCoord(4, 8).setItemName("spicymustardporkItem");
         spicymustardgreensItem = new ItemPamFoodFo(itembaseID + 624, 10, 1.0F, false).setIconCoord(6, 8).setItemName("spicymustardgreensItem");
         veggiepizzaItem = new ItemPamFoodFo(itembaseID + 625, 12, 1.2F, false).setIconCoord(7, 8).setItemName("veggiepizzaItem");
         cheesecakeItem = new ItemPamFoodFo(itembaseID + 626, 10, 1.0F, false).setIconCoord(8, 8).setItemName("cheesecakeItem");
         toppingcheesecakeItem = new ItemPamFoodFo(itembaseID + 627, 12, 1.2F, false).setIconCoord(14, 8).setItemName("toppingcheesecakeItem");
         chocolatecheesecakeItem = new ItemPamFoodFo(itembaseID + 628, 12, 1.2F, false).setIconCoord(0, 9).setItemName("chocolatecheesecakeItem");
         pumpkincheesecakeItem = new ItemPamFoodFo(itembaseID + 629, 12, 1.2F, false).setIconCoord(4, 9).setItemName("pumpkincheesecakeItem");
         barrelItem = new ItemPamFo(itembaseID + 630).setIconCoord(0, 12).setItemName("barrelItem").setContainerItem(Pamcombinedmod.barrelItem);
         waterbarrelItem = new ItemPamFo(itembaseID + 631).setIconCoord(1, 12).setItemName("waterbarrelItem").setContainerItem(Pamcombinedmod.barrelItem);
         milkbarrelItem = new ItemPamFo(itembaseID + 632).setIconCoord(2, 12).setItemName("milkbarrelItem").setContainerItem(Pamcombinedmod.barrelItem);
         buttermilkItem = new ItemPamFo(itembaseID + 633).setIconCoord(3, 12).setItemName("buttermilkItem");
         cafeconlecheItem = new ItemPamFoodFo(itembaseID + 634, 10, 1.0F, false).setIconCoord(4, 12).setItemName("cafeconlecheItem");
         garlicmashedpotatoesItem = new ItemPamBowlFoodFo(itembaseID + 635, 10).setIconCoord(10, 9).setItemName("garlicmashedpotatoesItem");
         garlicchickenItem = new ItemPamFoodFo(itembaseID + 636, 12, 1.2F, false).setIconCoord(11, 9).setItemName("garlicchickenItem");
         garlictoastItem = new ItemPamFoodFo(itembaseID + 637, 10, 1.0F, false).setIconCoord(8, 10).setItemName("garlictoastItem");
         nutmegspiceItem = new ItemPamFo(itembaseID + 638).setIconCoord(5, 12).setItemName("nutmegspiceItem");
         vanillaItem = new ItemPamFo(itembaseID + 639).setIconCoord(6, 12).setItemName("vanillaItem");
         blackpepperItem = new ItemPamFo(itembaseID + 640).setIconCoord(7, 12).setItemName("blackpepperItem");
         beeswaxItem = new ItemPamFo(itembaseID + 641).setIconCoord(15, 8).setItemName("beeswaxItem");
         pressedwaxItem = new ItemPamFo(itembaseID + 642).setIconCoord(8, 12).setItemName("pressedwaxItem");
         cocoapowderItem = new ItemPamFo(itembaseID + 643).setIconCoord(5, 13).setItemName("cocoapowderItem");
         powderedsugarItem = new ItemPamFo(itembaseID + 644).setIconCoord(6, 13).setItemName("powderedsugarItem");
         tablesaltItem = new ItemPamFo(itembaseID + 645).setIconCoord(7, 13).setItemName("tablesaltItem");
         cornmealItem = new ItemPamFo(itembaseID + 646).setIconCoord(8, 13).setItemName("cornmealItem");
         cinnamonspiceItem = new ItemPamFo(itembaseID + 647).setIconCoord(9, 13).setItemName("cinnamonspiceItem");
         groundcoffeeItem = new ItemPamFo(itembaseID + 648).setIconCoord(10, 13).setItemName("groundcoffeeItem");
        //itembaseID + 649 --- 749
         
        zincoreItem = new ItemPamCraftingMats(itembaseID + 750).setIconCoord(0,1).setItemName("zincoreItem");
        tinoreItem = new ItemPamCraftingMats(itembaseID + 751).setIconCoord(1, 1).setItemName("tinoreItem");
        copperoreItem = new ItemPamCraftingMats(itembaseID + 752).setIconCoord(2, 1).setItemName("copperoreItem");
        silveroreItem = new ItemPamCraftingMats(itembaseID + 753).setIconCoord(3, 1).setItemName("silveroreItem");
        cobaltoreItem = new ItemPamCraftingMats(itembaseID + 754).setIconCoord(4, 1).setItemName("cobaltoreItem");
        platinumoreItem = new ItemPamCraftingMats(itembaseID + 755).setIconCoord(5, 1).setItemName("platinumoreItem");
        titaniumoreItem = new ItemPamCraftingMats(itembaseID + 756).setIconCoord(6, 1).setItemName("titaniumoreItem");
        mithriloreItem = new ItemPamCraftingMats(itembaseID + 757).setIconCoord(7, 1).setItemName("mithriloreItem");
        //itembaseID + 757 --- 764
        
        flawedquartzgemItem = new ItemPamCraftingMats(itembaseID + 765).setIconCoord(0, 4).setItemName("flawedquartzgemItem");
        flawedcitrinegemItem = new ItemPamCraftingMats(itembaseID + 766).setIconCoord(1, 4).setItemName("flawedcitrinegemItem");
        flawedtanzanitegemItem = new ItemPamCraftingMats(itembaseID + 767).setIconCoord(2, 4).setItemName("flawedtanzanitegemItem");
        flawedsapphiregemItem = new ItemPamCraftingMats(itembaseID + 768).setIconCoord(3, 4).setItemName("flawedsapphiregemItem");
        flawedtopazgemItem = new ItemPamCraftingMats(itembaseID + 769).setIconCoord(4, 4).setItemName("flawedtopazgemItem");
        flawedagategemItem = new ItemPamCraftingMats(itembaseID + 770).setIconCoord(5, 4).setItemName("flawedagategemItem");
        flawedgarnetgemItem = new ItemPamCraftingMats(itembaseID + 771).setIconCoord(6, 4).setItemName("flawedgarnetgemItem");
        flawedhematitegemItem = new ItemPamCraftingMats(itembaseID + 772).setIconCoord(7, 4).setItemName("flawedhematitegemItem");
        flawedmoonstonegemItem = new ItemPamCraftingMats(itembaseID + 773).setIconCoord(8, 4).setItemName("flawedmoonstonegemItem");
        flawedaquamarinegemItem = new ItemPamCraftingMats(itembaseID + 774).setIconCoord(9, 4).setItemName("flawedaquamarinegemItem");
        flawedamethystgemItem = new ItemPamCraftingMats(itembaseID + 775).setIconCoord(10, 4).setItemName("flawedamethystgemItem");
        flawedtigerseyegemItem = new ItemPamCraftingMats(itembaseID + 776).setIconCoord(11, 4).setItemName("flawedtigerseyegemItem");
        flawedemeraldgemItem = new ItemPamCraftingMats(itembaseID + 777).setIconCoord(12, 4).setItemName("flawedemeraldgemItem");
        flawedrubygemItem = new ItemPamCraftingMats(itembaseID + 778).setIconCoord(13, 4).setItemName("flawedrubygemItem");
        flawedonyxgemItem = new ItemPamCraftingMats(itembaseID + 779).setIconCoord(14, 4).setItemName("flawedonyxgemItem");
        
        zincingotItem = new ItemPamCraftingMats(itembaseID + 780).setIconCoord(0,2).setItemName("zincingotItem");
        tiningotItem = new ItemPamCraftingMats(itembaseID + 781).setIconCoord(1, 2).setItemName("tiningotItem");
        copperingotItem = new ItemPamCraftingMats(itembaseID + 782).setIconCoord(2, 2).setItemName("copperingotItem");
        silveringotItem = new ItemPamCraftingMats(itembaseID + 783).setIconCoord(3, 2).setItemName("silveringotItem");
        cobaltingotItem = new ItemPamCraftingMats(itembaseID + 784).setIconCoord(4, 2).setItemName("cobaltingotItem");
        platinumingotItem = new ItemPamCraftingMats(itembaseID + 785).setIconCoord(5, 2).setItemName("platinumingotItem");
        titaniumingotItem = new ItemPamCraftingMats(itembaseID + 786).setIconCoord(6, 2).setItemName("titaniumingotItem");
        mithrilingotItem = new ItemPamCraftingMats(itembaseID + 787).setIconCoord(7, 2).setItemName("mithrilingotItem");
        bronzealloyItem = new ItemPamCraftingMats(itembaseID + 788).setIconCoord(8, 1).setItemName("bronzealloyItem");
        steelalloyItem = new ItemPamCraftingMats(itembaseID + 789).setIconCoord(9, 1).setItemName("steelalloyItem");
        bronzeingotItem = new ItemPamCraftingMats(itembaseID + 791).setIconCoord(8, 2).setItemName("bronzeingotItem");
        steelingotItem = new ItemPamCraftingMats(itembaseID + 792).setIconCoord(9, 2).setItemName("steelingotItem");
        //itembaseID + 793 --- 803
        
        saltpeterItem = new ItemPamCraftingMats(itembaseID + 804).setIconCoord(1, 3).setItemName("saltpeterItem");
        sulphurItem = new ItemPamCraftingMats(itembaseID + 805).setIconCoord(2, 3).setItemName("sulphurItem");
        //itembaseID + 806 --- 817
        
        EnumToolMaterial toolCOPPER = EnumHelper.addToolMaterial("COPPER", 2, 8, 6.0F, 2, 22);
        EnumToolMaterial toolTIN = EnumHelper.addToolMaterial("TIN", 2, 155, 6.0F, 2, 14);
        EnumToolMaterial toolBRONZE = EnumHelper.addToolMaterial("BRONZE", 2, 205, 6.0F, 2, 14);
        EnumToolMaterial toolSILVER = EnumHelper.addToolMaterial("SILVER", 2, 16, 6.0F, 2, 22);
        EnumToolMaterial toolCOBALT = EnumHelper.addToolMaterial("COBALT", 2, 500, 6.0F, 2, 14);
        EnumToolMaterial toolSTEEL = EnumHelper.addToolMaterial("STEEL", 2, 750, 8.0F, 2, 14);
        EnumToolMaterial toolPLATINUM = EnumHelper.addToolMaterial("PLATINUM", 2, 64, 8.0F, 2, 22);
        EnumToolMaterial toolTITANIUM = EnumHelper.addToolMaterial("TITANIUM", 2, 1000, 8.0F, 2, 14);
        EnumToolMaterial toolMITHRIL = EnumHelper.addToolMaterial("MITHRIL", 3, 64, 8.0F, 3, 22);
        
        copperPick = new ItemPamPickaxe(itembaseID + 818, toolCOPPER).setIconCoord(0, 2).setItemName("copperPick");
        copperShovel = new ItemPamSpade(itembaseID + 819, toolCOPPER).setIconCoord(1, 2).setItemName("copperShovel");
        copperAxe = new ItemPamAxe(itembaseID + 820, toolCOPPER).setIconCoord(2, 2).setItemName("copperAxe");
        copperHoe = new ItemPamHoe(itembaseID + 821, toolCOPPER).setIconCoord(3, 2).setItemName("copperHoe");
        copperSword = new ItemPamSword(itembaseID + 822, toolCOPPER).setIconCoord(4, 2).setItemName("copperSword");
        copperHelm = (new ItemPamArmorEaCopper(itembaseID + 823, armorCopper, 8, 0).setIconCoord(5, 2).setItemName("copperHelm"));
        copperChest = (new ItemPamArmorEaCopper(itembaseID + 824, armorCopper, 8, 1).setIconCoord(6, 2).setItemName("copperChest"));
        copperLegs = (new ItemPamArmorEaCopper(itembaseID + 825, armorCopper, 8, 2).setIconCoord(7, 2).setItemName("copperLegs"));
        copperBoots = (new ItemPamArmorEaCopper(itembaseID + 826, armorCopper, 8, 3).setIconCoord(8, 2).setItemName("copperBoots"));
        tinPick = new ItemPamPickaxe(itembaseID + 827, toolTIN).setIconCoord(0, 3).setItemName("tinPick");
        tinShovel = new ItemPamSpade(itembaseID + 828, toolTIN).setIconCoord(1, 3).setItemName("tinShovel");
        tinAxe = new ItemPamAxe(itembaseID + 829, toolTIN).setIconCoord(2, 3).setItemName("tinAxe");
        tinHoe = new ItemPamHoe(itembaseID + 830, toolTIN).setIconCoord(3, 3).setItemName("tinHoe");
        tinSword = new ItemPamSword(itembaseID + 831, toolTIN).setIconCoord(4, 3).setItemName("tinSword");
        tinHelm = (new ItemPamArmorEaTin(itembaseID + 832, armorTin, 9, 0).setIconCoord(5, 3).setItemName("tinHelm"));
        tinChest = (new ItemPamArmorEaTin(itembaseID + 833, armorTin, 9, 1).setIconCoord(6, 3).setItemName("tinChest"));
        tinLegs = (new ItemPamArmorEaTin(itembaseID + 834, armorTin, 9, 2).setIconCoord(7, 3).setItemName("tinLegs"));
        tinBoots = (new ItemPamArmorEaTin(itembaseID + 835, armorTin, 9, 3).setIconCoord(8, 3).setItemName("tinBoots"));
        bronzePick = new ItemPamPickaxe(itembaseID + 836, toolBRONZE).setIconCoord(0, 4).setItemName("bronzePick");
        bronzeShovel = new ItemPamSpade(itembaseID + 837, toolBRONZE).setIconCoord(1, 4).setItemName("bronzeShovel");
        bronzeAxe = new ItemPamAxe(itembaseID + 838, toolBRONZE).setIconCoord(2, 4).setItemName("bronzeAxe");
        bronzeHoe = new ItemPamHoe(itembaseID + 839, toolBRONZE).setIconCoord(3, 4).setItemName("bronzeHoe");
        bronzeSword = new ItemPamSword(itembaseID + 840, toolBRONZE).setIconCoord(4, 4).setItemName("bronzeSword");
        bronzeHelm = (new ItemPamArmorEaBronze(itembaseID + 841, armorBronze, 10, 0).setIconCoord(5, 4).setItemName("bronzeHelm"));
        bronzeChest = (new ItemPamArmorEaBronze(itembaseID + 842, armorBronze, 10, 1).setIconCoord(6, 4).setItemName("bronzeChest"));
        bronzeLegs = (new ItemPamArmorEaBronze(itembaseID + 843, armorBronze, 10, 2).setIconCoord(7, 4).setItemName("bronzeLegs"));
        bronzeBoots = (new ItemPamArmorEaBronze(itembaseID + 844, armorBronze, 10, 3).setIconCoord(8, 4).setItemName("bronzeBoots"));
        silverPick = new ItemPamPickaxe(itembaseID + 845, toolSILVER).setIconCoord(0, 5).setItemName("silverPick");
        silverShovel = new ItemPamSpade(itembaseID + 846, toolSILVER).setIconCoord(1, 5).setItemName("silverShovel");
        silverAxe = new ItemPamAxe(itembaseID + 847, toolSILVER).setIconCoord(2, 5).setItemName("silverAxe");
        silverHoe = new ItemPamHoe(itembaseID + 848, toolSILVER).setIconCoord(3, 5).setItemName("silverHoe");
        silverSword = new ItemPamSword(itembaseID + 849, toolSILVER).setIconCoord(4, 5).setItemName("silverSword");
        silverHelm = (new ItemPamArmorEaSilver(itembaseID + 850, armorSilver, 11, 0).setIconCoord(5, 5).setItemName("silverHelm"));
        silverChest = (new ItemPamArmorEaSilver(itembaseID + 851, armorSilver, 11, 1).setIconCoord(6, 5).setItemName("silverChest"));
        silverLegs = (new ItemPamArmorEaSilver(itembaseID + 852, armorSilver, 11, 2).setIconCoord(7, 5).setItemName("silverLegs"));
        silverBoots = (new ItemPamArmorEaSilver(itembaseID + 853, armorSilver, 11, 3).setIconCoord(8, 5).setItemName("silverBoots"));
        cobaltPick = new ItemPamPickaxe(itembaseID + 854, toolCOBALT).setIconCoord(0, 6).setItemName("cobaltPick");
        cobaltShovel = new ItemPamSpade(itembaseID + 855, toolCOBALT).setIconCoord(1, 6).setItemName("cobaltShovel");
        cobaltAxe = new ItemPamAxe(itembaseID + 856, toolCOBALT).setIconCoord(2, 6).setItemName("cobaltAxe");
        cobaltHoe = new ItemPamHoe(itembaseID + 857, toolCOBALT).setIconCoord(3, 6).setItemName("cobaltHoe");
        cobaltSword = new ItemPamSword(itembaseID + 858, toolCOBALT).setIconCoord(4, 6).setItemName("cobaltSword");
        cobaltHelm = (new ItemPamArmorEaCobalt(itembaseID + 859, armorCobalt, 12, 0).setIconCoord(5, 6).setItemName("cobaltHelm"));
        cobaltChest = (new ItemPamArmorEaCobalt(itembaseID + 860, armorCobalt, 12, 1).setIconCoord(6, 6).setItemName("cobaltChest"));
        cobaltLegs = (new ItemPamArmorEaCobalt(itembaseID + 861, armorCobalt, 12, 2).setIconCoord(7, 6).setItemName("cobaltLegs"));
        cobaltBoots = (new ItemPamArmorEaCobalt(itembaseID + 862, armorCobalt, 12, 3).setIconCoord(8, 6).setItemName("cobaltBoots"));
        steelPick = new ItemPamPickaxe(itembaseID + 863, toolSTEEL).setIconCoord(0, 7).setItemName("steelPick");
        steelShovel = new ItemPamSpade(itembaseID + 864, toolSTEEL).setIconCoord(1, 7).setItemName("steelShovel");
        steelAxe = new ItemPamAxe(itembaseID + 865, toolSTEEL).setIconCoord(2, 7).setItemName("steelAxe");
        steelHoe = new ItemPamHoe(itembaseID + 866, toolSTEEL).setIconCoord(3, 7).setItemName("steelHoe");
        steelSword = new ItemPamSword(itembaseID + 867, toolSTEEL).setIconCoord(4, 7).setItemName("steelSword");
        steelHelm = (new ItemPamArmorEaSteel(itembaseID + 868, armorSteel, 13, 0).setIconCoord(5, 7).setItemName("steelHelm"));
        steelChest = (new ItemPamArmorEaSteel(itembaseID + 869, armorSteel, 13, 1).setIconCoord(6, 7).setItemName("steelChest"));
        steelLegs = (new ItemPamArmorEaSteel(itembaseID + 870, armorSteel, 13, 2).setIconCoord(7, 7).setItemName("steelLegs"));
        steelBoots = (new ItemPamArmorEaSteel(itembaseID + 871, armorSteel, 13, 3).setIconCoord(8, 7).setItemName("steelBoots"));
        platinumPick = new ItemPamPickaxe(itembaseID + 872, toolPLATINUM).setIconCoord(0, 8).setItemName("platinumPick");
        platinumShovel = new ItemPamSpade(itembaseID + 873, toolPLATINUM).setIconCoord(1, 8).setItemName("platinumShovel");
        platinumAxe = new ItemPamAxe(itembaseID + 874, toolPLATINUM).setIconCoord(2, 8).setItemName("platinumAxe");
        platinumHoe = new ItemPamHoe(itembaseID + 875, toolPLATINUM).setIconCoord(3, 8).setItemName("platinumHoe");
        platinumSword = new ItemPamSword(itembaseID + 876, toolPLATINUM).setIconCoord(4, 8).setItemName("platinumSword");
        platinumHelm = (new ItemPamArmorEaPlatinum(itembaseID + 877, armorPlatinum, 14, 0).setIconCoord(5, 8).setItemName("platinumHelm"));
        platinumChest = (new ItemPamArmorEaPlatinum(itembaseID + 878, armorPlatinum, 14, 1).setIconCoord(6, 8).setItemName("platinumChest"));
        platinumLegs = (new ItemPamArmorEaPlatinum(itembaseID + 879, armorPlatinum, 14, 2).setIconCoord(7, 8).setItemName("platinumLegs"));
        platinumBoots = (new ItemPamArmorEaPlatinum(itembaseID + 880, armorPlatinum, 14, 3).setIconCoord(8, 8).setItemName("platinumBoots"));
        titaniumPick = new ItemPamPickaxe(itembaseID + 881, toolTITANIUM).setIconCoord(0, 9).setItemName("titaniumPick");
        titaniumShovel = new ItemPamSpade(itembaseID + 882, toolTITANIUM).setIconCoord(1, 9).setItemName("titaniumShovel");
        titaniumAxe = new ItemPamAxe(itembaseID + 883, toolTITANIUM).setIconCoord(2, 9).setItemName("titaniumAxe");
        titaniumHoe = new ItemPamHoe(itembaseID + 884, toolTITANIUM).setIconCoord(3, 9).setItemName("titaniumHoe");
        titaniumSword = new ItemPamSword(itembaseID + 885, toolTITANIUM).setIconCoord(4, 9).setItemName("titaniumSword");
        titaniumHelm = (new ItemPamArmorEaTitanium(itembaseID + 886, armorTitanium, 15, 0).setIconCoord(5, 9).setItemName("titaniumHelm"));
        titaniumChest = (new ItemPamArmorEaTitanium(itembaseID + 887, armorTitanium, 15, 1).setIconCoord(6, 9).setItemName("titaniumChest"));
        titaniumLegs = (new ItemPamArmorEaTitanium(itembaseID + 888, armorTitanium, 15, 2).setIconCoord(7, 9).setItemName("titaniumLegs"));
        titaniumBoots = (new ItemPamArmorEaTitanium(itembaseID + 889, armorTitanium, 15, 3).setIconCoord(8, 9).setItemName("titaniumBoots"));
        mithrilPick = new ItemPamPickaxe(itembaseID + 890, toolMITHRIL).setIconCoord(0, 10).setItemName("mithrilPick");
        mithrilShovel = new ItemPamSpade(itembaseID + 891, toolMITHRIL).setIconCoord(1, 10).setItemName("mithrilShovel");
        mithrilAxe = new ItemPamAxe(itembaseID + 892, toolMITHRIL).setIconCoord(2, 10).setItemName("mithrilAxe");
        mithrilHoe = new ItemPamHoe(itembaseID + 893, toolMITHRIL).setIconCoord(3, 10).setItemName("mithrilHoe");
        mithrilSword = new ItemPamSword(itembaseID + 894, toolMITHRIL).setIconCoord(4, 10).setItemName("mithrilSword");
        mithrilHelm = (new ItemPamArmorEaMithril(itembaseID + 896, armorMithril, 16, 0).setIconCoord(5, 10).setItemName("mithrilHelm"));
        mithrilChest = (new ItemPamArmorEaMithril(itembaseID + 897, armorMithril, 16, 1).setIconCoord(6, 10).setItemName("mithrilChest"));
        mithrilLegs = (new ItemPamArmorEaMithril(itembaseID + 898, armorMithril, 16, 2).setIconCoord(7, 10).setItemName("mithrilLegs"));
        mithrilBoots = (new ItemPamArmorEaMithril(itembaseID + 899, armorMithril, 16, 3).setIconCoord(8, 10).setItemName("mithrilBoots"));
        
        MinecraftForge.setToolClass(Pamcombinedmod.cactusPick, "pickaxe", 0);
        MinecraftForge.setToolClass(Pamcombinedmod.cactusAxe, "axe", 0);
        MinecraftForge.setToolClass(Pamcombinedmod.cactusShovel, "shovel", 0);
        MinecraftForge.setToolClass(Pamcombinedmod.bonePick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.boneAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.boneShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.copperPick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.tinPick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.bronzePick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.silverPick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.cobaltPick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.steelPick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.platinumPick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.titaniumPick, "pickaxe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.mithrilPick, "pickaxe", 3);
        MinecraftForge.setToolClass(Pamcombinedmod.copperAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.tinAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.bronzeAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.silverAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.cobaltAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.steelAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.platinumAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.titaniumAxe, "axe", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.mithrilAxe, "axe", 3);
        MinecraftForge.setToolClass(Pamcombinedmod.copperShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.tinShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.bronzeShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.silverShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.cobaltShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.steelShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.platinumShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.titaniumShovel, "shovel", 2);
        MinecraftForge.setToolClass(Pamcombinedmod.mithrilShovel, "shovel", 3);
        
    	ModLoader.registerBlock(pamFlower, ItemPamFlower.class);
    	ModLoader.registerBlock(pamdesertPlant, ItemPamDesertPlant.class);
    	ModLoader.registerBlock(pamtemperatePlant, ItemPamTemperatePlant.class);
    	ModLoader.registerBlock(pamFruit, ItemPamTreeFruit.class);
    	ModLoader.registerBlock(pamwarmFruit, ItemPamTreeWarmFruit.class);
    	ModLoader.registerBlock(pamBush, ItemPamBush.class);
    	ModLoader.registerBlock(pamwarmBush, ItemPamWarmBush.class);
    	ModLoader.registerBlock(pamcoldBush, ItemPamColdBush.class);
    	ModLoader.registerBlock(pamMineral, ItemPamMineral.class);
    	ModLoader.registerBlock(pamOre, ItemPamOre.class);
    	ModLoader.registerBlock(pamGem, ItemPamGem.class);
    	ModLoader.registerBlock(pamcoloredSmoothstone, ItemPamColoredSmoothstone.class);
    	ModLoader.registerBlock(pamSapling, ItemPamSapling.class);
    	ModLoader.registerBlock(pamwarmSapling, ItemPamWarmSapling.class);
    	ModLoader.registerBlock(pamcoloredPlank, ItemPamColoredPlank.class);
    	ModLoader.registerBlock(pamcoloredwoodFence, ItemPamColoredWoodFence.class);
    	ModLoader.registerBlock(pamcoloredwoodstairsWhite);
    	ModLoader.registerBlock(pamcoloredwoodstairsOrange);
    	ModLoader.registerBlock(pamcoloredwoodstairsMagenta);
    	ModLoader.registerBlock(pamcoloredwoodstairsLightblue);
    	ModLoader.registerBlock(pamcoloredwoodstairsYellow);
    	ModLoader.registerBlock(pamcoloredwoodstairsLime);
    	ModLoader.registerBlock(pamcoloredwoodstairsPink);
    	ModLoader.registerBlock(pamcoloredwoodstairsDarkgrey);
    	ModLoader.registerBlock(pamcoloredwoodstairsLightgrey);
    	ModLoader.registerBlock(pamcoloredwoodstairsCyan);
    	ModLoader.registerBlock(pamcoloredwoodstairsPurple);
    	ModLoader.registerBlock(pamcoloredwoodstairsBlue);
    	ModLoader.registerBlock(pamcoloredwoodstairsBrown);
    	ModLoader.registerBlock(pamcoloredwoodstairsGreen);
    	ModLoader.registerBlock(pamcoloredwoodstairsRed);
    	ModLoader.registerBlock(pamcoloredwoodstairsBlack);
    	ModLoader.registerBlock(pamcoloredwoodslabWhite);
    	ModLoader.registerBlock(pamcoloredwoodslabOrange);
    	ModLoader.registerBlock(pamcoloredwoodslabMagenta);
    	ModLoader.registerBlock(pamcoloredwoodslabLightblue);
    	ModLoader.registerBlock(pamcoloredwoodslabYellow);
    	ModLoader.registerBlock(pamcoloredwoodslabLime);
    	ModLoader.registerBlock(pamcoloredwoodslabPink);
    	ModLoader.registerBlock(pamcoloredwoodslabDarkgrey);
    	ModLoader.registerBlock(pamcoloredwoodslabLightgrey);
    	ModLoader.registerBlock(pamcoloredwoodslabCyan);
    	ModLoader.registerBlock(pamcoloredwoodslabPurple);
    	ModLoader.registerBlock(pamcoloredwoodslabBlue);
    	ModLoader.registerBlock(pamcoloredwoodslabBrown);
    	ModLoader.registerBlock(pamcoloredwoodslabGreen);
    	ModLoader.registerBlock(pamcoloredwoodslabRed);
    	ModLoader.registerBlock(pamcoloredwoodslabBlack);
    	ModLoader.registerBlock(pamcoloredwoodThin, ItemPamColoredWoodThin.class);
    	ModLoader.registerBlock(pamcoloredwoodfencegateWhite);
    	ModLoader.registerBlock(pamcoloredwoodfencegateOrange);
    	ModLoader.registerBlock(pamcoloredwoodfencegateMagenta);
    	ModLoader.registerBlock(pamcoloredwoodfencegateLightblue);
    	ModLoader.registerBlock(pamcoloredwoodfencegateYellow);
    	ModLoader.registerBlock(pamcoloredwoodfencegateLime);
    	ModLoader.registerBlock(pamcoloredwoodfencegatePink);
    	ModLoader.registerBlock(pamcoloredwoodfencegateDarkgrey);
    	ModLoader.registerBlock(pamcoloredwoodfencegateLightgrey);
    	ModLoader.registerBlock(pamcoloredwoodfencegateCyan);
    	ModLoader.registerBlock(pamcoloredwoodfencegatePurple);
    	ModLoader.registerBlock(pamcoloredwoodfencegateBlue);
    	ModLoader.registerBlock(pamcoloredwoodfencegateBrown);
    	ModLoader.registerBlock(pamcoloredwoodfencegateGreen);
    	ModLoader.registerBlock(pamcoloredwoodfencegateRed);
    	ModLoader.registerBlock(pamcoloredwoodfencegateBlack);
    	
    	ModLoader.registerBlock(pamcoloredCobblestone, ItemPamColoredCobblestone.class);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsWhite);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsOrange);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsMagenta);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsLightblue);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsYellow);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsLime);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsPink);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsDarkgrey);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsLightgrey);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsCyan);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsPurple);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsBlue);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsBrown);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsGreen);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsRed);
    	ModLoader.registerBlock(pamcoloredcobblestonestairsBlack);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabWhite);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabOrange);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabMagenta);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabLightblue);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabYellow);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabLime);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabPink);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabDarkgrey);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabLightgrey);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabCyan);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabPurple);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabBlue);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabBrown);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabGreen);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabRed);
    	ModLoader.registerBlock(pamcoloredcobblestoneslabBlack);
    	ModLoader.registerBlock(pamcoloredcobblestoneThin, ItemPamColoredCobblestoneThin.class);
    	
    	ModLoader.registerBlock(pamcoloredclothstairsWhite);
    	ModLoader.registerBlock(pamcoloredclothstairsOrange);
    	ModLoader.registerBlock(pamcoloredclothstairsMagenta);
    	ModLoader.registerBlock(pamcoloredclothstairsLightblue);
    	ModLoader.registerBlock(pamcoloredclothstairsYellow);
    	ModLoader.registerBlock(pamcoloredclothstairsLime);
    	ModLoader.registerBlock(pamcoloredclothstairsPink);
    	ModLoader.registerBlock(pamcoloredclothstairsDarkgrey);
    	ModLoader.registerBlock(pamcoloredclothstairsLightgrey);
    	ModLoader.registerBlock(pamcoloredclothstairsCyan);
    	ModLoader.registerBlock(pamcoloredclothstairsPurple);
    	ModLoader.registerBlock(pamcoloredclothstairsBlue);
    	ModLoader.registerBlock(pamcoloredclothstairsBrown);
    	ModLoader.registerBlock(pamcoloredclothstairsGreen);
    	ModLoader.registerBlock(pamcoloredclothstairsRed);
    	ModLoader.registerBlock(pamcoloredclothstairsBlack);
    	ModLoader.registerBlock(pamcoloredclothslabWhite);
    	ModLoader.registerBlock(pamcoloredclothslabOrange);
    	ModLoader.registerBlock(pamcoloredclothslabMagenta);
    	ModLoader.registerBlock(pamcoloredclothslabLightblue);
    	ModLoader.registerBlock(pamcoloredclothslabYellow);
    	ModLoader.registerBlock(pamcoloredclothslabLime);
    	ModLoader.registerBlock(pamcoloredclothslabPink);
    	ModLoader.registerBlock(pamcoloredclothslabDarkgrey);
    	ModLoader.registerBlock(pamcoloredclothslabLightgrey);
    	ModLoader.registerBlock(pamcoloredclothslabCyan);
    	ModLoader.registerBlock(pamcoloredclothslabPurple);
    	ModLoader.registerBlock(pamcoloredclothslabBlue);
    	ModLoader.registerBlock(pamcoloredclothslabBrown);
    	ModLoader.registerBlock(pamcoloredclothslabGreen);
    	ModLoader.registerBlock(pamcoloredclothslabRed);
    	ModLoader.registerBlock(pamcoloredclothslabBlack);
    	ModLoader.registerBlock(pamcoloredclothThin, ItemPamColoredClothThin.class);
    	
    	ModLoader.registerBlock(pammetalBlock, ItemPamMetalBlock.class);
    	ModLoader.registerBlock(pamgemBlock, ItemPamGemBlock.class);
    	ModLoader.registerBlock(pamcoloredClay, ItemPamColoredClay.class);
    	ModLoader.registerBlock(pamcoloredSand, ItemPamColoredSand.class);
    	ModLoader.registerBlock(pamcoloredBookshelf, ItemPamColoredBookshelf.class);
    	ModLoader.registerBlock(pamcoloredLeaves, ItemPamColoredLeaves.class);
    	ModLoader.registerBlock(pamcoloredWood, ItemPamColoredWood.class);
    	ModLoader.registerBlock(pamstonePaver, ItemPamStonePaver.class);
    	ModLoader.registerBlock(pamWindow, ItemPamWindow.class);
    	ModLoader.registerBlock(pamcoloredGlass, ItemPamColoredGlass.class);
    	
        ModLoader.registerBlock(pamChurn); // ADDED
        ModLoader.addName(pamChurn, "Butter Churn"); // ADDED
        ModLoader.registerTileEntity(TileEntityPamChurn.class, "Butter Churn"); // ADDED
        ModLoader.registerBlock(pamQuern); // ADDED
        ModLoader.addName(pamQuern, "Quern"); // ADDED
        ModLoader.registerTileEntity(TileEntityPamQuern.class, "Quern"); // ADDED
        
        ModLoader.registerBlock(pamcropboxOne, ItemPamCropBoxOne.class);
    	
    	
    	if (generateflower)
    	{
    	MinecraftForge.addGrassPlant(pamFlower, 0, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 1, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 2, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 3, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 4, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 5, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 6, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 7, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 8, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 9, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 10, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 11, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 12, 25);
    	MinecraftForge.addGrassPlant(pamFlower, 13, 25);
    	}
    	
    	if (generatetemperateplant)
    	{
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 0, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 1, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 2, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 3, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 4, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 5, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 6, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 7, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 8, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 9, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 10, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 11, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 12, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 13, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 14, 25);
    	MinecraftForge.addGrassPlant(pamtemperatePlant, 15, 25);
    	}
    	
    	if (generatebush)
    	{
    	MinecraftForge.addGrassPlant(pamBush, 0, 15);
    	MinecraftForge.addGrassPlant(pamBush, 1, 15);
    	MinecraftForge.addGrassPlant(pamBush, 2, 15);
    	MinecraftForge.addGrassPlant(pamBush, 3, 15);
    	MinecraftForge.addGrassPlant(pamBush, 4, 15);
    	MinecraftForge.addGrassPlant(pamBush, 5, 15);
    	MinecraftForge.addGrassPlant(pamBush, 6, 15);
    	MinecraftForge.addGrassPlant(pamBush, 7, 15);
    	}
    	
    	if (generatewarmbush)
    	{
    	MinecraftForge.addGrassPlant(pamwarmBush, 0, 15);
    	MinecraftForge.addGrassPlant(pamwarmBush, 1, 15);
    	MinecraftForge.addGrassPlant(pamwarmBush, 2, 15);
    	MinecraftForge.addGrassPlant(pamwarmBush, 3, 15);
    	MinecraftForge.addGrassPlant(pamwarmBush, 4, 15);
    	MinecraftForge.addGrassPlant(pamwarmBush, 5, 15);
    	MinecraftForge.addGrassPlant(pamwarmBush, 6, 15);
    	}
    	
    	if (generatecoldbush)
    	{
    	MinecraftForge.addGrassPlant(pamcoldBush, 0, 15);
    	MinecraftForge.addGrassPlant(pamcoldBush, 1, 15);
    	MinecraftForge.addGrassPlant(pamcoldBush, 2, 15);
    	}
    	
    	if (generatefruittree)
    	{
    	MinecraftForge.addGrassPlant(pamSapling, 0, 15);
    	MinecraftForge.addGrassPlant(pamSapling, 1, 15);
    	MinecraftForge.addGrassPlant(pamSapling, 2, 15);
    	MinecraftForge.addGrassPlant(pamSapling, 3, 15);
    	MinecraftForge.addGrassPlant(pamSapling, 4, 15);
    	MinecraftForge.addGrassPlant(pamSapling, 5, 15);
    	}
    	
    	if (generatewarmfruittree)
    	{
    	MinecraftForge.addGrassPlant(pamwarmSapling, 0, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 1, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 2, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 3, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 4, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 5, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 6, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 7, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 8, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 9, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 10, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 11, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 12, 15);
    	MinecraftForge.addGrassPlant(pamwarmSapling, 13, 15);
    	}
    	
    	if (flowerseedgrassdrop)
        {
    		MinecraftForge.addGrassSeed((new ItemStack(whiteflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(orangeflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(magentaflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(lightblueflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(yellowflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(limeflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(pinkflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(darkgreyflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(lightgreyflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(cyanflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(purpleflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(blueflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(brownflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(greenflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(redflowerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(blackflowerseedItem.shiftedIndex, 1, 0)), 10);
        }
    	
    	if (cropsseedgrassdrop)
    	{
    		MinecraftForge.addGrassSeed((new ItemStack(tomatoseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(potatoseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(lettuceseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(onionseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(carrotseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(cornseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(peanutseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(cucumberseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(riceseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(beansseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(bellpepperseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(eggplantseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(teaseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(coffeeseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(beetseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(broccoliseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(sweetpotatoseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(peasseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(pineappleseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(turnipseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(gingerseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(mustardseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(garlicseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(harvestwheatseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(radishseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(celeryseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(zucchiniseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(chilipepperseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(cantaloupeseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(asparagusseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(cranberryseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(spiceleafseedItem.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(Item.pumpkinSeeds.shiftedIndex, 1, 0)), 10);
            MinecraftForge.addGrassSeed((new ItemStack(Item.melonSeeds.shiftedIndex, 1, 0)), 10);
    	}
    	
    	flowerTex[0] = 0;
        flowerTex[1] = 1;
        flowerTex[2] = 2;
        flowerTex[3] = 3;
        flowerTex[4] = 4;
        flowerTex[5] = 5;
        flowerTex[6] = 6;
        flowerTex[7] = 7;
        flowerTex[8] = 8;
        flowerTex[9] = 9;
        flowerTex[10] = 10;
        flowerTex[11] = 11;
        flowerTex[12] = 12;
        flowerTex[13] = 13; 
        
        desertplantTex[0] = 16;
        desertplantTex[1] = 17;
        desertplantTex[2] = 18;
        desertplantTex[3] = 19;
        desertplantTex[4] = 20;
        desertplantTex[5] = 21;
        desertplantTex[6] = 22;
        desertplantTex[7] = 23;
        desertplantTex[8] = 24;
        desertplantTex[9] = 25;
        desertplantTex[10] = 26;
        desertplantTex[11] = 27;
        desertplantTex[12] = 28;
        desertplantTex[13] = 29;
        desertplantTex[14] = 30;
        desertplantTex[15] = 31;
        
        temperateplantTex[0] = 32;
        temperateplantTex[1] = 33;
        temperateplantTex[2] = 34;
        temperateplantTex[3] = 35;
        temperateplantTex[4] = 36;
        temperateplantTex[5] = 37;
        temperateplantTex[6] = 38;
        temperateplantTex[7] = 39;
        temperateplantTex[8] = 40;
        temperateplantTex[9] = 41;
        temperateplantTex[10] = 42;
        temperateplantTex[11] = 43;
        temperateplantTex[12] = 44;
        temperateplantTex[13] = 45;
        temperateplantTex[14] = 46;
        temperateplantTex[15] = 47;
        
        fruitTex[0] = 48;
        fruitTex[1] = 49;
        fruitTex[2] = 50;
        fruitTex[3] = 51;
        fruitTex[4] = 52;
        fruitTex[5] = 53;
        fruitTex[6] = 54;
        fruitTex[7] = 55;
        fruitTex[8] = 56;
        fruitTex[9] = 57;
        fruitTex[10] = 58;
        fruitTex[11] = 59;
        fruitTex[12] = 60;
        fruitTex[13] = 61;
        fruitTex[14] = 62;
        fruitTex[15] = 63;
        
        warmfruitTex[0] = 64;
        warmfruitTex[1] = 65;
        warmfruitTex[2] = 66;
        warmfruitTex[3] = 67;
        warmfruitTex[4] = 68;
        warmfruitTex[5] = 69;
        warmfruitTex[6] = 70;
        warmfruitTex[7] = 71;
        warmfruitTex[8] = 72;
        warmfruitTex[9] = 73;
        warmfruitTex[10] = 74;
        warmfruitTex[11] = 75;
        warmfruitTex[12] = 76;
        warmfruitTex[13] = 77;
        warmfruitTex[14] = 78;
        warmfruitTex[15] = 79;
        
        bushTex[0] = 144;
        bushTex[1] = 145;
        bushTex[2] = 146;
        bushTex[3] = 147;
        bushTex[4] = 148;
        bushTex[5] = 149;
        bushTex[6] = 150;
        bushTex[7] = 151;
        bushTex[8] = 152;
        bushTex[9] = 153;
        bushTex[10] = 154;
        bushTex[11] = 155;
        bushTex[12] = 156;
        bushTex[13] = 157;
        bushTex[14] = 158;
        bushTex[15] = 159;
        
        warmbushTex[0] = 160;
        warmbushTex[1] = 161;
        warmbushTex[2] = 162;
        warmbushTex[3] = 163;
        warmbushTex[4] = 164;
        warmbushTex[5] = 165;
        warmbushTex[6] = 166;
        warmbushTex[7] = 167;
        warmbushTex[8] = 168;
        warmbushTex[9] = 169;
        warmbushTex[10] = 170;
        warmbushTex[11] = 171;
        warmbushTex[12] = 172;
        warmbushTex[13] = 173;
        warmbushTex[14] = 174;
        warmbushTex[15] = 175;
        
        coldbushTex[0] = 176;
        coldbushTex[1] = 177;
        coldbushTex[2] = 178;
        coldbushTex[3] = 179;
        coldbushTex[4] = 180;
        coldbushTex[5] = 181;
        coldbushTex[6] = 182;
        coldbushTex[7] = 183;
        coldbushTex[8] = 184;
        coldbushTex[9] = 185;
        coldbushTex[10] = 186;
        coldbushTex[11] = 187;
        coldbushTex[12] = 188;
        coldbushTex[13] = 189;
        coldbushTex[14] = 190;
        coldbushTex[15] = 191;
        
        mineralTex[0] = 192;
        mineralTex[1] = 193;
        mineralTex[2] = 194;
        mineralTex[3] = 195;
        mineralTex[4] = 196;
        mineralTex[5] = 197;
        mineralTex[6] = 198;
        mineralTex[7] = 199;
        mineralTex[8] = 200;
        mineralTex[9] = 201;
        mineralTex[10] = 202;
        mineralTex[11] = 203;
        mineralTex[12] = 204;
        mineralTex[13] = 205;
        mineralTex[14] = 206;
        mineralTex[15] = 207;
        
        oreTex[0] = 208;
        oreTex[1] = 209;
        oreTex[2] = 210;
        oreTex[3] = 211;
        oreTex[4] = 212;
        oreTex[5] = 213;
        oreTex[6] = 214;
        oreTex[7] = 215;
        oreTex[8] = 216;
        oreTex[9] = 217;
        oreTex[10] = 218;
        oreTex[11] = 219;
        oreTex[12] = 220;
        oreTex[13] = 221;
        oreTex[14] = 222;
        oreTex[15] = 223;
        
        gemTex[0] = 224;
        gemTex[1] = 225;
        gemTex[2] = 226;
        gemTex[3] = 227;
        gemTex[4] = 228;
        gemTex[5] = 229;
        gemTex[6] = 230;
        gemTex[7] = 231;
        gemTex[8] = 232;
        gemTex[9] = 233;
        gemTex[10] = 234;
        gemTex[11] = 235;
        gemTex[12] = 236;
        gemTex[13] = 237;
        gemTex[14] = 238;
        gemTex[15] = 239;
        
        coloredsmoothstoneTex[0] = 240;
        coloredsmoothstoneTex[1] = 241;
        coloredsmoothstoneTex[2] = 242;
        coloredsmoothstoneTex[3] = 243;
        coloredsmoothstoneTex[4] = 244;
        coloredsmoothstoneTex[5] = 245;
        coloredsmoothstoneTex[6] = 246;
        coloredsmoothstoneTex[7] = 247;
        coloredsmoothstoneTex[8] = 248;
        coloredsmoothstoneTex[9] = 249;
        coloredsmoothstoneTex[10] = 250;
        coloredsmoothstoneTex[11] = 251;
        coloredsmoothstoneTex[12] = 252;
        coloredsmoothstoneTex[13] = 253;
        coloredsmoothstoneTex[14] = 254;
        coloredsmoothstoneTex[15] = 255;
        
        coloredplankTex[0] = 0;
        coloredplankTex[1] = 1;
        coloredplankTex[2] = 2;
        coloredplankTex[3] = 3;
        coloredplankTex[4] = 4;
        coloredplankTex[5] = 5;
        coloredplankTex[6] = 6;
        coloredplankTex[7] = 7;
        coloredplankTex[8] = 8;
        coloredplankTex[9] = 9;
        coloredplankTex[10] = 10;
        coloredplankTex[11] = 11;
        coloredplankTex[12] = 12;
        coloredplankTex[13] = 13;
        coloredplankTex[14] = 14;
        coloredplankTex[15] = 15;
        
        coloredwoodfenceTex[0] = 0;
        coloredwoodfenceTex[1] = 1;
        coloredwoodfenceTex[2] = 2;
        coloredwoodfenceTex[3] = 3;
        coloredwoodfenceTex[4] = 4;
        coloredwoodfenceTex[5] = 5;
        coloredwoodfenceTex[6] = 6;
        coloredwoodfenceTex[7] = 7;
        coloredwoodfenceTex[8] = 8;
        coloredwoodfenceTex[9] = 9;
        coloredwoodfenceTex[10] = 10;
        coloredwoodfenceTex[11] = 11;
        coloredwoodfenceTex[12] = 12;
        coloredwoodfenceTex[13] = 13;
        coloredwoodfenceTex[14] = 14;
        coloredwoodfenceTex[15] = 15;
     
        pamcoloredwoodslabWhite.blockIndexInTexture = 0;
        pamcoloredwoodslabOrange.blockIndexInTexture = 1;
        pamcoloredwoodslabMagenta.blockIndexInTexture = 2;
        pamcoloredwoodslabLightblue.blockIndexInTexture = 3;
        pamcoloredwoodslabYellow.blockIndexInTexture = 4;
        pamcoloredwoodslabLime.blockIndexInTexture = 5;
        pamcoloredwoodslabPink.blockIndexInTexture = 6;
        pamcoloredwoodslabDarkgrey.blockIndexInTexture = 7;
        pamcoloredwoodslabLightgrey.blockIndexInTexture = 8;
        pamcoloredwoodslabCyan.blockIndexInTexture = 9;
        pamcoloredwoodslabPurple.blockIndexInTexture = 10;
        pamcoloredwoodslabBlue.blockIndexInTexture = 11;
        pamcoloredwoodslabBrown.blockIndexInTexture = 12;
        pamcoloredwoodslabGreen.blockIndexInTexture = 13;
        pamcoloredwoodslabRed.blockIndexInTexture = 14;
        pamcoloredwoodslabBlack.blockIndexInTexture = 15;
        
        coloredcobblestoneTex[0] = 96;
        coloredcobblestoneTex[1] = 97;
        coloredcobblestoneTex[2] = 98;
        coloredcobblestoneTex[3] = 99;
        coloredcobblestoneTex[4] = 100;
        coloredcobblestoneTex[5] = 101;
        coloredcobblestoneTex[6] = 102;
        coloredcobblestoneTex[7] = 103;
        coloredcobblestoneTex[8] = 104;
        coloredcobblestoneTex[9] = 105;
        coloredcobblestoneTex[10] = 106;
        coloredcobblestoneTex[11] = 107;
        coloredcobblestoneTex[12] = 108;
        coloredcobblestoneTex[13] = 109;
        coloredcobblestoneTex[14] = 110;
        coloredcobblestoneTex[15] = 111;
     
        pamcoloredcobblestoneslabWhite.blockIndexInTexture = 96;
        pamcoloredcobblestoneslabOrange.blockIndexInTexture = 97;
        pamcoloredcobblestoneslabMagenta.blockIndexInTexture = 98;
        pamcoloredcobblestoneslabLightblue.blockIndexInTexture = 99;
        pamcoloredcobblestoneslabYellow.blockIndexInTexture = 100;
        pamcoloredcobblestoneslabLime.blockIndexInTexture = 101;
        pamcoloredcobblestoneslabPink.blockIndexInTexture = 102;
        pamcoloredcobblestoneslabDarkgrey.blockIndexInTexture = 103;
        pamcoloredcobblestoneslabLightgrey.blockIndexInTexture = 104;
        pamcoloredcobblestoneslabCyan.blockIndexInTexture = 105;
        pamcoloredcobblestoneslabPurple.blockIndexInTexture = 106;
        pamcoloredcobblestoneslabBlue.blockIndexInTexture = 107;
        pamcoloredcobblestoneslabBrown.blockIndexInTexture = 108;
        pamcoloredcobblestoneslabGreen.blockIndexInTexture = 109;
        pamcoloredcobblestoneslabRed.blockIndexInTexture = 110;
        pamcoloredcobblestoneslabBlack.blockIndexInTexture = 111;
        
        coloredclothTex[0] = 64;
        coloredclothTex[1] = 210;
        coloredclothTex[2] = 194;
        coloredclothTex[3] = 178;
        coloredclothTex[4] = 162;
        coloredclothTex[5] = 146;
        coloredclothTex[6] = 130;
        coloredclothTex[7] = 114;
        coloredclothTex[8] = 225;
        coloredclothTex[9] = 209;
        coloredclothTex[10] = 193;
        coloredclothTex[11] = 177;
        coloredclothTex[12] = 161;
        coloredclothTex[13] = 145;
        coloredclothTex[14] = 129;
        coloredclothTex[15] = 113;
     
        pamcoloredclothslabWhite.blockIndexInTexture = 64;
        pamcoloredclothslabOrange.blockIndexInTexture = 210;
        pamcoloredclothslabMagenta.blockIndexInTexture = 194;
        pamcoloredclothslabLightblue.blockIndexInTexture = 178;
        pamcoloredclothslabYellow.blockIndexInTexture = 162;
        pamcoloredclothslabLime.blockIndexInTexture = 146;
        pamcoloredclothslabPink.blockIndexInTexture = 130;
        pamcoloredclothslabDarkgrey.blockIndexInTexture = 114;
        pamcoloredclothslabLightgrey.blockIndexInTexture = 225;
        pamcoloredclothslabCyan.blockIndexInTexture = 209;
        pamcoloredclothslabPurple.blockIndexInTexture = 193;
        pamcoloredclothslabBlue.blockIndexInTexture = 177;
        pamcoloredclothslabBrown.blockIndexInTexture = 161;
        pamcoloredclothslabGreen.blockIndexInTexture = 145;
        pamcoloredclothslabRed.blockIndexInTexture = 129;
        pamcoloredclothslabBlack.blockIndexInTexture = 113;
        
		coloredbookshelfTex[0] = 16;
        coloredbookshelfTex[1] = 17;
        coloredbookshelfTex[2] = 18;
        coloredbookshelfTex[3] = 19;
        coloredbookshelfTex[4] = 20;
        coloredbookshelfTex[5] = 21;
        coloredbookshelfTex[6] = 22;
        coloredbookshelfTex[7] = 23;
        coloredbookshelfTex[8] = 24;
        coloredbookshelfTex[9] = 25;
        coloredbookshelfTex[10] = 26;
        coloredbookshelfTex[11] = 27;
        coloredbookshelfTex[12] = 28;
        coloredbookshelfTex[13] = 29;
        coloredbookshelfTex[14] = 30;
        coloredbookshelfTex[15] = 31;
        
		coloredleavesTex[0] = 32;
        coloredleavesTex[1] = 33;
        coloredleavesTex[2] = 34;
        coloredleavesTex[3] = 35;
        coloredleavesTex[4] = 36;
        coloredleavesTex[5] = 37;
        coloredleavesTex[6] = 38;
        coloredleavesTex[7] = 39;
        coloredleavesTex[8] = 40;
        coloredleavesTex[9] = 41;
        coloredleavesTex[10] = 42;
        coloredleavesTex[11] = 43;
        coloredleavesTex[12] = 44;
        coloredleavesTex[13] = 45;
        coloredleavesTex[14] = 46;
        coloredleavesTex[15] = 47;
        
		coloredwoodsideTex[0] = 64;
        coloredwoodsideTex[1] = 65;
        coloredwoodsideTex[2] = 66;
        coloredwoodsideTex[3] = 67;
        coloredwoodsideTex[4] = 68;
        coloredwoodsideTex[5] = 69;
        coloredwoodsideTex[6] = 70;
        coloredwoodsideTex[7] = 71;
        coloredwoodsideTex[8] = 72;
        coloredwoodsideTex[9] = 73;
        coloredwoodsideTex[10] = 74;
        coloredwoodsideTex[11] = 75;
        coloredwoodsideTex[12] = 76;
        coloredwoodsideTex[13] = 77;
        coloredwoodsideTex[14] = 78;
        coloredwoodsideTex[15] = 79;
        
		coloredwoodtopTex[0] = 80;
        coloredwoodtopTex[1] = 81;
        coloredwoodtopTex[2] = 82;
        coloredwoodtopTex[3] = 83;
        coloredwoodtopTex[4] = 84;
        coloredwoodtopTex[5] = 85;
        coloredwoodtopTex[6] = 86;
        coloredwoodtopTex[7] = 87;
        coloredwoodtopTex[8] = 88;
        coloredwoodtopTex[9] = 89;
        coloredwoodtopTex[10] = 90;
        coloredwoodtopTex[11] = 91;
        coloredwoodtopTex[12] = 92;
        coloredwoodtopTex[13] = 93;
        coloredwoodtopTex[14] = 94;
        coloredwoodtopTex[15] = 95;
    	
        coloredglassTex[0] = 128;
        coloredglassTex[1] = 129;
        coloredglassTex[2] = 130;
        coloredglassTex[3] = 131;
        coloredglassTex[4] = 132;
        coloredglassTex[5] = 133;
        coloredglassTex[6] = 134;
        coloredglassTex[7] = 135;
        coloredglassTex[8] = 136;
        coloredglassTex[9] = 137;
        coloredglassTex[10] = 138;
        coloredglassTex[11] = 139;
        coloredglassTex[12] = 140;
        coloredglassTex[13] = 141;
        coloredglassTex[14] = 142;
        coloredglassTex[15] = 143;
        
        metalblockTex[0] = 160;
        metalblockTex[1] = 161;
        metalblockTex[2] = 162;
        metalblockTex[3] = 163;
        metalblockTex[4] = 164;
        metalblockTex[5] = 165;
        metalblockTex[6] = 166;
        metalblockTex[7] = 167;
        metalblockTex[8] = 168;
        metalblockTex[9] = 169;
        metalblockTex[10] = 170;
        metalblockTex[11] = 171;
        metalblockTex[12] = 172;
        metalblockTex[13] = 173;
        metalblockTex[14] = 174;
        metalblockTex[15] = 175;
        
        gemblockTex[0] = 176;
        gemblockTex[1] = 177;
        gemblockTex[2] = 178;
        gemblockTex[3] = 179;
        gemblockTex[4] = 180;
        gemblockTex[5] = 181;
        gemblockTex[6] = 182;
        gemblockTex[7] = 183;
        gemblockTex[8] = 184;
        gemblockTex[9] = 185;
        gemblockTex[10] = 186;
        gemblockTex[11] = 187;
        gemblockTex[12] = 188;
        gemblockTex[13] = 189;
        gemblockTex[14] = 190;
        gemblockTex[15] = 191;
        
        coloredclayTex[0] = 192;
        coloredclayTex[1] = 193;
        coloredclayTex[2] = 194;
        coloredclayTex[3] = 195;
        coloredclayTex[4] = 196;
        coloredclayTex[5] = 197;
        coloredclayTex[6] = 198;
        coloredclayTex[7] = 199;
        coloredclayTex[8] = 200;
        coloredclayTex[9] = 201;
        coloredclayTex[10] = 202;
        coloredclayTex[11] = 203;
        coloredclayTex[12] = 204;
        coloredclayTex[13] = 205;
        coloredclayTex[14] = 206;
        coloredclayTex[15] = 207;
        
        coloredsandTex[0] = 208;
        coloredsandTex[1] = 209;
        coloredsandTex[2] = 210;
        coloredsandTex[3] = 211;
        coloredsandTex[4] = 212;
        coloredsandTex[5] = 213;
        coloredsandTex[6] = 214;
        coloredsandTex[7] = 215;
        coloredsandTex[8] = 216;
        coloredsandTex[9] = 217;
        coloredsandTex[10] = 218;
        coloredsandTex[11] = 219;
        coloredsandTex[12] = 220;
        coloredsandTex[13] = 221;
        coloredsandTex[14] = 222;
        coloredsandTex[15] = 223;
        
        stonepaverTex[0] = 224;
        stonepaverTex[1] = 225;
        stonepaverTex[2] = 226;
        stonepaverTex[3] = 227;
        stonepaverTex[4] = 228;
        stonepaverTex[5] = 229;
        stonepaverTex[6] = 230;
        stonepaverTex[7] = 231;
        stonepaverTex[8] = 232;
        stonepaverTex[9] = 233;
        stonepaverTex[10] = 234;
        stonepaverTex[11] = 235;
        stonepaverTex[12] = 236;
        stonepaverTex[13] = 237;
        stonepaverTex[14] = 238;
        stonepaverTex[15] = 239;
        
        windowTex[0] = 240;
        windowTex[1] = 241;
        windowTex[2] = 242;
        windowTex[3] = 243;
        windowTex[4] = 244;
        windowTex[5] = 245;
        windowTex[6] = 246;
        windowTex[7] = 247;
        windowTex[8] = 248;
        windowTex[9] = 249;
        windowTex[10] = 250;
        windowTex[11] = 251;
        windowTex[12] = 252;
        windowTex[13] = 253;
        windowTex[14] = 254;
        windowTex[15] = 255;
        
        cropboxoneTex[0] = 0;
        cropboxoneTex[1] = 1;
        cropboxoneTex[2] = 2;
        cropboxoneTex[3] = 3;
        cropboxoneTex[4] = 4;
        cropboxoneTex[5] = 5;
        cropboxoneTex[6] = 6;
        cropboxoneTex[7] = 7;
        cropboxoneTex[8] = 8;
        cropboxoneTex[9] = 9;
        cropboxoneTex[10] = 10;
        cropboxoneTex[11] = 11;
        cropboxoneTex[12] = 12;
        cropboxoneTex[13] = 13;
        cropboxoneTex[14] = 14;
        cropboxoneTex[15] = 15;
        
        
			
			load2();
			load3();
			load4();
        }


		public void load2()
        {
        	//Flower Block Names
            LanguageRegistry.instance().addStringLocalization("block.WhitepamFlower.name", "en_US", "White Roses");
            LanguageRegistry.instance().addStringLocalization("block.OrangepamFlower.name", "en_US", "Orange Wild Poppies");
            LanguageRegistry.instance().addStringLocalization("block.MagentapamFlower.name", "en_US", "Magenta Wildflowers");
            LanguageRegistry.instance().addStringLocalization("block.LightBluepamFlower.name", "en_US", "Blue Chrysanthemums");
            LanguageRegistry.instance().addStringLocalization("block.ShrubspamFlower.name", "en_US", "Shrubs");
            LanguageRegistry.instance().addStringLocalization("block.PinkpamFlower.name", "en_US", "Pink Dasies");
            LanguageRegistry.instance().addStringLocalization("block.GreypamFlower.name", "en_US", "Grey Peonies");
            LanguageRegistry.instance().addStringLocalization("block.WildpamFlower.name", "en_US", "Wild Parsley Blooms");
            LanguageRegistry.instance().addStringLocalization("block.CyanpamFlower.name", "en_US", "Cyan Wildflowers");
            LanguageRegistry.instance().addStringLocalization("block.PurplepamFlower.name", "en_US", "Purple Violets");
            LanguageRegistry.instance().addStringLocalization("block.BluepamFlower.name", "en_US", "Blue Hydrangeas");
            LanguageRegistry.instance().addStringLocalization("block.DyingpamFlower.name", "en_US", "Dying Shrubs");
            LanguageRegistry.instance().addStringLocalization("block.GreenpamFlower.name", "en_US", "Green Shrubs");
            LanguageRegistry.instance().addStringLocalization("block.BlackpamFlower.name", "en_US", "Black Roses");
            
            //Desert Plant Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamdesertPlant.name", "en_US", "Cactus Fruit Cactus");
            LanguageRegistry.instance().addStringLocalization("block.BACpamdesertPlant.name", "en_US", "Brown Armed Cactus");
            LanguageRegistry.instance().addStringLocalization("block.BCpamdesertPlant.name", "en_US", "Brown Cactus");
            LanguageRegistry.instance().addStringLocalization("block.GCpamdesertPlant.name", "en_US", "Green Cactus");
            LanguageRegistry.instance().addStringLocalization("block.OCpamdesertPlant.name", "en_US", "Olive Cactus");
            LanguageRegistry.instance().addStringLocalization("block.OACpamdesertPlant.name", "en_US", "Olive Armed Cactus");
            LanguageRegistry.instance().addStringLocalization("block.RSpamdesertPlant.name", "en_US", "Rusty Shrub");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamdesertPlant.name", "en_US", "Rusty Mini Shrub");
            LanguageRegistry.instance().addStringLocalization("block.RGpamdesertPlant.name", "en_US", "Rusty Grass");
            LanguageRegistry.instance().addStringLocalization("block.RWpamdesertPlant.name", "en_US", "Rusty Wheatgrass");
            LanguageRegistry.instance().addStringLocalization("block.DSpamdesertPlant.name", "en_US", "Dusty Shrub");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamdesertPlant.name", "en_US", "Dusty Mini Shrub");
            LanguageRegistry.instance().addStringLocalization("block.DGpamdesertPlant.name", "en_US", "Dusty Grass");
            LanguageRegistry.instance().addStringLocalization("block.DWpamdesertPlant.name", "en_US", "Dusty Wheatgrass");
            LanguageRegistry.instance().addStringLocalization("block.DFpamdesertPlant.name", "en_US", "Desert Flower");
            LanguageRegistry.instance().addStringLocalization("block.DSappamdesertPlant.name", "en_US", "Dead Sapling");
            
            //Temperate Plant Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamtemperatePlant.name", "en_US", "Dark Bush");
            LanguageRegistry.instance().addStringLocalization("block.BACpamtemperatePlant.name", "en_US", "Dark Grass");
            LanguageRegistry.instance().addStringLocalization("block.BCpamtemperatePlant.name", "en_US", "Dark Vine");
            LanguageRegistry.instance().addStringLocalization("block.GCpamtemperatePlant.name", "en_US", "Dark Thin Grass");
            LanguageRegistry.instance().addStringLocalization("block.OCpamtemperatePlant.name", "en_US", "Light Fern");
            LanguageRegistry.instance().addStringLocalization("block.OACpamtemperatePlant.name", "en_US", "Dark Mini Grass");
            LanguageRegistry.instance().addStringLocalization("block.RSpamtemperatePlant.name", "en_US", "Squat Bush");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamtemperatePlant.name", "en_US", "Tall Bush");
            LanguageRegistry.instance().addStringLocalization("block.RGpamtemperatePlant.name", "en_US", "Leafy Bush");
            LanguageRegistry.instance().addStringLocalization("block.RWpamtemperatePlant.name", "en_US", "Light Thin Grass");
            LanguageRegistry.instance().addStringLocalization("block.DSpamtemperatePlant.name", "en_US", "Light Grass");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamtemperatePlant.name", "en_US", "Light Mini Grass");
            LanguageRegistry.instance().addStringLocalization("block.DGpamtemperatePlant.name", "en_US", "Light Vine");
            LanguageRegistry.instance().addStringLocalization("block.DWpamtemperatePlant.name", "en_US", "Dark Fern");
            LanguageRegistry.instance().addStringLocalization("block.DFpamtemperatePlant.name", "en_US", "Colorful Bush");
            LanguageRegistry.instance().addStringLocalization("block.DSappamtemperatePlant.name", "en_US", "Mini Coloreful Bush");
            
            //Fruit Block Name
            LanguageRegistry.instance().addStringLocalization("block.CFCpamFruit.name", "en_US", "Cherry");
            LanguageRegistry.instance().addStringLocalization("block.BACpamFruit.name", "en_US", "Walnut");
            LanguageRegistry.instance().addStringLocalization("block.BCpamFruit.name", "en_US", "Pear");
            LanguageRegistry.instance().addStringLocalization("block.GCpamFruit.name", "en_US", "Plum");
            LanguageRegistry.instance().addStringLocalization("block.OCpamFruit.name", "en_US", "Avacado");
            LanguageRegistry.instance().addStringLocalization("block.OACpamFruit.name", "en_US", "Nutmeg");
            
            //Warm Fruit Block Name
            LanguageRegistry.instance().addStringLocalization("block.CFCpamwarmFruit.name", "en_US", "Banana");
            LanguageRegistry.instance().addStringLocalization("block.BACpamwarmFruit.name", "en_US", "Coconut");
            LanguageRegistry.instance().addStringLocalization("block.BCpamwarmFruit.name", "en_US", "Lemon");
            LanguageRegistry.instance().addStringLocalization("block.GCpamwarmFruit.name", "en_US", "Orange");
            LanguageRegistry.instance().addStringLocalization("block.OCpamwarmFruit.name", "en_US", "Peach");
            LanguageRegistry.instance().addStringLocalization("block.OACpamwarmFruit.name", "en_US", "Lime");
            LanguageRegistry.instance().addStringLocalization("block.RSpamwarmFruit.name", "en_US", "Mango");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamwarmFruit.name", "en_US", "Olive");
            LanguageRegistry.instance().addStringLocalization("block.RGpamwarmFruit.name", "en_US", "Pomegranate");
            LanguageRegistry.instance().addStringLocalization("block.RWpamwarmFruit.name", "en_US", "Peppercorn");
            LanguageRegistry.instance().addStringLocalization("block.DSpamwarmFruit.name", "en_US", "Papaya");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamwarmFruit.name", "en_US", "Starfruit");
            LanguageRegistry.instance().addStringLocalization("block.DGpamwarmFruit.name", "en_US", "Cinammon");
            
            //Bush Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamBush.name", "en_US", "Blueberry Bush");
            LanguageRegistry.instance().addStringLocalization("block.BACpamBush.name", "en_US", "Blackberry Bush");
            LanguageRegistry.instance().addStringLocalization("block.BCpamBush.name", "en_US", "Raspberry Bush");
            LanguageRegistry.instance().addStringLocalization("block.GCpamBush.name", "en_US", "Strawberry Bush");
            LanguageRegistry.instance().addStringLocalization("block.OCpamBush.name", "en_US", "Sunflower");
            LanguageRegistry.instance().addStringLocalization("block.OACpamBush.name", "en_US", "White Mushroom");
            LanguageRegistry.instance().addStringLocalization("block.RSpamBush.name", "en_US", "Cotton Bush");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamBush.name", "en_US", "Candleberry Bush");
            
            //Warm Bush Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamwarmBush.name", "en_US", "Blackberry Bush");
            LanguageRegistry.instance().addStringLocalization("block.BACpamwarmBush.name", "en_US", "Raspberry Bush");
            LanguageRegistry.instance().addStringLocalization("block.BCpamwarmBush.name", "en_US", "Kiwi Bush");
            LanguageRegistry.instance().addStringLocalization("block.GCpamwarmBush.name", "en_US", "Grape Bush");
            LanguageRegistry.instance().addStringLocalization("block.OCpamwarmBush.name", "en_US", "White Mushroom");
            LanguageRegistry.instance().addStringLocalization("block.OACpamwarmBush.name", "en_US", "Cotton Bush");
            LanguageRegistry.instance().addStringLocalization("block.RSpamwarmBush.name", "en_US", "Candleberry Bush");

            //Cold Bush Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoldBush.name", "en_US", "Blueberry Bush");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoldBush.name", "en_US", "Raspberry Bush");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoldBush.name", "en_US", "Cotton Bush");
            
            //Mineral Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamMineral.name", "en_US", "Salt");
            LanguageRegistry.instance().addStringLocalization("block.BACpamMineral.name", "en_US", "Fossil");
            LanguageRegistry.instance().addStringLocalization("block.BCpamMineral.name", "en_US", "Saltpeter");
            LanguageRegistry.instance().addStringLocalization("block.GCpamMineral.name", "en_US", "Sulphur");
            
            //Ore Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamOre.name", "en_US", "Zinc Ore");
            LanguageRegistry.instance().addStringLocalization("block.BACpamOre.name", "en_US", "Tin Ore");
            LanguageRegistry.instance().addStringLocalization("block.BCpamOre.name", "en_US", "Copper Ore");
            LanguageRegistry.instance().addStringLocalization("block.GCpamOre.name", "en_US", "Silver Ore");
            LanguageRegistry.instance().addStringLocalization("block.OCpamOre.name", "en_US", "Cobalt Ore");
            LanguageRegistry.instance().addStringLocalization("block.OACpamOre.name", "en_US", "Platinum Ore");
            LanguageRegistry.instance().addStringLocalization("block.RSpamOre.name", "en_US", "Titanium Ore");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamOre.name", "en_US", "Mithril Ore");

            
            //Colored Smoothstone Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredSmoothstone.name", "en_US", "White Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredSmoothstone.name", "en_US", "Orange Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredSmoothstone.name", "en_US", "Magenata Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredSmoothstone.name", "en_US", "Light Blue Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredSmoothstone.name", "en_US", "Yellow Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredSmoothstone.name", "en_US", "Lime Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredSmoothstone.name", "en_US", "Pink Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredSmoothstone.name", "en_US", "Dark Grey Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredSmoothstone.name", "en_US", "Light Grey Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredSmoothstone.name", "en_US", "Cyan Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredSmoothstone.name", "en_US", "Purple Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredSmoothstone.name", "en_US", "Blue Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredSmoothstone.name", "en_US", "Brown Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredSmoothstone.name", "en_US", "Green Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredSmoothstone.name", "en_US", "Red Smoothstone");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredSmoothstone.name", "en_US", "Black Smoothstone");
            
            //Gem Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamGem.name", "en_US", "Flawed Quartz");
            LanguageRegistry.instance().addStringLocalization("block.BACpamGem.name", "en_US", "Flawed Citrine");
            LanguageRegistry.instance().addStringLocalization("block.BCpamGem.name", "en_US", "Flawed Tanzanite");
            LanguageRegistry.instance().addStringLocalization("block.GCpamGem.name", "en_US", "Flawed Sapphire");
            LanguageRegistry.instance().addStringLocalization("block.OCpamGem.name", "en_US", "Flawed Topaz");
            LanguageRegistry.instance().addStringLocalization("block.OACpamGem.name", "en_US", "Flawed Agate");
            LanguageRegistry.instance().addStringLocalization("block.RSpamGem.name", "en_US", "Flawed Garnet");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamGem.name", "en_US", "Flawed Hematite");
            LanguageRegistry.instance().addStringLocalization("block.RGpamGem.name", "en_US", "Flawed Moonstone");
            LanguageRegistry.instance().addStringLocalization("block.RWpamGem.name", "en_US", "Flawed Aquamarine");
            LanguageRegistry.instance().addStringLocalization("block.DSpamGem.name", "en_US", "Flawed Amethyst");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamGem.name", "en_US", "Flawed Tigerseye");
            LanguageRegistry.instance().addStringLocalization("block.DGpamGem.name", "en_US", "Flawed Emerald");
            LanguageRegistry.instance().addStringLocalization("block.DWpamGem.name", "en_US", "Flawed Ruby");
            LanguageRegistry.instance().addStringLocalization("block.DFpamGem.name", "en_US", "Flawed Onyx");

            //Sapling Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamSapling.name", "en_US", "Cherry Sapling");
            LanguageRegistry.instance().addStringLocalization("block.BACpamSapling.name", "en_US", "Walnut Sapling");
            LanguageRegistry.instance().addStringLocalization("block.BCpamSapling.name", "en_US", "Pear Sapling");
            LanguageRegistry.instance().addStringLocalization("block.GCpamSapling.name", "en_US", "Plum Blue Sapling");
            LanguageRegistry.instance().addStringLocalization("block.OCpamSapling.name", "en_US", "Avacado Sapling");
            LanguageRegistry.instance().addStringLocalization("block.OACpamSapling.name", "en_US", "Nutmeg Sapling");
            
            //Warm Sapling Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamwarmSapling.name", "en_US", "Banana Sapling");
            LanguageRegistry.instance().addStringLocalization("block.BACpamwarmSapling.name", "en_US", "Coconut Sapling");
            LanguageRegistry.instance().addStringLocalization("block.BCpamwarmSapling.name", "en_US", "Lemon Sapling");
            LanguageRegistry.instance().addStringLocalization("block.GCpamwarmSapling.name", "en_US", "Orange Sapling");
            LanguageRegistry.instance().addStringLocalization("block.OCpamwarmSapling.name", "en_US", "Peach Sapling");
            LanguageRegistry.instance().addStringLocalization("block.OACpamwarmSapling.name", "en_US", "Lime Sapling");
            LanguageRegistry.instance().addStringLocalization("block.RSpamwarmSapling.name", "en_US", "Mango Sapling");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamwarmSapling.name", "en_US", "Olive Sapling");
            LanguageRegistry.instance().addStringLocalization("block.RGpamwarmSapling.name", "en_US", "Pomegranate Sapling");
            LanguageRegistry.instance().addStringLocalization("block.RWpamwarmSapling.name", "en_US", "Vanilla Bean Sapling");
            LanguageRegistry.instance().addStringLocalization("block.DSpamwarmSapling.name", "en_US", "Peppercorn Sapling");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamwarmSapling.name", "en_US", "Papaya Sapling");
            LanguageRegistry.instance().addStringLocalization("block.DGpamwarmSapling.name", "en_US", "Starfruit Sapling");
            LanguageRegistry.instance().addStringLocalization("block.DWpamwarmSapling.name", "en_US", "Cinnamon Sapling");
            
            //Colored Plank Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredPlank.name", "en_US", "White Plank");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredPlank.name", "en_US", "Orange Plank");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredPlank.name", "en_US", "Magenata Plank");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredPlank.name", "en_US", "Light Blue Plank");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredPlank.name", "en_US", "Yellow Plank");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredPlank.name", "en_US", "Lime Plank");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredPlank.name", "en_US", "Pink Plank");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredPlank.name", "en_US", "Dark Grey Plank");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredPlank.name", "en_US", "Light Grey Plank");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredPlank.name", "en_US", "Cyan Plank");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredPlank.name", "en_US", "Purple Plank");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredPlank.name", "en_US", "Blue Plank");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredPlank.name", "en_US", "Brown Plank");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredPlank.name", "en_US", "Green Plank");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredPlank.name", "en_US", "Red Plank");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredPlank.name", "en_US", "Black Plank");
            
            //Colored Wood Fence Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredwoodFence.name", "en_US", "White Fence");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredwoodFence.name", "en_US", "Orange Fence");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredwoodFence.name", "en_US", "Magenata Fence");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredwoodFence.name", "en_US", "Light Blue Fence");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredwoodFence.name", "en_US", "Yellow Fence");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredwoodFence.name", "en_US", "Lime Fence");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredwoodFence.name", "en_US", "Pink Fence");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredwoodFence.name", "en_US", "Dark Grey Fence");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredwoodFence.name", "en_US", "Light Grey Fence");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredwoodFence.name", "en_US", "Cyan Fence");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredwoodFence.name", "en_US", "Purple Fence");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredwoodFence.name", "en_US", "Blue Fence");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredwoodFence.name", "en_US", "Brown Fence");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredwoodFence.name", "en_US", "Green Fence");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredwoodFence.name", "en_US", "Red Fence");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredwoodFence.name", "en_US", "Black Fence");
            
            //Colored Wood Thin Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredwoodThin.name", "en_US", "White Tile");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredwoodThin.name", "en_US", "Orange Tile");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredwoodThin.name", "en_US", "Magenata Tile");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredwoodThin.name", "en_US", "Light Blue Tile");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredwoodThin.name", "en_US", "Yellow Tile");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredwoodThin.name", "en_US", "Lime Tile");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredwoodThin.name", "en_US", "Pink Tile");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredwoodThin.name", "en_US", "Dark Grey Tile");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredwoodThin.name", "en_US", "Light Grey Tile");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredwoodThin.name", "en_US", "Cyan Tile");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredwoodThin.name", "en_US", "Purple Tile");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredwoodThin.name", "en_US", "Blue Tile");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredwoodThin.name", "en_US", "Brown Tile");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredwoodThin.name", "en_US", "Green Tile");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredwoodThin.name", "en_US", "Red Tile");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredwoodThin.name", "en_US", "Black Tile");
            
            //Colored Cobblestone Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredCobblestone.name", "en_US", "White Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredCobblestone.name", "en_US", "Orange Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredCobblestone.name", "en_US", "Magenata Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredCobblestone.name", "en_US", "Light Blue Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredCobblestone.name", "en_US", "Yellow Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredCobblestone.name", "en_US", "Lime Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredCobblestone.name", "en_US", "Pink Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredCobblestone.name", "en_US", "Dark Grey Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredCobblestone.name", "en_US", "Light Grey Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredCobblestone.name", "en_US", "Cyan Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredCobblestone.name", "en_US", "Purple Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredCobblestone.name", "en_US", "Blue Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredCobblestone.name", "en_US", "Brown Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredCobblestone.name", "en_US", "Green Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredCobblestone.name", "en_US", "Red Cobblestone");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredCobblestone.name", "en_US", "Black Cobblestone");
            
          //Colored Cobblestone Thin Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredcobblestoneThin.name", "en_US", "White Tile");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredcobblestoneThin.name", "en_US", "Orange Tile");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredcobblestoneThin.name", "en_US", "Magenata Tile");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredcobblestoneThin.name", "en_US", "Light Blue Tile");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredcobblestoneThin.name", "en_US", "Yellow Tile");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredcobblestoneThin.name", "en_US", "Lime Tile");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredcobblestoneThin.name", "en_US", "Pink Tile");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredcobblestoneThin.name", "en_US", "Dark Grey Tile");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredcobblestoneThin.name", "en_US", "Light Grey Tile");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredcobblestoneThin.name", "en_US", "Cyan Tile");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredcobblestoneThin.name", "en_US", "Purple Tile");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredcobblestoneThin.name", "en_US", "Blue Tile");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredcobblestoneThin.name", "en_US", "Brown Tile");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredcobblestoneThin.name", "en_US", "Green Tile");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredcobblestoneThin.name", "en_US", "Red Tile");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredcobblestoneThin.name", "en_US", "Black Tile");
            
          //Colored Cloth Thin Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredclothThin.name", "en_US", "White Carpet");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredclothThin.name", "en_US", "Orange Carpet");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredclothThin.name", "en_US", "Magenata Carpet");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredclothThin.name", "en_US", "Light Blue Carpet");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredclothThin.name", "en_US", "Yellow Carpet");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredclothThin.name", "en_US", "Lime Carpet");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredclothThin.name", "en_US", "Pink Carpet");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredclothThin.name", "en_US", "Dark Grey Carpet");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredclothThin.name", "en_US", "Light Grey Carpet");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredclothThin.name", "en_US", "Cyan Carpet");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredclothThin.name", "en_US", "Purple Carpet");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredclothThin.name", "en_US", "Blue Carpet");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredclothThin.name", "en_US", "Brown Carpet");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredclothThin.name", "en_US", "Green Carpet");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredclothThin.name", "en_US", "Red Carpet");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredclothThin.name", "en_US", "Black Carpet");
            
            //Metal Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpammetalBlock.name", "en_US", "Zinc Block");
            LanguageRegistry.instance().addStringLocalization("block.BACpammetalBlock.name", "en_US", "Tin Block");
            LanguageRegistry.instance().addStringLocalization("block.BCpammetalBlock.name", "en_US", "Copper Block");
            LanguageRegistry.instance().addStringLocalization("block.GCpammetalBlock.name", "en_US", "Silver Block");
            LanguageRegistry.instance().addStringLocalization("block.OCpammetalBlock.name", "en_US", "Cobalt Block");
            LanguageRegistry.instance().addStringLocalization("block.OACpammetalBlock.name", "en_US", "Platnium Block");
            LanguageRegistry.instance().addStringLocalization("block.RSpammetalBlock.name", "en_US", "Titanium Block");
            LanguageRegistry.instance().addStringLocalization("block.RMSpammetalBlock.name", "en_US", "Mithril Block");
            LanguageRegistry.instance().addStringLocalization("block.RGpammetalBlock.name", "en_US", "Bronze Block");
            LanguageRegistry.instance().addStringLocalization("block.RWpammetalBlock.name", "en_US", "Steel Block");
            LanguageRegistry.instance().addStringLocalization("block.DSpammetalBlock.name", "en_US", "Redstone Block");
            LanguageRegistry.instance().addStringLocalization("block.DMSpammetalBlock.name", "en_US", "Coal Block");

            
            //Gem Block Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamgemBlock.name", "en_US", "Flawed Quartz Block");
            LanguageRegistry.instance().addStringLocalization("block.BACpamgemBlock.name", "en_US", "Flawed Citrine Block");
            LanguageRegistry.instance().addStringLocalization("block.BCpamgemBlock.name", "en_US", "Flawed Tanzanite Block");
            LanguageRegistry.instance().addStringLocalization("block.GCpamgemBlock.name", "en_US", "Flawed Sapphire Block");
            LanguageRegistry.instance().addStringLocalization("block.OCpamgemBlock.name", "en_US", "Flawed Topaz Block");
            LanguageRegistry.instance().addStringLocalization("block.OACpamgemBlock.name", "en_US", "Flawed Agate Block");
            LanguageRegistry.instance().addStringLocalization("block.RSpamgemBlock.name", "en_US", "Flawed Garnet Block");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamgemBlock.name", "en_US", "Flawed Hematite Block");
            LanguageRegistry.instance().addStringLocalization("block.RGpamgemBlock.name", "en_US", "Flawed Moonstone Block");
            LanguageRegistry.instance().addStringLocalization("block.RWpamgemBlock.name", "en_US", "Flawed Aquamarine Block");
            LanguageRegistry.instance().addStringLocalization("block.DSpamgemBlock.name", "en_US", "Flawed Amethyst Block");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamgemBlock.name", "en_US", "Flawed Lapis Lazuli Block");
            LanguageRegistry.instance().addStringLocalization("block.DGpamgemBlock.name", "en_US", "Flawed Tigerseye Block");
            LanguageRegistry.instance().addStringLocalization("block.DWpamgemBlock.name", "en_US", "Flawed Emerald Block");
            LanguageRegistry.instance().addStringLocalization("block.DFpamgemBlock.name", "en_US", "Flawed Ruby Block");
            LanguageRegistry.instance().addStringLocalization("block.DSappamgemBlock.name", "en_US", "Flawed Onyx Block");
            
            //Colored Clay Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredClay.name", "en_US", "White Clay");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredClay.name", "en_US", "Orange Clay");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredClay.name", "en_US", "Magenata Clay");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredClay.name", "en_US", "Light Blue Clay");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredClay.name", "en_US", "Yellow Clay");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredClay.name", "en_US", "Lime Clay");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredClay.name", "en_US", "Pink Clay");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredClay.name", "en_US", "Dark Grey Clay");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredClay.name", "en_US", "Light Grey Clay");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredClay.name", "en_US", "Cyan Clay");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredClay.name", "en_US", "Purple Clay");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredClay.name", "en_US", "Blue Clay");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredClay.name", "en_US", "Brown Clay");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredClay.name", "en_US", "Green Clay");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredClay.name", "en_US", "Red Clay");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredClay.name", "en_US", "Black Clay");
            
          //Colored Sand Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredSand.name", "en_US", "White Sand");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredSand.name", "en_US", "Orange Sand");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredSand.name", "en_US", "Magenata Sand");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredSand.name", "en_US", "Light Blue Sand");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredSand.name", "en_US", "Yellow Sand");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredSand.name", "en_US", "Lime Sand");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredSand.name", "en_US", "Pink Sand");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredSand.name", "en_US", "Dark Grey Sand");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredSand.name", "en_US", "Light Grey Sand");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredSand.name", "en_US", "Cyan Sand");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredSand.name", "en_US", "Purple Sand");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredSand.name", "en_US", "Blue Sand");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredSand.name", "en_US", "Brown Sand");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredSand.name", "en_US", "Green Sand");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredSand.name", "en_US", "Red Sand");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredSand.name", "en_US", "Black Sand");
            
          //Colored Bookshelf Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredBookshelf.name", "en_US", "White Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredBookshelf.name", "en_US", "Orange Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredBookshelf.name", "en_US", "Magenata Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredBookshelf.name", "en_US", "Light Blue Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredBookshelf.name", "en_US", "Yellow Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredBookshelf.name", "en_US", "Lime Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredBookshelf.name", "en_US", "Pink Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredBookshelf.name", "en_US", "Dark Grey Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredBookshelf.name", "en_US", "Light Grey Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredBookshelf.name", "en_US", "Cyan Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredBookshelf.name", "en_US", "Purple Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredBookshelf.name", "en_US", "Blue Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredBookshelf.name", "en_US", "Brown Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredBookshelf.name", "en_US", "Green Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredBookshelf.name", "en_US", "Red Bookshelf");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredBookshelf.name", "en_US", "Black Bookshelf");
            
          //Colored Leaves Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredLeaves.name", "en_US", "White Leaves");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredLeaves.name", "en_US", "Orange Leaves");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredLeaves.name", "en_US", "Magenata Leaves");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredLeaves.name", "en_US", "Light Blue Leaves");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredLeaves.name", "en_US", "Yellow Leaves");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredLeaves.name", "en_US", "Lime Leaves");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredLeaves.name", "en_US", "Pink Leaves");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredLeaves.name", "en_US", "Dark Grey Leaves");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredLeaves.name", "en_US", "Light Grey Leaves");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredLeaves.name", "en_US", "Cyan Leaves");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredLeaves.name", "en_US", "Purple Leaves");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredLeaves.name", "en_US", "Blue Leaves");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredLeaves.name", "en_US", "Brown Leaves");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredLeaves.name", "en_US", "Green Leaves");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredLeaves.name", "en_US", "Red Leaves");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredLeaves.name", "en_US", "Black Leaves");
            
          //Colored Wood Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredWood.name", "en_US", "White Wood");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredWood.name", "en_US", "Orange Wood");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredWood.name", "en_US", "Magenata Wood");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredWood.name", "en_US", "Light Blue Wood");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredWood.name", "en_US", "Yellow Wood");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredWood.name", "en_US", "Lime Wood");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredWood.name", "en_US", "Pink Wood");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredWood.name", "en_US", "Dark Grey Wood");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredWood.name", "en_US", "Light Grey Wood");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredWood.name", "en_US", "Cyan Wood");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredWood.name", "en_US", "Purple Wood");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredWood.name", "en_US", "Blue Wood");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredWood.name", "en_US", "Brown Wood");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredWood.name", "en_US", "Green Wood");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredWood.name", "en_US", "Red Wood");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredWood.name", "en_US", "Black Wood");
            
          //Stone Paver Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamstonePaver.name", "en_US", "First Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.BACpamstonePaver.name", "en_US", "Second Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.BCpamstonePaver.name", "en_US", "Third Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.GCpamstonePaver.name", "en_US", "Fourth Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.OCpamstonePaver.name", "en_US", "Fifth Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.OACpamstonePaver.name", "en_US", "Sixth Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.RSpamstonePaver.name", "en_US", "Seventh Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamstonePaver.name", "en_US", "Eighth Grey Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.RGpamstonePaver.name", "en_US", "Ninth Grey Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.RWpamstonePaver.name", "en_US", "Tenth Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.DSpamstonePaver.name", "en_US", "Elventh Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamstonePaver.name", "en_US", "Twelveth Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.DGpamstonePaver.name", "en_US", "Thirteenth Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.DWpamstonePaver.name", "en_US", "Fourteenth Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.DFpamstonePaver.name", "en_US", "Fifteenth Stone Paver");
            LanguageRegistry.instance().addStringLocalization("block.DSappamstonePaver.name", "en_US", "Sixteenth Stone Paver");
            
          //Window Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamWindow.name", "en_US", "First Window");
            LanguageRegistry.instance().addStringLocalization("block.BACpamWindow.name", "en_US", "Second Window");
            LanguageRegistry.instance().addStringLocalization("block.BCpamWindow.name", "en_US", "Third Window");
            LanguageRegistry.instance().addStringLocalization("block.GCpamWindow.name", "en_US", "Fourth Window");
            LanguageRegistry.instance().addStringLocalization("block.OCpamWindow.name", "en_US", "Fifth Window");
            LanguageRegistry.instance().addStringLocalization("block.OACpamWindow.name", "en_US", "Sixth Window");
            LanguageRegistry.instance().addStringLocalization("block.RSpamWindow.name", "en_US", "Seventh Window");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamWindow.name", "en_US", "Eighth Grey Window");
            LanguageRegistry.instance().addStringLocalization("block.RGpamWindow.name", "en_US", "Ninth Grey Window");
            LanguageRegistry.instance().addStringLocalization("block.RWpamWindow.name", "en_US", "Tenth Window");
            LanguageRegistry.instance().addStringLocalization("block.DSpamWindow.name", "en_US", "Elventh Window");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamWindow.name", "en_US", "Twelveth Window");
            LanguageRegistry.instance().addStringLocalization("block.DGpamWindow.name", "en_US", "Thirteenth Window");
            LanguageRegistry.instance().addStringLocalization("block.DWpamWindow.name", "en_US", "Fourteenth Window");
            LanguageRegistry.instance().addStringLocalization("block.DFpamWindow.name", "en_US", "Fifteenth Window");
            LanguageRegistry.instance().addStringLocalization("block.DSappamWindow.name", "en_US", "Sixteenth Window");
            
          //Colored Glass Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcoloredGlass.name", "en_US", "White Glass");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcoloredGlass.name", "en_US", "Orange Glass");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcoloredGlass.name", "en_US", "Magenata Glass");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcoloredGlass.name", "en_US", "Light Blue Glass");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcoloredGlass.name", "en_US", "Yellow Glass");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcoloredGlass.name", "en_US", "Lime Glass");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcoloredGlass.name", "en_US", "Pink Glass");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcoloredGlass.name", "en_US", "Dark Grey Glass");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcoloredGlass.name", "en_US", "Light Grey Glass");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcoloredGlass.name", "en_US", "Cyan Glass");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcoloredGlass.name", "en_US", "Purple Glass");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcoloredGlass.name", "en_US", "Blue Glass");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcoloredGlass.name", "en_US", "Brown Glass");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcoloredGlass.name", "en_US", "Green Glass");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcoloredGlass.name", "en_US", "Red Glass");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcoloredGlass.name", "en_US", "Black Glass");
            
            LanguageRegistry.instance().addStringLocalization("block.pamChurn.name", "en_US", "Churn"); // ADDED
            LanguageRegistry.instance().addStringLocalization("block.pamQuern.name", "en_US", "Quern"); // ADDED
            
          //Crop Boxes Names
            LanguageRegistry.instance().addStringLocalization("block.CFCpamcropboxOne.name", "en_US", "Wheat Bale");
            LanguageRegistry.instance().addStringLocalization("block.BACpamcropboxOne.name", "en_US", "Orange ");
            LanguageRegistry.instance().addStringLocalization("block.BCpamcropboxOne.name", "en_US", "Magenata ");
            LanguageRegistry.instance().addStringLocalization("block.GCpamcropboxOne.name", "en_US", "Light Blue ");
            LanguageRegistry.instance().addStringLocalization("block.OCpamcropboxOne.name", "en_US", "Yellow ");
            LanguageRegistry.instance().addStringLocalization("block.OACpamcropboxOne.name", "en_US", "Lime ");
            LanguageRegistry.instance().addStringLocalization("block.RSpamcropboxOne.name", "en_US", "Pink ");
            LanguageRegistry.instance().addStringLocalization("block.RMSpamcropboxOne.name", "en_US", "Dark Grey ");
            LanguageRegistry.instance().addStringLocalization("block.RGpamcropboxOne.name", "en_US", "Light Grey ");
            LanguageRegistry.instance().addStringLocalization("block.RWpamcropboxOne.name", "en_US", "Cyan ");
            LanguageRegistry.instance().addStringLocalization("block.DSpamcropboxOne.name", "en_US", "Purple ");
            LanguageRegistry.instance().addStringLocalization("block.DMSpamcropboxOne.name", "en_US", "Blue ");
            LanguageRegistry.instance().addStringLocalization("block.DGpamcropboxOne.name", "en_US", "Brown ");
            LanguageRegistry.instance().addStringLocalization("block.DWpamcropboxOne.name", "en_US", "Green ");
            LanguageRegistry.instance().addStringLocalization("block.DFpamcropboxOne.name", "en_US", "Red ");
            LanguageRegistry.instance().addStringLocalization("block.DSappamcropboxOne.name", "en_US", "Black ");
            
            ModLoader.addName(pamcoloredwoodstairsWhite, "White Stairs");
            ModLoader.addName(pamcoloredwoodstairsOrange, "Orange Stairs");
            ModLoader.addName(pamcoloredwoodstairsMagenta, "Magenta Stairs");
            ModLoader.addName(pamcoloredwoodstairsLightblue, "Orange Stairs");
            ModLoader.addName(pamcoloredwoodstairsYellow, "Yellow Stairs");
            ModLoader.addName(pamcoloredwoodstairsLime, "Lime Stairs");
            ModLoader.addName(pamcoloredwoodstairsPink, "Pink Stairs");
            ModLoader.addName(pamcoloredwoodstairsDarkgrey, "Dark Grey Stairs");
            ModLoader.addName(pamcoloredwoodstairsLightgrey, "Light Grey Stairs");
            ModLoader.addName(pamcoloredwoodstairsCyan, "Cyan Stairs");
            ModLoader.addName(pamcoloredwoodstairsPurple, "Purple Stairs");
            ModLoader.addName(pamcoloredwoodstairsBlue, "Blue Stairs");
            ModLoader.addName(pamcoloredwoodstairsBrown, "Brown Stairs");
            ModLoader.addName(pamcoloredwoodstairsGreen, "Green Stairs");
            ModLoader.addName(pamcoloredwoodstairsRed, "Red Stairs");
            ModLoader.addName(pamcoloredwoodstairsBlack, "Black Stairs");
            
            ModLoader.addName(pamcoloredwoodslabWhite, "White Slab");
            ModLoader.addName(pamcoloredwoodslabOrange, "Orange Slab");
            ModLoader.addName(pamcoloredwoodslabMagenta, "Magenta Slab");
            ModLoader.addName(pamcoloredwoodslabLightblue, "Orange Slab");
            ModLoader.addName(pamcoloredwoodslabYellow, "Yellow Slab");
            ModLoader.addName(pamcoloredwoodslabLime, "Lime Slab");
            ModLoader.addName(pamcoloredwoodslabPink, "Pink Slab");
            ModLoader.addName(pamcoloredwoodslabDarkgrey, "Dark Grey Slab");
            ModLoader.addName(pamcoloredwoodslabLightgrey, "Light Grey Slab");
            ModLoader.addName(pamcoloredwoodslabCyan, "Cyan Slab");
            ModLoader.addName(pamcoloredwoodslabPurple, "Purple Slab");
            ModLoader.addName(pamcoloredwoodslabBlue, "Blue Slab");
            ModLoader.addName(pamcoloredwoodslabBrown, "Brown Slab");
            ModLoader.addName(pamcoloredwoodslabGreen, "Green Slab");
            ModLoader.addName(pamcoloredwoodslabRed, "Red Slab");
            ModLoader.addName(pamcoloredwoodslabBlack, "Black Slab");

            ModLoader.addName(pamcoloredwoodfencegateWhite, "White Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateOrange, "Orange Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateMagenta, "Magenta Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateLightblue, "Orange Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateYellow, "Yellow Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateLime, "Lime Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegatePink, "Pink Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateDarkgrey, "Dark Grey Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateLightgrey, "Light Grey Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateCyan, "Cyan Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegatePurple, "Purple Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateBlue, "Blue Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateBrown, "Brown Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateGreen, "Green Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateRed, "Red Fence Gate");
            ModLoader.addName(pamcoloredwoodfencegateBlack, "Black Fence Gate");
            
            ModLoader.addName(pamcoloredcobblestonestairsWhite, "White Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsOrange, "Orange Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsMagenta, "Magenta Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsLightblue, "Orange Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsYellow, "Yellow Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsLime, "Lime Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsPink, "Pink Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsDarkgrey, "Dark Grey Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsLightgrey, "Light Grey Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsCyan, "Cyan Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsPurple, "Purple Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsBlue, "Blue Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsBrown, "Brown Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsGreen, "Green Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsRed, "Red Stairs");
            ModLoader.addName(pamcoloredcobblestonestairsBlack, "Black Stairs");
            
            ModLoader.addName(pamcoloredcobblestoneslabWhite, "White Slab");
            ModLoader.addName(pamcoloredcobblestoneslabOrange, "Orange Slab");
            ModLoader.addName(pamcoloredcobblestoneslabMagenta, "Magenta Slab");
            ModLoader.addName(pamcoloredcobblestoneslabLightblue, "Orange Slab");
            ModLoader.addName(pamcoloredcobblestoneslabYellow, "Yellow Slab");
            ModLoader.addName(pamcoloredcobblestoneslabLime, "Lime Slab");
            ModLoader.addName(pamcoloredcobblestoneslabPink, "Pink Slab");
            ModLoader.addName(pamcoloredcobblestoneslabDarkgrey, "Dark Grey Slab");
            ModLoader.addName(pamcoloredcobblestoneslabLightgrey, "Light Grey Slab");
            ModLoader.addName(pamcoloredcobblestoneslabCyan, "Cyan Slab");
            ModLoader.addName(pamcoloredcobblestoneslabPurple, "Purple Slab");
            ModLoader.addName(pamcoloredcobblestoneslabBlue, "Blue Slab");
            ModLoader.addName(pamcoloredcobblestoneslabBrown, "Brown Slab");
            ModLoader.addName(pamcoloredcobblestoneslabGreen, "Green Slab");
            ModLoader.addName(pamcoloredcobblestoneslabRed, "Red Slab");
            ModLoader.addName(pamcoloredcobblestoneslabBlack, "Black Slab");
            
            ModLoader.addName(pamcoloredclothstairsWhite, "White Stairs");
            ModLoader.addName(pamcoloredclothstairsOrange, "Orange Stairs");
            ModLoader.addName(pamcoloredclothstairsMagenta, "Magenta Stairs");
            ModLoader.addName(pamcoloredclothstairsLightblue, "Orange Stairs");
            ModLoader.addName(pamcoloredclothstairsYellow, "Yellow Stairs");
            ModLoader.addName(pamcoloredclothstairsLime, "Lime Stairs");
            ModLoader.addName(pamcoloredclothstairsPink, "Pink Stairs");
            ModLoader.addName(pamcoloredclothstairsDarkgrey, "Dark Grey Stairs");
            ModLoader.addName(pamcoloredclothstairsLightgrey, "Light Grey Stairs");
            ModLoader.addName(pamcoloredclothstairsCyan, "Cyan Stairs");
            ModLoader.addName(pamcoloredclothstairsPurple, "Purple Stairs");
            ModLoader.addName(pamcoloredclothstairsBlue, "Blue Stairs");
            ModLoader.addName(pamcoloredclothstairsBrown, "Brown Stairs");
            ModLoader.addName(pamcoloredclothstairsGreen, "Green Stairs");
            ModLoader.addName(pamcoloredclothstairsRed, "Red Stairs");
            ModLoader.addName(pamcoloredclothstairsBlack, "Black Stairs");
            
            ModLoader.addName(pamcoloredclothslabWhite, "White Slab");
            ModLoader.addName(pamcoloredclothslabOrange, "Orange Slab");
            ModLoader.addName(pamcoloredclothslabMagenta, "Magenta Slab");
            ModLoader.addName(pamcoloredclothslabLightblue, "Orange Slab");
            ModLoader.addName(pamcoloredclothslabYellow, "Yellow Slab");
            ModLoader.addName(pamcoloredclothslabLime, "Lime Slab");
            ModLoader.addName(pamcoloredclothslabPink, "Pink Slab");
            ModLoader.addName(pamcoloredclothslabDarkgrey, "Dark Grey Slab");
            ModLoader.addName(pamcoloredclothslabLightgrey, "Light Grey Slab");
            ModLoader.addName(pamcoloredclothslabCyan, "Cyan Slab");
            ModLoader.addName(pamcoloredclothslabPurple, "Purple Slab");
            ModLoader.addName(pamcoloredclothslabBlue, "Blue Slab");
            ModLoader.addName(pamcoloredclothslabBrown, "Brown Slab");
            ModLoader.addName(pamcoloredclothslabGreen, "Green Slab");
            ModLoader.addName(pamcoloredclothslabRed, "Red Slab");
            ModLoader.addName(pamcoloredclothslabBlack, "Black Slab");
            
            
            ModLoader.addName(whiteflowerseedItem, "White Flower Seed");
            ModLoader.addName(orangeflowerseedItem, "Orange Flower Seed");
            ModLoader.addName(magentaflowerseedItem, "Magenta Flower Seed");
            ModLoader.addName(lightblueflowerseedItem, "Light Blue Flower Seed");
            ModLoader.addName(yellowflowerseedItem, "Yellow Flower Seed");
            ModLoader.addName(limeflowerseedItem, "Lime Flower Seed");
            ModLoader.addName(pinkflowerseedItem, "Pink Flower Seed");
            ModLoader.addName(darkgreyflowerseedItem, "Dark Grey Flower Seed");
            ModLoader.addName(lightgreyflowerseedItem, "Light Grey Flower Seed");
            ModLoader.addName(cyanflowerseedItem, "Cyan Flower Seed");
            ModLoader.addName(purpleflowerseedItem, "Purple Flower Seed");
            ModLoader.addName(blueflowerseedItem, "Blue Flower Seed");
            ModLoader.addName(brownflowerseedItem, "Brown Flower Seed");
            ModLoader.addName(greenflowerseedItem, "Green Flower Seed");
            ModLoader.addName(redflowerseedItem, "Red Flower Seed");
            ModLoader.addName(blackflowerseedItem, "Black Flower Seed");
            
            ModLoader.addName(cactusPick, "Cactus Pickaxe");
            ModLoader.addName(cactusShovel, "Cactus Shovel");
            ModLoader.addName(cactusAxe, "Cactus Axe");
            ModLoader.addName(cactusHoe, "Cactus Hoe");
            ModLoader.addName(cactusSword, "Cactus Sword");
            ModLoader.addName(sandstonePick, "Sandstone Pickaxe");
            ModLoader.addName(sandstoneShovel, "Sandstone Shovel");
            ModLoader.addName(sandstoneAxe, "Sandstone Axe");
            ModLoader.addName(sandstoneHoe, "Sandstone Hoe");
            ModLoader.addName(sandstoneSword, "Sandstone Sword");
            ModLoader.addName(glasssteelPick, "Glass Steel Pickaxe");
            ModLoader.addName(glasssteelShovel, "Glass Steel Shovel");
            ModLoader.addName(glasssteelAxe, "Glass Steel Axe");
            ModLoader.addName(glasssteelHoe, "Glass Steel Hoe");
            ModLoader.addName(glasssteelSword, "Glass Steel Sword");
            ModLoader.addName(cactusstickItem, "Cactus Stick");
            ModLoader.addName(glasssteelItem, "Glass Steel");
            ModLoader.addName(cactusfruitItem, "Cactus Fruit");
            ModLoader.addName(cactusfruitseedItem, "Cactus Fruit Seed");
            
            ModLoader.addName(bonePick, "Bone Pickaxe");
            ModLoader.addName(boneShovel, "Bone Shovel");
            ModLoader.addName(boneAxe, "Bone Axe");
            ModLoader.addName(boneHoe, "Bone Hoe");
            ModLoader.addName(boneSword, "Bone Sword");
            ModLoader.addName(boneHelm, "Bone Helm");
            ModLoader.addName(boneChest, "Bone Chestpiece");
            ModLoader.addName(boneLegs, "Bone Leggings");
            ModLoader.addName(boneBoots, "Bone Boots");
            
            ModLoader.addName(saltItem, "Salt");
            ModLoader.addName(butterItem, "Butter");
            ModLoader.addName(cheeseItem, "Cheese");
            ModLoader.addName(doughItem, "Dough");
            ModLoader.addName(bakedpotatoItem, "Baked Potato");
            ModLoader.addName(butteredpotatoItem, "Buttered Potato");
            ModLoader.addName(loadedpotatoItem, "Loaded Potato");
            ModLoader.addName(friedeggsItem, "Fried Eggs");
            ModLoader.addName(friedpotatoesItem, "Fried Potatoes");
            ModLoader.addName(saladItem, "Salad");
            ModLoader.addName(saltedcookedfishItem, "Salted Fish");
            ModLoader.addName(pumpkinpieItem, "Pumpkin Pie");
            ModLoader.addName(pizzaItem, "Pizza");
            ModLoader.addName(spagettiItem, "Spagetti");
            ModLoader.addName(pastaItem, "Pasta");
            ModLoader.addName(friedonionringsItem, "Fried Onion Rings");
            ModLoader.addName(applepieItem, "Apple Pie");
            ModLoader.addName(applesauceItem, "Apple Sauce");
            ModLoader.addName(toastItem, "Toast");
            ModLoader.addName(grilledcheeseItem, "Grilled Cheese");
            ModLoader.addName(bltsandwichItem, "BLT Sandwich");
            ModLoader.addName(macncheeseItem, "Mac n Cheese");
            ModLoader.addName(fishsticksItem, "Fish Sticks");
            ModLoader.addName(mashedpotatoesItem, "Mashed Potatoes");
            ModLoader.addName(fishsandwichItem, "Fish Sandwich");
            ModLoader.addName(cerealItem, "Cereal");
            ModLoader.addName(popcornItem, "Popcorn");
            ModLoader.addName(butteredpopcornItem, "Buttered Popcorn");
            ModLoader.addName(cornonthecobItem, "Corn on the Cob");
            ModLoader.addName(saltedpeanutsItem, "Salted Peanuts");
            ModLoader.addName(pbnjsandwichItem, "PBnJ Sandwich");
            ModLoader.addName(raisinsItem, "Raisins");
            ModLoader.addName(cornbreadmuffinsItem, "Corn Bread Muffins");
            ModLoader.addName(tacoItem, "Taco");
            ModLoader.addName(nachosItem, "Nachos");
            ModLoader.addName(strawberrypieItem, "Strawberry Pie");
            ModLoader.addName(peanutbrittleItem, "Peanut Brittle");
            ModLoader.addName(chocolatebarItem, "Chocolate Bar");
            ModLoader.addName(driedappleslicesItem, "Dried Apple Slices");
            ModLoader.addName(driedstrawberriesItem, "Dried Strawberries");
            ModLoader.addName(trailmixItem, "Trailmix");
            ModLoader.addName(icecreamItem, "Ice Cream");
            ModLoader.addName(chocolateicecreamItem, "Chocolate Ice Cream");
            ModLoader.addName(strawberryicecreamItem, "Strawberry Ice Cream");
            ModLoader.addName(picklesItem, "Pickles");
            ModLoader.addName(chocolatecoveredfruitItem, "Chocolate Covered Fruit");
            ModLoader.addName(flourItem, "Flour");
            ModLoader.addName(cornmealdoughItem, "Cornmeal Dough");
            ModLoader.addName(cornmuffinmixItem, "Corn Muffin Mix");
            ModLoader.addName(tortillaItem, "Tortilla");
            ModLoader.addName(bottleItem, "Bottle");
            ModLoader.addName(mayoItem, "Mayo");
            ModLoader.addName(vinegarItem, "Vinegar");
            ModLoader.addName(peanutbutterItem, "Peanut Butter");
            ModLoader.addName(grapejellyItem, "Grape Jelly");
            ModLoader.addName(strawberryjamItem, "Strawberry Jam");
            ModLoader.addName(stockItem, "Stock");
            ModLoader.addName(noodlesoupItem, "Noodle Soup");
            ModLoader.addName(hambonesoupItem, "Ham Bone Soup");
            ModLoader.addName(cheesesoupItem, "Cheese Soup");
            ModLoader.addName(vegetablesoupItem, "Vegetable Soup");
            ModLoader.addName(onionsoupItem, "Onion Soup");
            ModLoader.addName(peanutsoupItem, "Peanut Soup");
            ModLoader.addName(cucumbersoupItem, "Cucumber Soup");
            ModLoader.addName(carrotsoupItem, "Carrot Soup");
            ModLoader.addName(pumpkinsoupItem, "Pumpkin Soup");
            ModLoader.addName(wheatsoupItem, "Wheat Soup");
            ModLoader.addName(potatosoupItem, "Potato Soup");
            ModLoader.addName(oatmealItem, "Oatmeal");
            ModLoader.addName(friedpicklesItem, "Fried Pickles");
            ModLoader.addName(shepardpieItem, "Shepard Pie");
            ModLoader.addName(strawberryiceItem, "Strawberry Ice");
            ModLoader.addName(sidesaladItem, "Side Salad");
            ModLoader.addName(breakfastsandwichItem, "Breakfast Sandwich");
            ModLoader.addName(coleslawItem, "Coleslaw");
            ModLoader.addName(fishlettucewrapItem, "Fish Lettuce Wrap");
            ModLoader.addName(fishtacoItem, "Fish Taco");
            ModLoader.addName(porklettucewrapItem, "Pork Lettuce Wrap");
            ModLoader.addName(pastasaladItem, "Pasta Salad");
            ModLoader.addName(potatosaladItem, "Potato Salad");
            ModLoader.addName(chocolatepeanutsItem, "Chocolate Peanuts");
            ModLoader.addName(pumpkinbreadItem, "Pumpkin Bread");
            //Ingrediant Names
            //Food Names
            ModLoader.addName(scrambledeggsItem, "Scrambled Eggs");
            ModLoader.addName(omeletItem, "Omelet");
            ModLoader.addName(sushiItem, "Sushi");
            ModLoader.addName(porkfriedriceItem, "Pork Fried Rice");
            ModLoader.addName(fiestariceItem, "Fiesta Rice");
            ModLoader.addName(stuffedpepperItem, "Stuffed Pepper");
            ModLoader.addName(beansandriceItem, "Beans and Rice");
            ModLoader.addName(ricecakeItem, "Rice Cake");
            ModLoader.addName(beanburritoItem, "Bean Burrito");
            ModLoader.addName(chiliItem, "Chili");
            ModLoader.addName(bakedbeansItem, "Baked Beans");
            ModLoader.addName(supremepizzaItem, "Supreme Pizza");
            ModLoader.addName(ricesoupItem, "Rice Soup");
            ModLoader.addName(veggiestirfryItem, "Veggie Stirfry");
            ModLoader.addName(carrotpilafItem, "Carrot Pilaf");
            ModLoader.addName(cornricemedleyItem, "Corn and Rice Medley");
            ModLoader.addName(mushroomrisottoItem, "Mushroom Risotto");
            ModLoader.addName(refriedbeansItem, "Refried Beans");
            ModLoader.addName(batterItem, "Batter");
            ModLoader.addName(syrupItem, "Syrup");
            ModLoader.addName(berrysyrupItem, "Berry Syrup");
            ModLoader.addName(wafflesItem, "Waffles");
            ModLoader.addName(fancywafflesItem, "Fancy Waffles");
            ModLoader.addName(pancakesItem, "Pancakes");
            ModLoader.addName(fancypancakesItem, "Fancy Pancakes");
            ModLoader.addName(frenchtoastItem, "French Toast");
            ModLoader.addName(berrysaladItem, "Berry Salad");
            ModLoader.addName(blueberrymuffinsItem, "Blueberry Muffins");
            ModLoader.addName(raspberrytartItem, "Raspberry Tart");
            ModLoader.addName(blackberrycobblerItem, "Blackberry Cobbler");
            ModLoader.addName(peachcobblerItem, "Peach Cobbler");
            ModLoader.addName(cherrypieItem, "Cherry Pie");
            ModLoader.addName(lemonpieItem, "Lemon Pie");
            ModLoader.addName(bananasplitItem, "Banana Split");
            ModLoader.addName(toastedcoconutItem, "Toasted Coconut");
            ModLoader.addName(fruitsaladItem, "Fruit Salad");
            ModLoader.addName(fruitjuiceItem, "Fruit Juice");
            ModLoader.addName(lemonaideItem, "Lemonaide");
            ModLoader.addName(grilledeggplantItem, "Grilled Eggplant");
            ModLoader.addName(eggplantparmItem, "Eggplant Parm");
            ModLoader.addName(stuffedeggplantItem, "Stuffed Eggplant");
            ModLoader.addName(teaItem, "Tea");
            ModLoader.addName(raspberryicedteaItem, "Raspberry Iced Tea");
            ModLoader.addName(chaiteaItem, "Chai Tea");
            ModLoader.addName(coffeeItem, "Coffee");
            ModLoader.addName(mochaicecreamItem, "Mocha Icecream");
            ModLoader.addName(espressoItem, "Espresso");
            ModLoader.addName(pickledbeetsItem, "Pickled Beets");
            ModLoader.addName(beetsaladItem, "Beet Salad");
            ModLoader.addName(beetsoupItem, "Beet Soup");
            ModLoader.addName(broccolimacItem, "Broccoli Mac");
            ModLoader.addName(broccolindipItem, "Broccoli n Dip");
            ModLoader.addName(creamedbroccolisoupItem, "Creamed Broccoli Soup");
            ModLoader.addName(grilledsweetpotatoItem, "Grilled Sweet Potato");
            ModLoader.addName(sweetpotatopieItem, "Sweet Potato Pie");
            ModLoader.addName(candiedsweetpotatoesItem, "Candied Sweet Potatoes");
            ModLoader.addName(marshmellowsItem, "Marshmellows");
            ModLoader.addName(splitpeasoupItem, "Split Pea Soup");
            ModLoader.addName(pineapplehamItem, "Pineapple Ham");
            ModLoader.addName(turnipsoupItem, "Turnip Soup");
            ModLoader.addName(banananutbreadItem, "Banana Nut Bread");
            ModLoader.addName(breadedchickenItem, "Breaded Chicken");
            ModLoader.addName(chickenparmItem, "Chicken Parm");
            ModLoader.addName(chickensandwichItem, "Chicken Sandwich");
            ModLoader.addName(chickennoodlesoupItem, "Chicken Noodle Soup");
            ModLoader.addName(hamburgerItem, "Hamburger");
            ModLoader.addName(cheeseburgerItem, "Cheeseburger");
            ModLoader.addName(baconcheeseburgerItem, "Baconcheeseburger");
            ModLoader.addName(spagettiandmeatballsItem, "Spagetti and Meatballs");
            ModLoader.addName(curryriceItem, "Curry Rice");
            ModLoader.addName(donutItem, "Donut");
            ModLoader.addName(chocolatedonutItem, "Chocolate Donut");
            ModLoader.addName(powdereddonutItem, "Powdered Donut");
            ModLoader.addName(jellydonutItem, "Jelly Donut");
            ModLoader.addName(frosteddonutItem, "Frosted Donut");
            ModLoader.addName(seedsoupItem, "Seed Soup");
            ModLoader.addName(oliveoilItem, "Olive Oil");
            ModLoader.addName(spidereyesoupItem, "Spider Eye Soup");
            ModLoader.addName(zombiejerkyItem, "Zombie Jerky");
            ModLoader.addName(gingerbreadItem, "Ginger Bread");
            ModLoader.addName(gingersnapsItem, "Ginger Snaps");
            ModLoader.addName(candiedgingerItem, "Candied Ginger");
            ModLoader.addName(saltedsunflowerseedsItem, "Salted Sunflower Seeds");
            ModLoader.addName(sunflowerwheatrollsItem, "Sunflower Wheat Rolls");
            ModLoader.addName(sunflowerbroccolisaladItem, "Sunflower Broccoli Salad");
            ModLoader.addName(mustardItem, "Mustard");
            ModLoader.addName(softpretzelItem, "Soft Pretzel");
            ModLoader.addName(softpretzelandmustardItem, "Soft Pretzel and Mustard Dip");
            ModLoader.addName(spicymustardporkItem, "Spicy Mustard Pork");
            ModLoader.addName(spicymustardgreensItem, "Spicy Mustard Greens");
            ModLoader.addName(veggiepizzaItem, "Veggie Pizza");
            ModLoader.addName(cheesecakeItem, "Cheesecake");
            ModLoader.addName(toppingcheesecakeItem, "Topping Cheesecake");
            ModLoader.addName(chocolatecheesecakeItem, "Chocolate Cheesecake");
            ModLoader.addName(pumpkincheesecakeItem, "Pumpkin Cheesecake");
            ModLoader.addName(barrelItem, "Barrel");
            ModLoader.addName(waterbarrelItem, "Water Barrel");
            ModLoader.addName(milkbarrelItem, "Milk Barrel");
            ModLoader.addName(buttermilkItem, "Butter Milk");
            ModLoader.addName(cafeconlecheItem, "Cafe con Leche");
            ModLoader.addName(garlicmashedpotatoesItem, "Garlic Mashed Potatoes");
            ModLoader.addName(garlicchickenItem, "Garlic Chicken");
            ModLoader.addName(garlictoastItem, "Garlic Toast");
            ModLoader.addName(nutmegspiceItem, "Nutmeg Spice");
            ModLoader.addName(vanillaItem, "Vanilla");
            ModLoader.addName(blackpepperItem, "Black Pepper");
            ModLoader.addName(beeswaxItem, "Beeswax");
            ModLoader.addName(pressedwaxItem, "Pressed Wax");
            
            ModLoader.addName(cocoapowderItem, "Cocoa Powder");
            ModLoader.addName(powderedsugarItem, "Powdered Sugar");
            ModLoader.addName(tablesaltItem, "Table Salt");
            ModLoader.addName(cornmealItem, "Cornmeal");
            ModLoader.addName(cinnamonspiceItem, "Cinnamon Spice");
            ModLoader.addName(groundcoffeeItem, "Ground Coffee");
            
            ModLoader.addName(tomatoseedItem, "Tomato Seed");
            ModLoader.addName(potatoseedItem, "Potato Seed");
            ModLoader.addName(lettuceseedItem, "Lettuce Seed");
            ModLoader.addName(onionseedItem, "Onion Seed");
            ModLoader.addName(carrotseedItem, "Carrot Seed");
            ModLoader.addName(cornseedItem, "Corn Seed");
            ModLoader.addName(strawberryseedItem, "Strawberry Seed");
            ModLoader.addName(cucumberseedItem, "Cucumber Seed");
            ModLoader.addName(riceseedItem, "Rice Seed");
            ModLoader.addName(beansseedItem, "Beans Seed");
            ModLoader.addName(bellpepperseedItem, "Bellpepper Seed");
            ModLoader.addName(eggplantseedItem, "Eggplant Seed");
            ModLoader.addName(teaseedItem, "Tea Seed");
            ModLoader.addName(coffeeseedItem, "Coffee Seed");
            ModLoader.addName(beetseedItem, "Beet Seed");
            ModLoader.addName(broccoliseedItem, "Broccoli Seed");
            ModLoader.addName(sweetpotatoseedItem, "Sweet Potato Seed");
            ModLoader.addName(peasseedItem, "Peas Seed");
            ModLoader.addName(pineappleseedItem, "Pineapple Seed");
            ModLoader.addName(turnipseedItem, "Turnip Seed");
            ModLoader.addName(gingerseedItem, "Ginger Seed");
            ModLoader.addName(mustardseedItem, "Mustard Seed");
            ModLoader.addName(garlicseedItem, "Garlic Seed");
            ModLoader.addName(rottenseedItem, "Rotten Seed");
            ModLoader.addName(harvestwheatseedItem, "Harvest Wheat Seed");
            ModLoader.addName(radishseedItem, "Radish Seed");
            ModLoader.addName(celeryseedItem, "Celery Seed");
            ModLoader.addName(zucchiniseedItem, "Zucchini Seed");
            ModLoader.addName(chilipepperseedItem, "Chili Pepper Seed");
            ModLoader.addName(cantaloupeseedItem, "Cantaloupe Seed");
            ModLoader.addName(asparagusseedItem, "Asparagus Seed");
            ModLoader.addName(cranberryseedItem, "Cranberry Seed");
            ModLoader.addName(spiceleafseedItem, "Spice Leaf Seed");
            
            ModLoader.addName(tomatoseedpacketItem, "Tomato Seed Packet");
            ModLoader.addName(potatoseedpacketItem, "Potato Seed Packet");
            ModLoader.addName(lettuceseedpacketItem, "Lettuce Seed Packet");
            ModLoader.addName(onionseedpacketItem, "Onion Seed Packet");
            ModLoader.addName(carrotseedpacketItem, "Carrot Seed Packet");
            ModLoader.addName(cornseedpacketItem, "Corn Seed Packet");
            ModLoader.addName(strawberryseedpacketItem, "Strawberry Seed Packet");
            ModLoader.addName(cucumberseedpacketItem, "Cucumber Seed Packet");
            ModLoader.addName(riceseedpacketItem, "Rice Seed Packet");
            ModLoader.addName(beansseedpacketItem, "Beans Seed Packet");
            ModLoader.addName(bellpepperseedpacketItem, "Bellpepper Seed Packet");
            ModLoader.addName(eggplantseedpacketItem, "Eggplant Seed Packet");
            ModLoader.addName(teaseedpacketItem, "Tea Seed Packet");
            ModLoader.addName(coffeeseedpacketItem, "Coffee Seed Packet");
            ModLoader.addName(beetseedpacketItem, "Beet Seed Packet");
            ModLoader.addName(broccoliseedpacketItem, "Broccoli Seed Packet");
            ModLoader.addName(sweetpotatoseedpacketItem, "Sweet Potato Seed Packet");
            ModLoader.addName(peasseedpacketItem, "Peas Seed Packet");
            ModLoader.addName(pineappleseedpacketItem, "Pineapple Seed Packet");
            ModLoader.addName(turnipseedpacketItem, "Turnip Seed Packet");
            ModLoader.addName(gingerseedpacketItem, "Ginger Seed Packet");
            ModLoader.addName(mustardseedpacketItem, "Mustard Seed Packet");
            ModLoader.addName(garlicseedpacketItem, "Garlic Seed Packet");
            ModLoader.addName(rottenseedpacketItem, "Rotten Seed Packet");
            ModLoader.addName(harvestwheatseedpacketItem, "Harvest Wheat Seed Packet");
            ModLoader.addName(cottonseedpacketItem, "Cotton Seed Packet");
            ModLoader.addName(candleberryseedpacketItem, "Candleberry Seed Packet");
            ModLoader.addName(cactusfruitseedpacketItem, "Cactus Fruit Seed Packet");
            ModLoader.addName(radishseedpacketItem, "Radish Seed Packet");
            ModLoader.addName(celeryseedpacketItem, "Celery Seed Packet");
            ModLoader.addName(zucchiniseedpacketItem, "Zucchini Seed Packet");
            ModLoader.addName(chilipepperseedpacketItem, "Chili Pepper Seed Packet");
            ModLoader.addName(cantaloupeseedpacketItem, "Cantaloupe Seed Packet");
            ModLoader.addName(asparagusseedpacketItem, "Asparagus Seed Packet");
            ModLoader.addName(cranberryseedpacketItem, "Cranberry Seed Packet");
            ModLoader.addName(spiceleafseedpacketItem, "Spice Leaf Seed Packet");
            
            ModLoader.addName(tomatoseedboxItem, "Tomato Seed Box");
            ModLoader.addName(potatoseedboxItem, "Potato Seed Box");
            ModLoader.addName(lettuceseedboxItem, "Lettuce Seed Box");
            ModLoader.addName(onionseedboxItem, "Onion Seed Box");
            ModLoader.addName(carrotseedboxItem, "Carrot Seed Box");
            ModLoader.addName(cornseedboxItem, "Corn Seed Box");
            ModLoader.addName(strawberryseedboxItem, "Strawberry Seed Box");
            ModLoader.addName(cucumberseedboxItem, "Cucumber Seed Box");
            ModLoader.addName(riceseedboxItem, "Rice Seed Box");
            ModLoader.addName(beansseedboxItem, "Beans Seed Box");
            ModLoader.addName(bellpepperseedboxItem, "Bellpepper Seed Box");
            ModLoader.addName(eggplantseedboxItem, "Eggplant Seed Box");
            ModLoader.addName(teaseedboxItem, "Tea Seed Box");
            ModLoader.addName(coffeeseedboxItem, "Coffee Seed Box");
            ModLoader.addName(beetseedboxItem, "Beet Seed Box");
            ModLoader.addName(broccoliseedboxItem, "Broccoli Seed Box");
            ModLoader.addName(sweetpotatoseedboxItem, "Sweet Potato Seed Box");
            ModLoader.addName(peasseedboxItem, "Peas Seed Box");
            ModLoader.addName(pineappleseedboxItem, "Pineapple Seed Box");
            ModLoader.addName(turnipseedboxItem, "Turnip Seed Box");
            ModLoader.addName(gingerseedboxItem, "Ginger Seed Box");
            ModLoader.addName(mustardseedboxItem, "Mustard Seed Box");
            ModLoader.addName(garlicseedboxItem, "Garlic Seed Box");
            ModLoader.addName(rottenseedboxItem, "Rotten Seed Box");
            ModLoader.addName(harvestwheatseedboxItem, "Harvest Wheat Seed Box");
            ModLoader.addName(cottonseedboxItem, "Cotton Seed Box");
            ModLoader.addName(candleberryseedboxItem, "Candleberry Seed Box");
            ModLoader.addName(cactusfruitseedboxItem, "Cactus Fruit Seed Box");
            ModLoader.addName(radishseedboxItem, "Radish Seed Box");
            ModLoader.addName(celeryseedboxItem, "Celery Seed Box");
            ModLoader.addName(zucchiniseedboxItem, "Zucchini Seed Box");
            ModLoader.addName(chilipepperseedboxItem, "Chili Pepper Seed Box");
            ModLoader.addName(cantaloupeseedboxItem, "Cantaloupe Seed Box");
            ModLoader.addName(asparagusseedboxItem, "Asparagus Seed Box");
            ModLoader.addName(cranberryseedboxItem, "Cranberry Seed Box");
            ModLoader.addName(spiceleafseedboxItem, "Spice Leaf Seed Box");
            
            ModLoader.addName(tomatoItem, "Tomato");
            ModLoader.addName(potatoItem, "Potato");
            ModLoader.addName(lettuceItem, "Lettuce");
            ModLoader.addName(onionItem, "Onion");
            ModLoader.addName(carrotItem, "Carrot");
            ModLoader.addName(cornItem, "Corn");
            ModLoader.addName(strawberryItem, "Strawberry");
            ModLoader.addName(cucumberItem, "Cucumber");
            ModLoader.addName(peppercornItem, "Peppercorn");
            ModLoader.addName(riceItem, "Rice");
            ModLoader.addName(beansItem, "Beans");
            ModLoader.addName(bellpepperItem, "Bellpepper");
            ModLoader.addName(eggplantItem, "Eggplant");
            ModLoader.addName(tealeafItem, "Tea Leaf");
            ModLoader.addName(coffeebeanItem, "Coffee Beans");
            ModLoader.addName(beetItem, "Beet");
            ModLoader.addName(broccoliItem, "Broccoli");
            ModLoader.addName(sweetpotatoItem, "Sweet Potato");
            ModLoader.addName(peasItem, "Peas");
            ModLoader.addName(pineappleItem, "Pineapple");
            ModLoader.addName(turnipItem, "Turnip");
            ModLoader.addName(gingerItem, "Ginger");
            ModLoader.addName(mustardseedsItem, "Mustard Seeds");
            ModLoader.addName(garlicItem, "Garlic");
            ModLoader.addName(harvestwheatItem, "Harvest Wheat");
            ModLoader.addName(radishItem, "Radish ");
            ModLoader.addName(celeryItem, "Celery ");
            ModLoader.addName(zucchiniItem, "Zucchini ");
            ModLoader.addName(chilipepperItem, "Chili Pepper ");
            ModLoader.addName(cantaloupeItem, "Cantaloupe ");
            ModLoader.addName(asparagusItem, "Asparagus");
            ModLoader.addName(cranberryItem, "Cranberry ");
            ModLoader.addName(spiceleafItem, "Spice Leaf ");
            
            ModLoader.addName(bananaItem, "Banana");
            ModLoader.addName(cherryItem, "Cherries");
            ModLoader.addName(coconutItem, "Coconut");
            ModLoader.addName(lemonItem, "Lemon");
            ModLoader.addName(orangeItem, "Orange");
            ModLoader.addName(peachItem, "Peach");
            ModLoader.addName(limeItem, "Lime");
            ModLoader.addName(mangoItem, "Mango");
            ModLoader.addName(walnutItem, "Walnuts");
            ModLoader.addName(pearItem, "Pear");
            ModLoader.addName(plumItem, "Plum");
            ModLoader.addName(oliveItem, "Olive");
            ModLoader.addName(cinnamonItem, "Cinnamon");
            ModLoader.addName(honeyItem, "Honey");
            ModLoader.addName(avacadoItem, "Avacado");
            ModLoader.addName(nutmegItem, "Nutmeg");
            ModLoader.addName(pomegranateItem, "Pomegranate");
            ModLoader.addName(vanillabeanItem, "Vanilla Bean");
            ModLoader.addName(papayaItem, "Papaya");
            ModLoader.addName(starfruitItem, "Starfruit");
            
            ModLoader.addName(blueberryItem, "Blueberries");
            ModLoader.addName(blackberryItem, "Blackberries");
            ModLoader.addName(raspberryItem, "Raspberries");
            ModLoader.addName(kiwiItem, "Kiwifruit");
            ModLoader.addName(grapeItem, "Grape");
            ModLoader.addName(peanutItem, "Peanut");
            ModLoader.addName(sunflowerseedsItem, "Sunflower Seeds");
            ModLoader.addName(whitemushroomItem, "White Mushroom");
            ModLoader.addName(cottonItem, "Cotton");
            ModLoader.addName(candleberryItem, "Candleberry");
            ModLoader.addName(blueberryseedItem, "Blueberry Seed");
            ModLoader.addName(blackberryseedItem, "Blackberry Seed");
            ModLoader.addName(raspberryseedItem, "Raspberry Seed");
            ModLoader.addName(kiwiseedItem, "Kiwifruit Seed");
            ModLoader.addName(grapeseedItem, "Grape Seed");
            ModLoader.addName(peanutseedItem, "Peanut Seed");
            ModLoader.addName(sunflowerseedItem, "Sunflower Seed");
            ModLoader.addName(whitemushroomseedItem, "White Mushroom Seed");
            ModLoader.addName(cottonseedItem, "Cotton Seed");
            ModLoader.addName(candleberryseedItem, "Candleberry Seed");
            ModLoader.addName(blueberryseedpacketItem, "Blueberry Seed Packet");
            ModLoader.addName(blackberryseedpacketItem, "Blackberry Seed Packet");
            ModLoader.addName(raspberryseedpacketItem, "Raspberry Seed Packet");
            ModLoader.addName(kiwiseedpacketItem, "Kiwifruit Seed Packet");
            ModLoader.addName(grapeseedpacketItem, "Grape Seed Packet");
            ModLoader.addName(peanutseedpacketItem, "Peanut Seed Packet");
            ModLoader.addName(sunflowerseedpacketItem, "Sunflower Seed Packet");
            ModLoader.addName(whitemushroomseedpacketItem, "White Mushroom Seed Packet");
            ModLoader.addName(cottonseedpacketItem, "Cotton Seed Packet");
            ModLoader.addName(candleberryseedpacketItem, "Candleberry Seed Packet");
            ModLoader.addName(blueberryseedboxItem, "Blueberry Seed Box");
            ModLoader.addName(blackberryseedboxItem, "Blackberry Seed Box");
            ModLoader.addName(raspberryseedboxItem, "Raspberry Seed Box");
            ModLoader.addName(kiwiseedboxItem, "Kiwifruit Seed Box");
            ModLoader.addName(grapeseedboxItem, "Grape Seed Box");
            ModLoader.addName(peanutseedboxItem, "Peanut Seed Box");
            ModLoader.addName(sunflowerseedboxItem, "Sunflower Seed Box");
            ModLoader.addName(whitemushroomseedboxItem, "White Mushroom Seed Box");
            ModLoader.addName(cottonseedboxItem, "Cotton Seed Box");
            ModLoader.addName(candleberryseedboxItem, "Candleberry Seed Box");
            ModLoader.addName(wovenclothItem, "Woven Cloth");
            ModLoader.addName(cottonHelm, "Cloth Hood");
            ModLoader.addName(cottonChest, "Cloth Robe");
            ModLoader.addName(cottonLegs, "Cloth Leggings");
            ModLoader.addName(cottonBoots, "Cloth Shoes");
            ModLoader.addName(hardenedleatherItem, "Hardened Leather");
            ModLoader.addName(hardenedleatherHelm, "Hardened Leather Helm");
            ModLoader.addName(hardenedleatherChest, "Hardened Leather Chestpiece");
            ModLoader.addName(hardenedleatherLegs, "Hardened Leather Leggings");
            ModLoader.addName(hardenedleatherBoots, "Hardened Leather Boots");
            
            ModLoader.addName(zincoreItem, "Zinc Ore");
            ModLoader.addName(tinoreItem, "Tin Ore");
            ModLoader.addName(copperoreItem, "Copper Ore");
            ModLoader.addName(silveroreItem, "Silver Ore");
            ModLoader.addName(cobaltoreItem, "Cobalt Ore");
            ModLoader.addName(platinumoreItem, "Platinum Ore");
            ModLoader.addName(titaniumoreItem, "Titanium Ore");
            ModLoader.addName(mithriloreItem, "Mithril Ore");
            ModLoader.addName(flawedquartzgemItem, "Flawed Quartz");
            ModLoader.addName(flawedcitrinegemItem, "Flawed Citrine");
            ModLoader.addName(flawedtanzanitegemItem, "Flawed Tanzanite");
            ModLoader.addName(flawedsapphiregemItem, "Flawed Sapphire");
            ModLoader.addName(flawedtopazgemItem, "Flawed Topaz");
            ModLoader.addName(flawedagategemItem, "Flawed Agate");
            ModLoader.addName(flawedgarnetgemItem, "Flawed Garnet");
            ModLoader.addName(flawedhematitegemItem, "Flawed Hematite");
            ModLoader.addName(flawedmoonstonegemItem, "Flawed Moonstone");
            ModLoader.addName(flawedaquamarinegemItem, "Flawed Aquamarine");
            ModLoader.addName(flawedamethystgemItem, "Flawed Amethyst");
            ModLoader.addName(flawedtigerseyegemItem, "Flawed Tigerseye");
            ModLoader.addName(flawedemeraldgemItem, "Flawed Emerald");
            ModLoader.addName(flawedrubygemItem, "Flawed Ruby");
            ModLoader.addName(flawedonyxgemItem, "Flawed Onyx");
            ModLoader.addName(zincingotItem, "Zinc Ingot");
            ModLoader.addName(tiningotItem, "Tin Ingot");
            ModLoader.addName(copperingotItem, "Copper Ingot");
            ModLoader.addName(silveringotItem, "Silver Ingot");
            ModLoader.addName(cobaltingotItem, "Cobalt Ingot");
            ModLoader.addName(platinumingotItem, "Platinum Ingot");
            ModLoader.addName(titaniumingotItem, "Titanium Ingot");
            ModLoader.addName(mithrilingotItem, "Mithril Ingot");
            ModLoader.addName(bronzealloyItem, "Bronze Alloy");
            ModLoader.addName(steelalloyItem, "Steel Alloy");
            ModLoader.addName(bronzeingotItem, "Bronze Ingot");
            ModLoader.addName(steelingotItem, "Steel Ingot");
            ModLoader.addName(saltpeterItem, "Saltpeter");
            ModLoader.addName(sulphurItem, "Sulphur");
            ModLoader.addName(copperPick, "Copper Pickaxe");
            ModLoader.addName(copperShovel, "Copper Shovel");
            ModLoader.addName(copperAxe, "Copper Axe");
            ModLoader.addName(copperHoe, "Copper Hoe");
            ModLoader.addName(copperSword, "Copper Sword");
            ModLoader.addName(copperHelm, "Copper Helm");
            ModLoader.addName(copperChest, "Copper Chestpiece");
            ModLoader.addName(copperLegs, "Copper Leggings");
            ModLoader.addName(copperBoots, "Copper Boots");
            ModLoader.addName(tinPick, "Tin Pickaxe");
            ModLoader.addName(tinShovel, "Tin Shovel");
            ModLoader.addName(tinAxe, "Tin Axe");
            ModLoader.addName(tinHoe, "Tin Hoe");
            ModLoader.addName(tinSword, "Tin Sword");
            ModLoader.addName(tinHelm, "Tin Helm");
            ModLoader.addName(tinChest, "Tin Chestpiece");
            ModLoader.addName(tinLegs, "Tin Leggings");
            ModLoader.addName(tinBoots, "Tin Boots");
            ModLoader.addName(bronzePick, "Bronze Pickaxe");
            ModLoader.addName(bronzeShovel, "Bronze Shovel");
            ModLoader.addName(bronzeAxe, "Bronze Axe");
            ModLoader.addName(bronzeHoe, "Bronze Hoe");
            ModLoader.addName(bronzeSword, "Bronze Sword");
            ModLoader.addName(bronzeHelm, "Bronze Helm");
            ModLoader.addName(bronzeChest, "Bronze Chestpiece");
            ModLoader.addName(bronzeLegs, "Bronze Leggings");
            ModLoader.addName(bronzeBoots, "Bronze Boots");
            ModLoader.addName(silverPick, "Silver Pickaxe");
            ModLoader.addName(silverShovel, "Silver Shovel");
            ModLoader.addName(silverAxe, "Silver Axe");
            ModLoader.addName(silverHoe, "Silver Hoe");
            ModLoader.addName(silverSword, "Silver Sword");
            ModLoader.addName(silverHelm, "Silver Helm");
            ModLoader.addName(silverChest, "Silver Chestpiece");
            ModLoader.addName(silverLegs, "Silver Leggings");
            ModLoader.addName(silverBoots, "Silver Boots");
            ModLoader.addName(cobaltPick, "Cobalt Pickaxe");
            ModLoader.addName(cobaltShovel, "Cobalt Shovel");
            ModLoader.addName(cobaltAxe, "Cobalt Axe");
            ModLoader.addName(cobaltHoe, "Cobalt Hoe");
            ModLoader.addName(cobaltSword, "Cobalt Sword");
            ModLoader.addName(cobaltHelm, "Cobalt Helm");
            ModLoader.addName(cobaltChest, "Cobalt Chestpiece");
            ModLoader.addName(cobaltLegs, "Cobalt Leggings");
            ModLoader.addName(cobaltBoots, "Cobalt Boots");
            ModLoader.addName(steelPick, "Steel Pickaxe");
            ModLoader.addName(steelShovel, "Steel Shovel");
            ModLoader.addName(steelAxe, "Steel Axe");
            ModLoader.addName(steelHoe, "Steel Hoe");
            ModLoader.addName(steelSword, "Steel Sword");
            ModLoader.addName(steelHelm, "Steel Helm");
            ModLoader.addName(steelChest, "Steel Chestpiece");
            ModLoader.addName(steelLegs, "Steel Leggings");
            ModLoader.addName(steelBoots, "Steel Boots");
            ModLoader.addName(platinumPick, "Platinum Pickaxe");
            ModLoader.addName(platinumShovel, "Platinum Shovel");
            ModLoader.addName(platinumAxe, "Platinum Axe");
            ModLoader.addName(platinumHoe, "Platinum Hoe");
            ModLoader.addName(platinumSword, "Platinum Sword");
            ModLoader.addName(platinumHelm, "Platinum Helm");
            ModLoader.addName(platinumChest, "Platinum Chestpiece");
            ModLoader.addName(platinumLegs, "Platinum Leggings");
            ModLoader.addName(platinumBoots, "Platinum Boots");
            ModLoader.addName(titaniumPick, "Titanium Pickaxe");
            ModLoader.addName(titaniumShovel, "Titanium Shovel");
            ModLoader.addName(titaniumAxe, "Titanium Axe");
            ModLoader.addName(titaniumHoe, "Titanium Hoe");
            ModLoader.addName(titaniumSword, "Titanium Sword");
            ModLoader.addName(titaniumHelm, "Titanium Helm");
            ModLoader.addName(titaniumChest, "Titanium Chestpiece");
            ModLoader.addName(titaniumLegs, "Titanium Leggings");
            ModLoader.addName(titaniumBoots, "Titanium Boots");
            ModLoader.addName(mithrilPick, "Mithril Pickaxe");
            ModLoader.addName(mithrilShovel, "Mithril Shovel");
            ModLoader.addName(mithrilAxe, "Mithril Axe");
            ModLoader.addName(mithrilHoe, "Mithril Hoe");
            ModLoader.addName(mithrilSword, "Mithril Sword");
            ModLoader.addName(mithrilHelm, "Mithril Helm");
            ModLoader.addName(mithrilChest, "Mithril Chestpiece");
            ModLoader.addName(mithrilLegs, "Mithril Leggings");
            ModLoader.addName(mithrilBoots, "Mithril Boots");
        }
            
     public void load3()
     {
    	 for (int i = 0; i < 14; i++)
         {
             int spacer = 0;

             if (i > 3)
             {
                 spacer += 1;
             }
             if (i > 12)
             {
                 spacer += 1;
             }
             ModLoader.addShapelessRecipe(new ItemStack(Block.cloth, 1, i + spacer), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, i), new ItemStack(Item.itemsList[Block.cloth.blockID], 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 15/*white*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 0/*white*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 14/*orange*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 1/*orange*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 13/*magenta*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 2/*magenta*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 12/*lightblue*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 3/*lightblue*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 11/*yellow*/), new Object[]
                     {
                         new ItemStack(Block.plantYellow, 1, 0/*yellow*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 10/*lime*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 4/*lime*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 9/*pink*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 5/*pink*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 8/*grey*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 6/*grey*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 7/*lightgrey*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 7/*lightgrey*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 6/*cyan*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 8/*cyan*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 5/*purple*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 9/*purple*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 4/*blue*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 10/*blue*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 3/*brown*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 11/*brown*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 2/*green*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 12/*green*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 1/*red*/), new Object[]
                     {
                         new ItemStack(Block.plantRed, 1, 0/*red*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, flowerdyerecipeOutput, 0/*black*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 13/*black*/), new ItemStack(373, 1, 0), new ItemStack(Item.redstone, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.whiteflowerseedItem, flowerseedrecipeOutput, 0/*white*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 0/*white*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 0/*white*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.orangeflowerseedItem, flowerseedrecipeOutput, 0/*orange*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 1/*orange*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 1/*orange*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.magentaflowerseedItem, flowerseedrecipeOutput, 0/*magenta*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 2/*magenta*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 2/*magenta*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.lightblueflowerseedItem, flowerseedrecipeOutput, 0/*lightblue*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 3/*lightblue*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 3/*lightblue*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.yellowflowerseedItem, flowerseedrecipeOutput, 0/*yellow*/), new Object[]
                     {
                         new ItemStack(Block.plantYellow, 1, 0/*yellow*/), new ItemStack(Block.plantYellow, 1, 0/*yellow*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.limeflowerseedItem, flowerseedrecipeOutput, 0/*lime*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 4/*lime*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 4/*lime*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pinkflowerseedItem, flowerseedrecipeOutput, 0/*pink*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 5/*pink*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 5/*pink*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.darkgreyflowerseedItem, flowerseedrecipeOutput, 0/*grey*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 6/*grey*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 6/*grey*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.lightgreyflowerseedItem, flowerseedrecipeOutput, 0/*lightgrey*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 7/*lightgrey*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 7/*lightgrey*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.cyanflowerseedItem, flowerseedrecipeOutput, 0/*cyan*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 8/*cyan*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 8/*cyan*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.purpleflowerseedItem, flowerseedrecipeOutput, 0/*purple*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 9/*purple*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 9/*purple*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.blueflowerseedItem, flowerseedrecipeOutput, 0/*blue*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 10/*blue*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 10/*blue*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.brownflowerseedItem, flowerseedrecipeOutput, 0/*brown*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 11/*brown*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 11/*brown*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.greenflowerseedItem, flowerseedrecipeOutput, 0/*green*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 12/*green*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 12/*green*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.redflowerseedItem, flowerseedrecipeOutput, 0/*red*/), new Object[]
                     {
                         new ItemStack(Block.plantRed, 1, 0/*red*/), new ItemStack(Block.plantRed, 1, 0/*red*/)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.blackflowerseedItem, flowerseedrecipeOutput, 0/*black*/), new Object[]
                     {
                         new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 13/*black*/), new ItemStack(Item.itemsList[Pamcombinedmod.pamFlower.blockID], 1, 13/*black*/)
                     });
         }
             
           //Cactus Stick Recipe
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusstickItem, 4), new Object[]
                     {
                         "X", "X", 'X', Block.cactus
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.cactusfruitseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(cactusfruitItem, 1)
                     });
             //Sandstone to Sand
             ModLoader.addShapelessRecipe(new ItemStack(Block.sand, 4, 0), new Object[]
                     {
                         new ItemStack(Block.sandStone, 1)
                     });
             //Cactus Fruit Block to Cactus Fruit
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.cactusfruitItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamdesertPlant, 1, 0)
                     });
             //Glass Steel Block
             /*ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamglasssteelBlock, 1), new Object[]
                     {
                         "XX", "XX", 'X', glasssteelItem
                     });*/
             //Cactus Tools
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.stick, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.bone, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', cactusstickItem, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.stick, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.bone, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', cactusstickItem, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusPick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.stick, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusPick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.bone, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusPick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', cactusstickItem, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.stick, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.bone, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', cactusstickItem, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.stick, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.bone, '@', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cactusSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', cactusstickItem, '@', Block.cactus
                     });
             //Wood-Cactus Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeWood, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', cactusstickItem, '@', Block.planks
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeWood, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', cactusstickItem, '@', Block.planks
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeWood, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', cactusstickItem, '@', Block.planks
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelWood, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', cactusstickItem, '@', Block.planks
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordWood, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', cactusstickItem, '@', Block.planks
                     });
             //Sandstone Tools
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.stick, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', cactusstickItem, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.bone, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.stick, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.bone, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', cactusstickItem, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstonePick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.stick, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstonePick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.bone, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstonePick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', cactusstickItem, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.stick, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.bone, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', cactusstickItem, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.stick, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.bone, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.sandstoneSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', cactusstickItem, '@', Block.sandStone
                     });
             //Stone-Cactus Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeStone, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', cactusstickItem, '@', Block.cobblestone
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeStone, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', cactusstickItem, '@', Block.cobblestone
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeStone, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', cactusstickItem, '@', Block.cobblestone
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelStone, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', cactusstickItem, '@', Block.cobblestone
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordStone, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', cactusstickItem, '@', Block.cobblestone
                     });
             //Iron-Cactus Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeSteel, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', cactusstickItem, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeSteel, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', cactusstickItem, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeSteel, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', cactusstickItem, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelSteel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', cactusstickItem, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordSteel, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', cactusstickItem, '@', Item.ingotIron
                     });
             //Glass Steel Recipe
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelItem, 4), new Object[]
                     {
                         " X ", "X@X", " X ", 'X', Block.glass, '@', Item.ingotIron
                     });
             //Glass Steel Tools
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.stick, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.bone, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelAxe, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', cactusstickItem, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.stick, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.bone, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelHoe, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', cactusstickItem, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelPick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.stick, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelPick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.bone, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelPick, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', cactusstickItem, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.stick, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.bone, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelShovel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', cactusstickItem, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.stick, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.bone, '@', glasssteelItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.glasssteelSword, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', cactusstickItem, '@', glasssteelItem
                     });
             //Gold-Cactus Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeGold, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', cactusstickItem, '@', Item.ingotGold
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeGold, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', cactusstickItem, '@', Item.ingotGold
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeGold, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', cactusstickItem, '@', Item.ingotGold
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelGold, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', cactusstickItem, '@', Item.ingotGold
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordGold, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', cactusstickItem, '@', Item.ingotGold
                     });
             //Diamond-Cactus Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeDiamond, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', cactusstickItem, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeDiamond, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', cactusstickItem, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeDiamond, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', cactusstickItem, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelDiamond, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', cactusstickItem, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordDiamond, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', cactusstickItem, '@', Item.diamond
                     });
             //Cactus Block Recipes
             ModLoader.addRecipe(new ItemStack(Block.chest, 1), new Object[]
                     {
                         "XXX", "X X", "XXX", 'X', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Block.workbench, 1), new Object[]
                     {
                         "XX", "XX", 'X', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Block.jukebox, 1), new Object[]
                     {
                         "XXX", "X@X", "XXX", 'X', Block.cactus, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Block.music, 1), new Object[]
                     {
                         "XXX", "X@X", "XXX", 'X', Block.cactus, '@', Item.redstone
                     });
             ModLoader.addRecipe(new ItemStack(Block.bookShelf, 1), new Object[]
                     {
                         "XXX", "@@@", "XXX", 'X', Block.cactus, '@', Item.book
                     });
             /*ModLoader.addRecipe(new ItemStack(Block.stairSingle, 3, 2), new Object[]
                     {
                         "XXX", 'X', Block.cactus
                     });*/
             ModLoader.addRecipe(new ItemStack(Item.doorWood, 1), new Object[]
                     {
                         "XX ", "XX ", "XX ", 'X', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Block.trapdoor, 2), new Object[]
                     {
                         "XXX", "XXX", 'X', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Item.sign, 1), new Object[]
                     {
                         "XXX", "XXX", " @ ", 'X', Block.cactus, '@', Item.stick
                     });
             ModLoader.addRecipe(new ItemStack(Item.sign, 1), new Object[]
                     {
                         "XXX", "XXX", " @ ", 'X', Block.cactus, '@', cactusstickItem
                     });
             ModLoader.addRecipe(new ItemStack(Item.bowlEmpty, 4), new Object[]
                     {
                         "X X", " X ", 'X', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Item.boat, 1), new Object[]
                     {
                         "X X", "XXX", 'X', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Block.stairCompactPlanks, 4), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Block.pressurePlatePlanks, 1), new Object[]
                     {
                         "XX", 'X', Block.cactus
                     });
             ModLoader.addRecipe(new ItemStack(Block.pistonBase, 1), new Object[]
                     {
                         "TTT", "#X#", "#R#", 'T', Block.cactus, '#', Block.cobblestone, 'X', Item.ingotIron,
                         'R', Item.redstone
                     });
             ModLoader.addRecipe(new ItemStack(Block.pistonBase, 1), new Object[]
                     {
                         "TTT", "#X#", "#R#", 'T', Block.cactus, '#', Block.sandStone, 'X', Item.ingotIron,
                         'R', Item.redstone
                     });
             ModLoader.addRecipe(new ItemStack(Item.bed, 1), new Object[]
                     {
                         "@@@", "XXX", 'X', Block.cactus, '@', Block.cloth
                     });
             ModLoader.addRecipe(new ItemStack(Block.fenceGate, 1), new Object[]
                     {
                         "#W#", "#W#", '#', Item.stick, 'W', Block.cactus
                     });
             //Cactus Stick Recipes
             ModLoader.addRecipe(new ItemStack(Block.fence, 2), new Object[]
                     {
                         "XXX", "XXX", 'X', cactusstickItem
                     });
             ModLoader.addRecipe(new ItemStack(Block.ladder, 2), new Object[]
                     {
                         "X X", "XXX", "X X", 'X', cactusstickItem
                     });
             ModLoader.addRecipe(new ItemStack(Block.torchWood, 4), new Object[]
                     {
                         "@", "X", 'X', cactusstickItem, '@', Item.coal
                     });
             ModLoader.addRecipe(new ItemStack(Block.torchWood, 4), new Object[]
                     {
                         "@", "X", 'X', cactusstickItem, '@', new ItemStack(Item.coal, 1, 1)
                     });
             ModLoader.addRecipe(new ItemStack(Block.rail, 16), new Object[]
                     {
                         "X X", "X@X", "X X", 'X', cactusstickItem, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Block.railPowered, 6), new Object[]
                     {
                         "X X", "X@X", "XRX", 'X', cactusstickItem, '@', Item.ingotGold, 'R', Item.redstone
                     });
             ModLoader.addRecipe(new ItemStack(Item.fishingRod, 1), new Object[]
                     {
                         "  #", " #X", "# X", '#', cactusstickItem, 'X', Item.silk
                     });
             ModLoader.addRecipe(new ItemStack(Item.painting, 1), new Object[]
                     {
                         "###", "#X#", "###", '#', cactusstickItem, 'X', Block.cloth
                     });
             ModLoader.addRecipe(new ItemStack(Block.lever, 1), new Object[]
                     {
                         "@", "X", 'X', cactusstickItem, '@', Block.cobblestone
                     });
             ModLoader.addRecipe(new ItemStack(Item.arrow, 4), new Object[]
                     {
                         "@", "X", "Y", 'X', cactusstickItem, '@', Item.flint, 'Y', Item.feather
                     });
             ModLoader.addRecipe(new ItemStack(Item.bow, 1), new Object[]
                     {
                         " #X", "# X", " #X", 'X', Item.silk, '#', cactusstickItem
                     });
             ModLoader.addRecipe(new ItemStack(Block.fenceGate, 1), new Object[]
                     {
                         "#W#", "#W#", '#', cactusstickItem, 'W', Block.planks
                     });
             //Sandstone Recipes
             ModLoader.addRecipe(new ItemStack(Block.stoneOvenIdle, 1), new Object[]
                     {
                         "XXX", "X X", "XXX", 'X', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Block.pistonBase, 1), new Object[]
                     {
                         "TTT", "#X#", "#R#", 'T', Block.planks, '#', Block.sandStone, 'X', Item.ingotIron,
                         'R', Item.redstone
                     });
             ModLoader.addRecipe(new ItemStack(Block.lever, 1), new Object[]
                     {
                         "@", "X", 'X', Item.stick, '@', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Block.button, 1), new Object[]
                     {
                         "X", "X", 'X', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Block.stairCompactCobblestone, 4), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Block.pressurePlateStone, 1), new Object[]
                     {
                         "XX", 'X', Block.sandStone
                     });
             ModLoader.addRecipe(new ItemStack(Block.dispenser, 1), new Object[]
                     {
                         "XXX", "X@X", "XRX", 'X', Block.sandStone, '@', Item.bow, 'R', Item.redstone
                     });
             
           //Pick Recipes
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.bonePick, 1), new Object[]
                     {
                         "XXX", " X ", " X ", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.bonePick, 1), new Object[]
                     {
                         "XXX", " | ", " | ", 'X', Item.bone, '|', Item.stick
                     });
             //ModLoader.addRecipe(new ItemStack(Pamcombinedmod.bonePick, 1), new Object[] {
             //"XXX", " | ", " | ", 'X', Item.bone, '|', Pamcombinedmod.cactusstickItem
             //});
             //Shovel Recipes
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneShovel, 1), new Object[]
                     {
                         " X ", " X ", " X ", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneShovel, 1), new Object[]
                     {
                         " X ", " | ", " | ", 'X', Item.bone, '|', Item.stick
                     });
             //ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneShovel, 1), new Object[] {
             //" X ", " | ", " | ", 'X', Item.bone, '|', ItemCactusStick
             //});
             //Axe Recipes
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneAxe, 1), new Object[]
                     {
                         "XX ", "XX ", " X ", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneAxe, 1), new Object[]
                     {
                         "XX ", "X| ", " | ", 'X', Item.bone, '|', Item.stick
                     });
             //ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneAxe, 1), new Object[] {
             //"XX ", "X| ", " | ", 'X', Item.bone, '|', ItemCactusStick
             //});
             //Hoe Recipes
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneHoe, 1), new Object[]
                     {
                         "XX ", " X ", " X ", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneHoe, 1), new Object[]
                     {
                         "XX ", " | ", " | ", 'X', Item.bone, '|', Item.stick
                     });
             //ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneHoe, 1), new Object[] {
             //"XX ", " | ", " | ", 'X', Item.bone, '|', ItemCactusStick
             //});
             //Sword Recipes
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneSword, 1), new Object[]
                     {
                         "X  ", " X ", "  X", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneSword, 1), new Object[]
                     {
                         "  X", " X ", "X  ", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneSword, 1), new Object[]
                     {
                         " X ", " X ", " | ", 'X', Item.bone, '|', Item.stick
                     });
             //ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneSword, 1), new Object[] {
             //" X ", " X ", " | ", 'X', Item.bone, '|', ItemCactusStick
             //});
             //Wood-Bone Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeWood, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.bone, '@', Block.planks
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeWood, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.bone, '@', Block.planks
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeWood, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.bone, '@', Block.planks
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelWood, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.bone, '@', Block.planks
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordWood, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.bone, '@', Block.planks
                     });
             //Stone-Bone Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeStone, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.bone, '@', Block.stone
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeStone, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.bone, '@', Block.stone
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeStone, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.bone, '@', Block.stone
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelStone, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.bone, '@', Block.stone
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordStone, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.bone, '@', Block.stone
                     });
             //Iron-Bone Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeSteel, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.bone, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeSteel, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.bone, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeSteel, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.bone, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelSteel, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.bone, '@', Item.ingotIron
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordSteel, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.bone, '@', Item.ingotIron
                     });
             //Gold-Bone Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeGold, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.bone, '@', Item.ingotGold
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeGold, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.bone, '@', Item.ingotGold
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeGold, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.bone, '@', Item.ingotGold
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelGold, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.bone, '@', Item.ingotGold
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordGold, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.bone, '@', Item.ingotGold
                     });
             //Diamond-Bone Stick Tools
             ModLoader.addRecipe(new ItemStack(Item.axeDiamond, 1), new Object[]
                     {
                         "@@ ", "@X ", " X ", 'X', Item.bone, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Item.hoeDiamond, 1), new Object[]
                     {
                         "@@ ", " X ", " X ", 'X', Item.bone, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Item.pickaxeDiamond, 1), new Object[]
                     {
                         "@@@", " X ", " X ", 'X', Item.bone, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Item.shovelDiamond, 1), new Object[]
                     {
                         " @ ", " X ", " X ", 'X', Item.bone, '@', Item.diamond
                     });
             ModLoader.addRecipe(new ItemStack(Item.swordDiamond, 1), new Object[]
                     {
                         " @ ", " @ ", " X ", 'X', Item.bone, '@', Item.diamond
                     });
             //Armor Recipes
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneHelm, 1), new Object[]
                     {
                         "XXX", "X X", "   ", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneHelm, 1), new Object[]
                     {
                         "XXX", "X X", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneChest, 1), new Object[]
                     {
                         "X X", "XXX", "XXX", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneLegs, 1), new Object[]
                     {
                         "XXX", "X X", "X X", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneBoots, 1), new Object[]
                     {
                         "X X", "X X", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.boneBoots, 1), new Object[]
                     {
                         "X X", "X X", 'X', Item.bone
                     });
             //Bone as Stick Recipes
             ModLoader.addRecipe(new ItemStack(Block.fence, 2), new Object[]
                     {
                         "XXX", "XXX", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Block.ladder, 2), new Object[]
                     {
                         "X X", "XXX", "X X", 'X', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Block.torchWood, 4), new Object[]
                     {
                         "@", "X", 'X', Item.bone, '@', Item.coal
                     });
             ModLoader.addRecipe(new ItemStack(Block.torchWood, 4), new Object[]
                     {
                         "@", "X", 'X', Item.bone, '@', new ItemStack(Item.coal, 1, 1)
                     });
             ModLoader.addRecipe(new ItemStack(Block.rail, 16), new Object[]
                     {
                         "X X", "X@X", "X X", 'X', Item.ingotIron, '@', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Block.railPowered, 6), new Object[]
                     {
                         "X X", "X@X", "XRX", 'X', Item.ingotGold, '@', Item.bone, 'R', Item.redstone
                     });
             ModLoader.addRecipe(new ItemStack(Item.fishingRod, 1), new Object[]
                     {
                         "  #", " #X", "# X", '#', Item.bone, 'X', Item.silk
                     });
             ModLoader.addRecipe(new ItemStack(Item.painting, 1), new Object[]
                     {
                         "###", "#X#", "###", '#', Item.bone, 'X', Block.cloth
                     });
             ModLoader.addRecipe(new ItemStack(Block.lever, 1), new Object[]
                     {
                         "@", "X", 'X', Block.cobblestone, '@', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Item.arrow, 4), new Object[]
                     {
                         "@", "X", "Y", 'X', Item.bone, '@', Item.flint, 'Y', Item.feather
                     });
             ModLoader.addRecipe(new ItemStack(Item.sign, 1), new Object[]
                     {
                         "XXX", "XXX", " @ ", 'X', Block.cactus, '@', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Item.bow, 1), new Object[]
                     {
                         " #X", "# X", " #X", 'X', Item.silk, '#', Item.bone
                     });
             ModLoader.addRecipe(new ItemStack(Block.fenceGate, 1), new Object[]
                     {
                         "#W#", "#W#", '#', Item.bone, 'W', Block.planks
                     });
             
          // New Ingrediants Recipes
             
             ModLoader.addShapelessRecipe(new ItemStack(doughItem, 1, 0), new Object[]
                     {
                         new ItemStack(flourItem, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             //Dough
             ModLoader.addShapelessRecipe(new ItemStack(doughItem, 1, 0), new Object[]
                     {
                         new ItemStack(flourItem, 1), new ItemStack(waterbarrelItem, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             //Pasta
             ModLoader.addShapelessRecipe(new ItemStack(pastaItem, 1, 0), new Object[]
                     {
                         new ItemStack(flourItem, 1, 0), new ItemStack(butterItem, 1, 0)
                     });
             //Cornmeal Dough
             ModLoader.addShapelessRecipe(new ItemStack(cornmealdoughItem, 1, 0), new Object[]
                     {
                         new ItemStack(cornmealItem, 1, 0), new ItemStack(Item.bucketWater, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             //Cornmeal Dough
             ModLoader.addShapelessRecipe(new ItemStack(cornmealdoughItem, 1, 0), new Object[]
                     {
                         new ItemStack(cornmealItem, 1, 0), new ItemStack(waterbarrelItem, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             //Corn Muffin Mix
             ModLoader.addShapelessRecipe(new ItemStack(cornmuffinmixItem, 1, 0), new Object[]
                     {
                         new ItemStack(cornmealdoughItem, 1, 0), new ItemStack(Item.egg, 1, 0)
                     });
             //Mayo
             ModLoader.addRecipe(new ItemStack(mayoItem, 1, 0), new Object[]
                     {
                         "O", "#", '#', Item.glassBottle, 'O', Item.egg
                     });
             //Vinegar
             ModLoader.addRecipe(new ItemStack(vinegarItem, 1, 0), new Object[]
                     {
                         "O", "#", '#', Item.glassBottle, 'O', grapeItem
                     });
             //Peanut Butter
             ModLoader.addRecipe(new ItemStack(peanutbutterItem, 1, 0), new Object[]
                     {
                         "O", "#", '#', Item.glassBottle, 'O', peanutItem
                     });
             //Grape Jelly
             ModLoader.addRecipe(new ItemStack(grapejellyItem, 1, 0), new Object[]
                     {
                         " O ", " S ", " # ", '#', Item.glassBottle, 'O', grapeItem, 'S', Item.sugar
                     });
             //Strawberry Jam
             ModLoader.addRecipe(new ItemStack(strawberryjamItem, 1, 0), new Object[]
                     {
                         " O ", " S ", " # ", '#', Item.glassBottle, 'O', strawberryItem, 'S', Item.sugar
                     });
             //Stock
             ModLoader.addRecipe(new ItemStack(stockItem, 1, 0), new Object[]
                     {
                         "O", "#", '#', Item.bowlEmpty, 'O', Item.bone
                     });
             //Olive Oil
             ModLoader.addRecipe(new ItemStack(oliveoilItem, 1, 0), new Object[]
                     {
                         "O", "#", '#', Item.glassBottle, 'O', oliveItem
                     });
             //Mustard
             ModLoader.addRecipe(new ItemStack(mustardItem, 1, 0), new Object[]
                     {
                         "O", "#", '#', vinegarItem, 'O', mustardseedsItem
                     });
             // Baked Potato Recipes
             //Buttered Potato
             ModLoader.addShapelessRecipe(new ItemStack(butteredpotatoItem, 1, 0), new Object[]
                     {
                         new ItemStack(bakedpotatoItem, 1, 0), new ItemStack(tablesaltItem, 1, 0), new ItemStack(butterItem, 1, 0)
                     });
             //Loaded Potato
             ModLoader.addShapelessRecipe(new ItemStack(loadedpotatoItem, 1, 0), new Object[]
                     {
                         new ItemStack(butteredpotatoItem, 1, 0), new ItemStack(cheeseItem, 1, 0), new ItemStack(Item.porkCooked, 1)
                     });
             //Other Food Recipes
             ModLoader.addShapelessRecipe(new ItemStack(friedeggsItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.egg, 1), new ItemStack(onionItem, 1, 0), new ItemStack(tablesaltItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(friedpotatoesItem, 1, 0), new Object[]
                     {
                         new ItemStack(potatoItem, 1, 0), new ItemStack(onionItem, 1, 0), new ItemStack(tablesaltItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(saladItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceItem, 1, 0), new ItemStack(carrotItem, 1, 0), new ItemStack(cucumberItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(saladItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceItem, 1, 0), new ItemStack(carrotItem, 1, 0), new ItemStack(broccoliItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(saladItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceItem, 1, 0), new ItemStack(carrotItem, 1, 0), new ItemStack(turnipItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(saltedcookedfishItem, 1, 0), new Object[]
                     {
                         new ItemStack(tablesaltItem, 1, 0), new ItemStack(Item.fishCooked, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pumpkinpieItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1, 0), new ItemStack(Block.pumpkin, 1), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pizzaItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(cheeseItem, 1, 0), new ItemStack(Item.porkCooked, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spagettiItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bowlEmpty, 1), new ItemStack(pastaItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(Block.mushroomRed, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spagettiItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bowlEmpty, 1), new ItemStack(pastaItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(Block.mushroomBrown, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spagettiItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bowlEmpty, 1), new ItemStack(pastaItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(whitemushroomItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spagettiItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bowlEmpty, 1), new ItemStack(pastaItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(garlicItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(friedonionringsItem, 1, 0), new Object[]
                     {
                         new ItemStack(onionItem, 1, 0), new ItemStack(Item.bucketMilk, 1), new ItemStack(flourItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(friedonionringsItem, 1, 0), new Object[]
                     {
                         new ItemStack(onionItem, 1, 0), new ItemStack(milkbarrelItem, 1), new ItemStack(flourItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(applepieItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1, 0), new ItemStack(Item.appleRed, 1), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(applesauceItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bowlEmpty, 1), new ItemStack(Item.appleRed, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(grilledcheeseItem, 1, 0), new Object[]
                     {
                         new ItemStack(toastItem, 1, 0), new ItemStack(cheeseItem, 1, 0), new ItemStack(toastItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(bltsandwichItem, 1, 0), new Object[]
                     {
                         new ItemStack(toastItem, 1, 0), new ItemStack(lettuceItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(Item.porkCooked, 1), new ItemStack(toastItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(macncheeseItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheeseItem, 1, 0), new ItemStack(pastaItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fishsticksItem, 1, 0), new Object[]
                     {
                         new ItemStack(flourItem, 1, 0), new ItemStack(onionItem, 1, 0), new ItemStack(Item.fishCooked, 1), new ItemStack(butterItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mashedpotatoesItem, 1, 0), new Object[]
                     {
                         new ItemStack(butteredpotatoItem, 1, 0), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mashedpotatoesItem, 1, 0), new Object[]
                     {
                         new ItemStack(butteredpotatoItem, 1, 0), new ItemStack(waterbarrelItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fishsandwichItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bread, 1), new ItemStack(mayoItem, 1, 0), new ItemStack(Item.fishCooked, 1), new ItemStack(Item.bread, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cerealItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.wheat, 1, 0), new ItemStack(Item.bucketMilk, 1), new ItemStack(Item.bowlEmpty, 1), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cerealItem, 1, 0), new Object[]
                     {
                         new ItemStack(harvestwheatItem, 1, 0), new ItemStack(Item.bucketMilk, 1), new ItemStack(Item.bowlEmpty, 1), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cerealItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.wheat, 1, 0), new ItemStack(milkbarrelItem, 1), new ItemStack(Item.bowlEmpty, 1), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cerealItem, 1, 0), new Object[]
                     {
                         new ItemStack(harvestwheatItem, 1, 0), new ItemStack(milkbarrelItem, 1), new ItemStack(Item.bowlEmpty, 1), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(butteredpopcornItem, 1, 0), new Object[]
                     {
                         new ItemStack(popcornItem, 8, 0), new ItemStack(butterItem, 1, 0), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cornonthecobItem, 1, 0), new Object[]
                     {
                         new ItemStack(cornItem, 1, 0), new ItemStack(butterItem, 1, 0), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(saltedpeanutsItem, 1, 0), new Object[]
                     {
                         new ItemStack(tablesaltItem, 1, 0), new ItemStack(peanutItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pbnjsandwichItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bread, 1), new ItemStack(peanutbutterItem, 1, 0), new ItemStack(grapejellyItem, 1), new ItemStack(Item.bread, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pbnjsandwichItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bread, 1), new ItemStack(peanutbutterItem, 1, 0), new ItemStack(strawberryjamItem, 1), new ItemStack(Item.bread, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(tacoItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.porkCooked, 1), new ItemStack(tortillaItem, 1, 0), new ItemStack(lettuceItem, 1), new ItemStack(cheeseItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(nachosItem, 1, 0), new Object[]
                     {
                         new ItemStack(tortillaItem, 1, 0), new ItemStack(tomatoItem, 1), new ItemStack(cheeseItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(strawberrypieItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1, 0), new ItemStack(strawberryItem, 1), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(peanutbrittleItem, 1, 0), new Object[]
                     {
                         new ItemStack(peanutItem, 1, 0), new ItemStack(butterItem, 1), new ItemStack(powderedsugarItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolatebarItem, 1, 0), new Object[]
                     {
                         new ItemStack(cocoapowderItem, 1, 0), new ItemStack(Item.bucketMilk, 1), new ItemStack(powderedsugarItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolatebarItem, 1, 0), new Object[]
                     {
                         new ItemStack(cocoapowderItem, 1, 0), new ItemStack(milkbarrelItem, 1), new ItemStack(powderedsugarItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(trailmixItem, 1, 0), new Object[]
                     {
                         new ItemStack(saltedpeanutsItem, 1, 0), new ItemStack(raisinsItem, 1), new ItemStack(chocolatebarItem, 1), new ItemStack(driedappleslicesItem, 1),
                         new ItemStack(driedstrawberriesItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(icecreamItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bowlEmpty, 1), new ItemStack(Item.bucketMilk, 1), new ItemStack(Item.snowball, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(icecreamItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bowlEmpty, 1), new ItemStack(milkbarrelItem, 1), new ItemStack(Item.snowball, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolateicecreamItem, 1, 0), new Object[]
                     {
                         new ItemStack(icecreamItem, 1, 0), new ItemStack(chocolatebarItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(strawberryicecreamItem, 1, 0), new Object[]
                     {
                         new ItemStack(icecreamItem, 1, 0), new ItemStack(strawberryItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(picklesItem, 1, 0), new Object[]
                     {
                         new ItemStack(cucumberItem, 1, 0), new ItemStack(vinegarItem, 1, 0), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolatecoveredfruitItem, 1, 0), new Object[]
                     {
                         new ItemStack(chocolatebarItem, 1, 0), new ItemStack(raisinsItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolatecoveredfruitItem, 1, 0), new Object[]
                     {
                         new ItemStack(chocolatebarItem, 1, 0), new ItemStack(driedappleslicesItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolatecoveredfruitItem, 1, 0), new Object[]
                     {
                         new ItemStack(chocolatebarItem, 1, 0), new ItemStack(driedstrawberriesItem, 1, 0)
                     });
             // Soup Recipes
             ModLoader.addShapelessRecipe(new ItemStack(noodlesoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(pastaItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(hambonesoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.porkCooked, 1), new ItemStack(potatoItem, 1, 0), new ItemStack(tablesaltItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cheesesoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheeseItem, 1, 0), new ItemStack(butterItem, 1, 0), new ItemStack(flourItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(vegetablesoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(tomatoItem, 1, 0), new ItemStack(carrotItem, 1, 0), new ItemStack(potatoItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(onionsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(onionItem, 1, 0), new ItemStack(toastItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(peanutsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(peanutItem, 1, 0), new ItemStack(flourItem, 1, 0), new ItemStack(tablesaltItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cucumbersoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(cucumberItem, 1, 0), new ItemStack(vinegarItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(carrotsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(carrotItem, 1, 0), new ItemStack(butterItem, 1, 0), new ItemStack(flourItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pumpkinsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Block.pumpkin, 1), new ItemStack(carrotItem, 1, 0), new ItemStack(onionItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(wheatsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.wheat, 1), new ItemStack(tomatoItem, 1, 0), new ItemStack(onionItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(wheatsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(harvestwheatItem, 1), new ItemStack(tomatoItem, 1, 0), new ItemStack(onionItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(potatosoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(potatoItem, 1, 0), new ItemStack(cheeseItem, 1, 0), new ItemStack(flourItem, 1, 0), new ItemStack(stockItem, 1, 0)
                     }); // End Soup Recipes
             ModLoader.addShapelessRecipe(new ItemStack(oatmealItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.wheat, 1), new ItemStack(Item.sugar, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(oatmealItem, 1, 0), new Object[]
                     {
                         new ItemStack(harvestwheatItem, 1), new ItemStack(Item.sugar, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(oatmealItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.wheat, 1), new ItemStack(Item.sugar, 1), new ItemStack(waterbarrelItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(oatmealItem, 1, 0), new Object[]
                     {
                         new ItemStack(harvestwheatItem, 1), new ItemStack(Item.sugar, 1), new ItemStack(waterbarrelItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(friedpicklesItem, 1, 0), new Object[]
                     {
                         new ItemStack(picklesItem, 1, 0), new ItemStack(flourItem, 1, 0), new ItemStack(Item.bucketMilk, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(friedpicklesItem, 1, 0), new Object[]
                     {
                         new ItemStack(picklesItem, 1, 0), new ItemStack(flourItem, 1, 0), new ItemStack(milkbarrelItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(shepardpieItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.porkCooked, 1), new ItemStack(mashedpotatoesItem, 1, 0), new ItemStack(cornItem, 1, 0), new ItemStack(doughItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(strawberryiceItem, 1, 0), new Object[]
                     {
                         new ItemStack(strawberryItem, 1, 0), new ItemStack(Item.snowball, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sidesaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(saladItem, 1, 0), new ItemStack(Item.porkCooked, 1), new ItemStack(Item.egg, 1), new ItemStack(toastItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(breakfastsandwichItem, 1, 0), new Object[]
                     {
                         new ItemStack(toastItem, 1, 0), new ItemStack(Item.porkCooked, 1), new ItemStack(friedeggsItem, 1, 0), new ItemStack(toastItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(coleslawItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceItem, 1, 0), new ItemStack(carrotItem, 1, 0), new ItemStack(mayoItem, 1, 0),  new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(coleslawItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceItem, 1, 0), new ItemStack(turnipItem, 1, 0), new ItemStack(mayoItem, 1, 0),  new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fishlettucewrapItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceItem, 1, 0), new ItemStack(Item.fishCooked, 1), new ItemStack(onionItem, 1, 0), new ItemStack(tomatoItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fishtacoItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.fishCooked, 1), new ItemStack(tortillaItem, 1, 0), new ItemStack(lettuceItem, 1), new ItemStack(cheeseItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(porklettucewrapItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceItem, 1, 0), new ItemStack(Item.porkCooked, 1), new ItemStack(onionItem, 1, 0), new ItemStack(tomatoItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pastasaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(pastaItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(cucumberItem, 1, 0), new ItemStack(vinegarItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(potatosaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(potatoItem, 1, 0), new ItemStack(mayoItem, 1, 0), new ItemStack(onionItem, 1, 0), new ItemStack(tablesaltItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolatepeanutsItem, 1, 0), new Object[]
                     {
                         new ItemStack(chocolatebarItem, 1, 0), new ItemStack(saltedpeanutsItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pumpkinbreadItem, 1, 0), new Object[]
                     {
                         new ItemStack(Block.pumpkin, 1), new ItemStack(flourItem, 1),  new ItemStack(Item.bucketWater, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pumpkinbreadItem, 1, 0), new Object[]
                     {
                         new ItemStack(Block.pumpkin, 1), new ItemStack(flourItem, 1),  new ItemStack(waterbarrelItem, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sushiItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.fishRaw, 1, 0), new ItemStack(riceItem, 1),
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beansandriceItem, 1, 0), new Object[]
                     {
                         new ItemStack(beansItem, 1), new ItemStack(riceItem, 1), new ItemStack(bellpepperItem, 1), new ItemStack(Item.porkCooked, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chiliItem, 1, 0), new Object[]
                     {
                         new ItemStack(blackpepperItem, 1), new ItemStack(beansItem, 1), new ItemStack(Item.porkCooked, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chiliItem, 1, 0), new Object[]
                     {
                         new ItemStack(bellpepperItem, 1), new ItemStack(beansItem, 1), new ItemStack(Item.porkCooked, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chiliItem, 1, 0), new Object[]
                     {
                         new ItemStack(garlicItem, 1), new ItemStack(beansItem, 1), new ItemStack(Item.porkCooked, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(omeletItem, 1, 0), new Object[]
                     {
                         new ItemStack(scrambledeggsItem, 1), new ItemStack(Item.egg, 1, 0), new ItemStack(Item.porkCooked, 1), new ItemStack(Pamcombinedmod.onionItem, 1, 0)/*Onion*/
                     });
             ModLoader.addShapelessRecipe(new ItemStack(porkfriedriceItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.egg, 1, 0), new ItemStack(Item.porkCooked, 1), new ItemStack(riceItem, 1), new ItemStack(Pamcombinedmod.onionItem, 1, 0)/*Onion*/, new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(porkfriedriceItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.egg, 1, 0), new ItemStack(Item.porkCooked, 1), new ItemStack(riceItem, 1), new ItemStack(Pamcombinedmod.peasItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fiestariceItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(Pamcombinedmod.tomatoItem, 1, 0)/*Tomato*/, new ItemStack(bellpepperItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(stuffedpepperItem, 1, 0), new Object[]
                     {
                         new ItemStack(fiestariceItem, 1), new ItemStack(bellpepperItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beanburritoItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.tortillaItem, 1), new ItemStack(riceItem, 1), new ItemStack(beansItem, 1), new ItemStack(Pamcombinedmod.cheeseItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.friedeggsItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.egg, 1), new ItemStack(Pamcombinedmod.onionItem, 1, 0), new ItemStack(blackpepperItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.friedpotatoesItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.potatoItem, 1, 0), new ItemStack(Pamcombinedmod.onionItem, 1, 0), new ItemStack(blackpepperItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.butteredpotatoItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.bakedpotatoItem, 1, 0), new ItemStack(blackpepperItem, 1), new ItemStack(Pamcombinedmod.butterItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(supremepizzaItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pizzaItem, 1, 0), new ItemStack(Pamcombinedmod.onionItem, 1, 0), new ItemStack(bellpepperItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(supremepizzaItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.veggiepizzaItem, 1, 0), new ItemStack(Pamcombinedmod.onionItem, 1, 0), new ItemStack(bellpepperItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(ricesoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(Pamcombinedmod.stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(veggiestirfryItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(carrotItem, 1), new ItemStack(Block.mushroomRed, 1), new ItemStack(Pamcombinedmod.beansItem, 1), new ItemStack(lettuceItem, 1), new ItemStack(onionItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(veggiestirfryItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(carrotItem, 1), new ItemStack(Block.mushroomBrown, 1), new ItemStack(Pamcombinedmod.beansItem, 1), new ItemStack(lettuceItem, 1), new ItemStack(onionItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(veggiestirfryItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(carrotItem, 1), new ItemStack(whitemushroomItem, 1), new ItemStack(Pamcombinedmod.beansItem, 1), new ItemStack(lettuceItem, 1), new ItemStack(onionItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(veggiestirfryItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(carrotItem, 1), new ItemStack(garlicItem, 1), new ItemStack(Pamcombinedmod.beansItem, 1), new ItemStack(lettuceItem, 1), new ItemStack(onionItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(carrotpilafItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(Pamcombinedmod.carrotItem, 1), new ItemStack(Pamcombinedmod.raisinsItem, 1, 0), new ItemStack(Pamcombinedmod.peanutItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cornricemedleyItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(Pamcombinedmod.cornItem, 1), new ItemStack(Pamcombinedmod.butterItem, 1, 0), new ItemStack(Pamcombinedmod.onionItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cornricemedleyItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(Pamcombinedmod.cornItem, 1), new ItemStack(Pamcombinedmod.butterItem, 1, 0), new ItemStack(Pamcombinedmod.peasItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mushroomrisottoItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(Block.mushroomRed, 1), new ItemStack(Pamcombinedmod.tablesaltItem, 1, 0), new ItemStack(blackpepperItem, 1), new ItemStack(Pamcombinedmod.stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mushroomrisottoItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(Block.mushroomBrown, 1), new ItemStack(Pamcombinedmod.tablesaltItem, 1, 0), new ItemStack(blackpepperItem, 1), new ItemStack(Pamcombinedmod.stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mushroomrisottoItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1), new ItemStack(whitemushroomItem, 1), new ItemStack(Pamcombinedmod.tablesaltItem, 1, 0), new ItemStack(blackpepperItem, 1), new ItemStack(Pamcombinedmod.stockItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(refriedbeansItem, 1, 0), new Object[]
                     {
                         new ItemStack(beansItem, 1), new ItemStack(Pamcombinedmod.onionItem, 1, 0)/*Onion*/, new ItemStack(Pamcombinedmod.butterItem, 1, 0), new ItemStack(Item.bowlEmpty, 1)
                     });
             //ForageCraft Ingrediant Recipes
             ModLoader.addShapelessRecipe(new ItemStack(batterItem, 1, 0), new Object[]
                     {
                         new ItemStack(flourItem, 1), new ItemStack(Item.bucketMilk, 1), new ItemStack(Item.egg, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(batterItem, 1, 0), new Object[]
                     {
                         new ItemStack(flourItem, 1), new ItemStack(milkbarrelItem, 1), new ItemStack(Item.egg, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(syrupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.glassBottle, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.sugar, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(berrysyrupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.glassBottle, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.sugar, 1, 0), new ItemStack(blueberryItem, 1), new ItemStack(blueberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(raspberryItem, 1), new ItemStack(raspberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(syrupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.glassBottle, 1), new ItemStack(waterbarrelItem, 1), new ItemStack(Item.sugar, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(berrysyrupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.glassBottle, 1), new ItemStack(waterbarrelItem, 1), new ItemStack(Item.sugar, 1, 0), new ItemStack(blueberryItem, 1), new ItemStack(blueberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(raspberryItem, 1), new ItemStack(raspberryItem, 1)
                     });
             //ForageCraft Food Recipes
             ModLoader.addRecipe(new ItemStack(wafflesItem, 1, 0), new Object[]
                     {
                         "# *", " O ", '#', batterItem, 'O', butterItem, '*', syrupItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fancywafflesItem, 1, 0), new Object[]
                     {
                         new ItemStack(wafflesItem, 1), new ItemStack(berrysyrupItem, 1), new ItemStack(bananaItem, 1), new ItemStack(cherryItem, 1), new ItemStack(peachItem, 1)
                     });
             ModLoader.addRecipe(new ItemStack(pancakesItem, 1, 0), new Object[]
                     {
                         " # ", " * ", " O ", 'O', batterItem, '*', butterItem, '#', syrupItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fancypancakesItem, 1, 0), new Object[]
                     {
                         new ItemStack(pancakesItem, 1), new ItemStack(berrysyrupItem, 1), new ItemStack(bananaItem, 1), new ItemStack(cherryItem, 1), new ItemStack(peachItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(frenchtoastItem, 1, 0), new Object[]
                     {
                         new ItemStack(syrupItem, 1), new ItemStack(Item.bread, 1), new ItemStack(Item.egg, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(berrysaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(saladItem, 1),  new ItemStack(blueberryItem, 1), new ItemStack(blueberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(raspberryItem, 1), new ItemStack(raspberryItem, 1), new ItemStack(saltedpeanutsItem, 1, 0)

                     });
             ModLoader.addRecipe(new ItemStack(blueberrymuffinsItem, 1, 0), new Object[]
                     {
                         "#", "O", "S", '#', blueberryItem, 'O', doughItem, 'S', Item.sugar
                     });
             ModLoader.addRecipe(new ItemStack(raspberrytartItem, 1, 0), new Object[]
                     {
                         "#", "O", "S", '#', raspberryItem, 'O', doughItem, 'S', Item.sugar
                     });
             ModLoader.addRecipe(new ItemStack(blackberrycobblerItem, 1, 0), new Object[]
                     {
                         "#", "O", "S", '#', blackberryItem, 'O', doughItem, 'S', Item.sugar
                     });
             ModLoader.addRecipe(new ItemStack(peachcobblerItem, 1, 0), new Object[]
                     {
                         "#", "O", "S", '#', peachItem, 'O', doughItem, 'S', Item.sugar
                     });
             ModLoader.addRecipe(new ItemStack(cherrypieItem, 1, 0), new Object[]
                     {
                         "#", "O", "S", '#', cherryItem, 'O', doughItem, 'S', Item.sugar
                     });
             ModLoader.addRecipe(new ItemStack(lemonpieItem, 1, 0), new Object[]
                     {
                         "#", "O", "S", '#', lemonItem, 'O', doughItem, 'S', Item.sugar
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.bananasplitItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.bananaItem, 1), new ItemStack(Pamcombinedmod.cherryItem, 1), new ItemStack(Pamcombinedmod.icecreamItem, 1), new ItemStack(Pamcombinedmod.strawberryicecreamItem, 1), new ItemStack(Pamcombinedmod.chocolateicecreamItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fruitsaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(blueberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(raspberryItem, 1), new ItemStack(cherryItem, 1), new ItemStack(peachItem, 1), new ItemStack(Item.appleRed), new ItemStack(strawberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fruitsaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(blueberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(raspberryItem, 1), new ItemStack(cherryItem, 1), new ItemStack(pineappleItem, 1), new ItemStack(Item.appleRed), new ItemStack(strawberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fruitsaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(blueberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(raspberryItem, 1), new ItemStack(cherryItem, 1), new ItemStack(peachItem, 1), new ItemStack(pearItem, 1), new ItemStack(strawberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(fruitsaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(blueberryItem, 1), new ItemStack(blackberryItem, 1), new ItemStack(raspberryItem, 1), new ItemStack(cherryItem, 1), new ItemStack(pineappleItem, 1), new ItemStack(pearItem, 1), new ItemStack(strawberryItem, 1)
                     });
             //Fruit Juice Recipes
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(cherryItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(Item.appleRed, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(peachItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(blueberryItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(blackberryItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(raspberryItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(kiwiItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(strawberryItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(orangeItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(limeItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(mangoItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(pearItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(plumItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(pineappleItem, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(fruitjuiceItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(Item.melon, 1), new ItemStack(Item.melon, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(lemonaideItem, 1, 0), new Object[] //Works
             {
                 new ItemStack(Item.glassBottle, 1), new ItemStack(lemonItem, 1), new ItemStack(Item.sugar, 1)
             });
             ModLoader.addShapelessRecipe(new ItemStack(eggplantparmItem, 1, 0), new Object[]
                     {
                         new ItemStack(eggplantItem, 1), new ItemStack(tomatoItem, 1), new ItemStack(pastaItem, 1), new ItemStack(cheeseItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(stuffedeggplantItem, 1, 0), new Object[]
                     {
                         new ItemStack(eggplantItem, 1), new ItemStack(onionItem, 1), new ItemStack(bellpepperItem, 1), new ItemStack(butterItem, 1), new ItemStack(Item.egg, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(stuffedeggplantItem, 1, 0), new Object[]
                     {
                         new ItemStack(eggplantItem, 1), new ItemStack(garlicItem, 1), new ItemStack(bellpepperItem, 1), new ItemStack(butterItem, 1), new ItemStack(Item.egg, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(raspberryicedteaItem, 1, 0), new Object[]
                     {
                         new ItemStack(teaItem, 1), new ItemStack(raspberryItem, 1, 0), new ItemStack(Item.snowball, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chaiteaItem, 1, 0), new Object[]
                     {
                         new ItemStack(teaItem, 1), new ItemStack(cinnamonspiceItem, 1, 0), new ItemStack(blackpepperItem, 1, 0), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mochaicecreamItem, 1, 0), new Object[]
                     {
                         new ItemStack(coffeeItem, 1, 0), new ItemStack(icecreamItem, 1, 0), new ItemStack(chocolatebarItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(espressoItem, 1, 0), new Object[]
                     {
                         new ItemStack(groundcoffeeItem, 1), new ItemStack(groundcoffeeItem, 1, 0), new ItemStack(groundcoffeeItem, 1, 0), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pickledbeetsItem, 1, 0), new Object[]
                     {
                         new ItemStack(beetItem, 1, 0), new ItemStack(vinegarItem, 1, 0), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beetsaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(beetItem, 1), new ItemStack(lettuceItem, 1), new ItemStack(vinegarItem, 1), new ItemStack(cheeseItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beetsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(beetItem, 1), new ItemStack(onionItem, 1), new ItemStack(Item.bucketMilk, 1), new ItemStack(blackpepperItem, 1), new ItemStack(stockItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beetsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(beetItem, 1), new ItemStack(onionItem, 1), new ItemStack(milkbarrelItem, 1), new ItemStack(blackpepperItem, 1), new ItemStack(stockItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(broccolimacItem, 1, 0), new Object[]
                     {
                         new ItemStack(broccoliItem, 1), new ItemStack(macncheeseItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(broccolindipItem, 1, 0), new Object[]
                     {
                         new ItemStack(broccoliItem, 1), new ItemStack(onionItem, 1), new ItemStack(Item.bucketMilk, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(broccolindipItem, 1, 0), new Object[]
                     {
                         new ItemStack(broccoliItem, 1), new ItemStack(onionItem, 1), new ItemStack(milkbarrelItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(creamedbroccolisoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(broccoliItem, 1), new ItemStack(carrotItem, 1), new ItemStack(flourItem, 1), new ItemStack(blackpepperItem, 1), new ItemStack(stockItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sweetpotatopieItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1, 0), new ItemStack(sweetpotatoItem, 1), new ItemStack(cinnamonspiceItem, 1), new ItemStack(marshmellowsItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(candiedsweetpotatoesItem, 1, 0), new Object[]
                     {
                         new ItemStack(sweetpotatoItem, 1), new ItemStack(cinnamonspiceItem, 1), new ItemStack(powderedsugarItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(marshmellowsItem, 1, 0), new Object[]
                     {
                         new ItemStack(powderedsugarItem, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.egg, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(marshmellowsItem, 1, 0), new Object[]
                     {
                         new ItemStack(powderedsugarItem, 1), new ItemStack(waterbarrelItem, 1), new ItemStack(Item.egg, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(splitpeasoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(peasItem, 1), new ItemStack(carrotItem, 1), new ItemStack(Item.porkCooked, 1), new ItemStack(blackpepperItem, 1), new ItemStack(stockItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pineapplehamItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.sugar, 1), new ItemStack(Item.porkCooked, 1), new ItemStack(pineappleItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(turnipsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(turnipItem, 1), new ItemStack(Block.pumpkin, 1), new ItemStack(butterItem, 1), new ItemStack(stockItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(banananutbreadItem, 1, 0), new Object[]
                     {
                         new ItemStack(bananaItem, 1), new ItemStack(flourItem, 1),  new ItemStack(walnutItem, 1),  new ItemStack(Item.bucketMilk, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(banananutbreadItem, 1, 0), new Object[]
                     {
                         new ItemStack(bananaItem, 1), new ItemStack(flourItem, 1),  new ItemStack(walnutItem, 1),  new ItemStack(milkbarrelItem, 1), new ItemStack(tablesaltItem, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(breadedchickenItem, 1, 0), new Object[]
                     {
                         new ItemStack(flourItem, 1),  new ItemStack(Item.chickenRaw, 1), new ItemStack(Item.egg, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chickenparmItem, 1, 0), new Object[]
                     {
                         new ItemStack(breadedchickenItem, 1),  new ItemStack(tomatoItem, 1), new ItemStack(pastaItem, 1), new ItemStack(cheeseItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chickennoodlesoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(noodlesoupItem, 1), new ItemStack(carrotItem, 1), new ItemStack(blackpepperItem, 1), new ItemStack(Item.chickenCooked, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chickensandwichItem, 1, 0), new Object[]
                     {
                         new ItemStack(toastItem, 1), new ItemStack(mayoItem, 1, 0), new ItemStack(lettuceItem, 1, 0), new ItemStack(breadedchickenItem, 1), new ItemStack(toastItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(hamburgerItem, 1, 0), new Object[]
                     {
                         new ItemStack(toastItem, 1), new ItemStack(lettuceItem, 1, 0), new ItemStack(tomatoItem, 1, 0), new ItemStack(Item.beefCooked, 1), new ItemStack(toastItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cheeseburgerItem, 1, 0), new Object[]
                     {
                         new ItemStack(hamburgerItem, 1), new ItemStack(cheeseItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(baconcheeseburgerItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheeseburgerItem, 1), new ItemStack(Item.porkCooked, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spagettiandmeatballsItem, 1, 0), new Object[]
                     {
                         new ItemStack(spagettiItem, 1), new ItemStack(Item.beefCooked, 1), new ItemStack(Item.bread, 1), new ItemStack(Item.egg, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(curryriceItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1),  new ItemStack(bellpepperItem, 1), new ItemStack(blackpepperItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(curryriceItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1),  new ItemStack(garlicItem, 1), new ItemStack(blackpepperItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(donutItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1),  new ItemStack(oliveoilItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolatedonutItem, 1, 0), new Object[]
                     {
                         new ItemStack(donutItem, 1),  new ItemStack(chocolatebarItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(powdereddonutItem, 1, 0), new Object[]
                     {
                         new ItemStack(donutItem, 1),  new ItemStack(powderedsugarItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(jellydonutItem, 1, 0), new Object[]
                     {
                         new ItemStack(donutItem, 1),  new ItemStack(grapejellyItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(jellydonutItem, 1, 0), new Object[]
                     {
                         new ItemStack(donutItem, 1),  new ItemStack(strawberryjamItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(frosteddonutItem, 1, 0), new Object[]
                     {
                         new ItemStack(donutItem, 1),  new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.dyePowder, 1, 2)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spidereyesoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.spiderEye, 1), new ItemStack(Item.spiderEye, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(zombiejerkyItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.rottenFlesh, 1), new ItemStack(tablesaltItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(gingerbreadItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.egg, 1), new ItemStack(flourItem, 1), new ItemStack(butterItem, 1), new ItemStack(gingerItem, 1), new ItemStack(cinnamonspiceItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(gingersnapsItem, 1, 0), new Object[]
                     {
                         new ItemStack(gingerItem, 1), new ItemStack(Item.sugar, 1), new ItemStack(flourItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(candiedgingerItem, 1, 0), new Object[]
                     {
                         new ItemStack(gingerItem, 1), new ItemStack(Item.sugar, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(saltedsunflowerseedsItem, 1, 0), new Object[]
                     {
                         new ItemStack(sunflowerseedsItem, 1), new ItemStack(tablesaltItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sunflowerwheatrollsItem, 1, 0), new Object[]
                     {
                         new ItemStack(flourItem, 1), new ItemStack(sunflowerseedsItem, 1), new ItemStack(tablesaltItem, 1), new ItemStack(oliveoilItem, 1), new ItemStack(Item.egg, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sunflowerbroccolisaladItem, 1, 0), new Object[]
                     {
                         new ItemStack(sunflowerseedsItem, 1), new ItemStack(broccoliItem, 1), new ItemStack(mayoItem, 1), new ItemStack(Item.sugar, 1), new ItemStack(Item.porkCooked, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(softpretzelItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1), new ItemStack(butterItem, 1), new ItemStack(tablesaltItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(softpretzelandmustardItem, 1, 0), new Object[]
                     {
                         new ItemStack(softpretzelItem, 1), new ItemStack(mustardItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardporkItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.porkCooked, 1), new ItemStack(mustardItem, 1), new ItemStack(tablesaltItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardporkItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.porkCooked, 1), new ItemStack(mustardItem, 1), new ItemStack(blackpepperItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardporkItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.porkCooked, 1), new ItemStack(mustardItem, 1), new ItemStack(garlicItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardgreensItem, 1, 0), new Object[]
                     {
                         new ItemStack(mustardItem, 1), new ItemStack(lettuceItem, 1), new ItemStack(oliveoilItem, 1), new ItemStack(onionItem, 1), new ItemStack(blackpepperItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardgreensItem, 1, 0), new Object[]
                     {
                         new ItemStack(mustardItem, 1), new ItemStack(broccoliItem, 1), new ItemStack(oliveoilItem, 1), new ItemStack(onionItem, 1), new ItemStack(blackpepperItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardgreensItem, 1, 0), new Object[]
                     {
                         new ItemStack(mustardItem, 1), new ItemStack(peasItem, 1), new ItemStack(oliveoilItem, 1), new ItemStack(onionItem, 1), new ItemStack(blackpepperItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardgreensItem, 1, 0), new Object[]
                     {
                         new ItemStack(mustardItem, 1), new ItemStack(lettuceItem, 1), new ItemStack(oliveoilItem, 1), new ItemStack(onionItem, 1), new ItemStack(garlicItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardgreensItem, 1, 0), new Object[]
                     {
                         new ItemStack(mustardItem, 1), new ItemStack(broccoliItem, 1), new ItemStack(oliveoilItem, 1), new ItemStack(onionItem, 1), new ItemStack(garlicItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spicymustardgreensItem, 1, 0), new Object[]
                     {
                         new ItemStack(mustardItem, 1), new ItemStack(peasItem, 1), new ItemStack(oliveoilItem, 1), new ItemStack(onionItem, 1), new ItemStack(garlicItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(veggiepizzaItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1), new ItemStack(tomatoItem, 1), new ItemStack(lettuceItem, 1), new ItemStack(onionItem, 1), new ItemStack(garlicItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1), new ItemStack(Item.bucketMilk, 1), new ItemStack(Item.sugar, 1), new ItemStack(cheeseItem, 1), new ItemStack(cinnamonspiceItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(doughItem, 1), new ItemStack(milkbarrelItem, 1), new ItemStack(Item.sugar, 1), new ItemStack(cheeseItem, 1), new ItemStack(cinnamonspiceItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(blueberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(blackberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(raspberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(kiwiItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(strawberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(grapeItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(Item.appleRed, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(bananaItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(cherryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(coconutItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(lemonItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(peachItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(walnutItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(peanutItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(toppingcheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(honeyItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chocolatecheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(chocolatebarItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pumpkincheesecakeItem, 1, 0), new Object[]
                     {
                         new ItemStack(cheesecakeItem, 1), new ItemStack(Block.pumpkin, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cafeconlecheItem, 1, 0), new Object[]
                     {
                         new ItemStack(espressoItem, 1), new ItemStack(Item.bucketMilk, 1), new ItemStack(cinnamonspiceItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cafeconlecheItem, 1, 0), new Object[]
                     {
                         new ItemStack(espressoItem, 1), new ItemStack(milkbarrelItem, 1), new ItemStack(cinnamonspiceItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(garlicmashedpotatoesItem, 1, 0), new Object[]
                     {
                         new ItemStack(mashedpotatoesItem, 1), new ItemStack(garlicItem, 1), new ItemStack(blackpepperItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(garlicmashedpotatoesItem, 1, 0), new Object[]
                     {
                         new ItemStack(mashedpotatoesItem, 1), new ItemStack(garlicItem, 1), new ItemStack(tablesaltItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(garlicchickenItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.chickenCooked, 1), new ItemStack(oliveoilItem, 1), new ItemStack(garlicItem, 1), new ItemStack(garlicItem, 1), new ItemStack(garlicItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(garlictoastItem, 1, 0), new Object[]
                     {
                         new ItemStack(toastItem, 1), new ItemStack(garlicItem, 1), new ItemStack(butterItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.bowlSoup, 1, 0), new Object[]
                     {
                         new ItemStack(Block.mushroomRed, 1), new ItemStack(whitemushroomItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.bowlSoup, 1, 0), new Object[]
                     {
                         new ItemStack(Block.mushroomBrown, 1), new ItemStack(whitemushroomItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Item.cookie, 1, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(harvestwheatItem, 1), new ItemStack(harvestwheatItem, 1)
                     });
             ModLoader.addRecipe(new ItemStack(Item.cake, 1), new Object[]
                     {
                         "AAA", "BEB", "CCC", 'A', Item.bucketMilk, 'B', Item.sugar, 'C', harvestwheatItem, 'E',
                         Item.egg
                     });
             ModLoader.addRecipe(new ItemStack(Item.cake, 1), new Object[]
                     {
                         "AAA", "BEB", "CCC", 'A', milkbarrelItem, 'B', Item.sugar, 'C', harvestwheatItem, 'E',
                         Item.egg
                     });
             ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
             //Seed Soup Recipes
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.seeds, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.pumpkinSeeds, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.melonSeeds, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(tomatoseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(potatoseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(onionseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(carrotseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(cornseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(strawberryseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(grapeseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(peanutseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(cucumberseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(beansseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(bellpepperseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(eggplantseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(teaseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(coffeeseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(beetseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(broccoliseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(sweetpotatoseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(peasseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(pineappleseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(turnipseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(gingerseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(sunflowerseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(mustardseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(garlicseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(rottenseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(whitemushroomseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(harvestwheatseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(cottonseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(candleberryseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(radishseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(celeryseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(zucchiniseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(chilipepperseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(cantaloupeseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(asparagusseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(cranberryseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(seedsoupItem, 1, 0), new Object[]
                     {
                         new ItemStack(spiceleafseedItem, 1), new ItemStack(Item.bowlEmpty, 1)
                     });
             //Crops to Seed Recipe
             ModLoader.addShapelessRecipe(new ItemStack(tomatoseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(tomatoItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(potatoseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(potatoItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(lettuceseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(lettuceItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(onionseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(onionItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(carrotseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(carrotItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cornseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(cornItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(peanutseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(peanutItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cucumberseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(cucumberItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(riceseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(riceItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beansseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(beansItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(bellpepperseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(bellpepperItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(eggplantseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(eggplantItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(teaseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(tealeafItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(coffeeseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(coffeebeanItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beetseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(beetItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(broccoliseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(broccoliItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sweetpotatoseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(sweetpotatoItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(peasseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(peasItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pineappleseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(pineappleItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(turnipseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(turnipItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(gingerseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(gingerItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(blueberryseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(blueberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(blackberryseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(blackberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(raspberryseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(raspberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(kiwiseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(kiwiItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(strawberryseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(strawberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(grapeseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(grapeItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sunflowerseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(sunflowerseedsItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mustardseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(mustardseedsItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(garlicseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(garlicItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(rottenseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.rottenFlesh, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(whitemushroomseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(whitemushroomItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(harvestwheatseedItem, 2, 0), new Object[]
                     {
                         new ItemStack(harvestwheatItem, 1), new ItemStack(harvestwheatItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cottonseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(cottonItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(candleberryseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(candleberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(radishseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(radishItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(celeryseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(celeryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(zucchiniseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(zucchiniItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chilipepperseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(chilipepperItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cantaloupeseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(cantaloupeItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(asparagusseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(asparagusItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cranberryseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(cranberryItem, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spiceleafseedItem, 1, 0), new Object[]
                     {
                         new ItemStack(spiceleafItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(tomatoseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', tomatoseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(tomatoseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(tomatoseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(tomatoseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', tomatoseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(tomatoseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(tomatoseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(potatoseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', potatoseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(potatoseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(potatoseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(potatoseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', potatoseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(potatoseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(potatoseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(lettuceseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', lettuceseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(lettuceseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(lettuceseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(lettuceseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', lettuceseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(lettuceseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(lettuceseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(onionseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', onionseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(onionseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(onionseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(onionseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', onionseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(onionseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(onionseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(carrotseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', carrotseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(carrotseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(carrotseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(carrotseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', carrotseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(carrotseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(carrotseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(cornseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cornseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cornseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(cornseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(cornseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cornseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cornseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(cornseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(peanutseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', peanutseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(peanutseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(peanutseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(peanutseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', peanutseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(peanutseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(peanutseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(cucumberseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cucumberseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cucumberseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(cucumberseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(cucumberseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cucumberseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cucumberseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(cucumberseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(riceseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', riceseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(riceseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(riceseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(riceseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', riceseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(riceseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(riceseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(beansseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', beansseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beansseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(beansseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(beansseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', beansseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beansseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(beansseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(bellpepperseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', bellpepperseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(bellpepperseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(bellpepperseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(bellpepperseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', bellpepperseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(bellpepperseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(bellpepperseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(eggplantseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', eggplantseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(eggplantseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(eggplantseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(eggplantseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', eggplantseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(eggplantseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(eggplantseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(teaseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', teaseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(teaseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(teaseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(teaseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', teaseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(teaseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(teaseedboxItem, 1)
                     });
     //Seed Packets
             ModLoader.addRecipe(new ItemStack(coffeeseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', coffeeseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(coffeeseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(coffeeseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(coffeeseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', coffeeseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(coffeeseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(coffeeseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(beetseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', beetseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beetseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(beetseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(beetseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', beetseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(beetseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(beetseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(broccoliseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', broccoliseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(broccoliseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(broccoliseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(broccoliseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', broccoliseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(broccoliseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(broccoliseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(sweetpotatoseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', sweetpotatoseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sweetpotatoseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(sweetpotatoseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(sweetpotatoseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', sweetpotatoseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sweetpotatoseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(sweetpotatoseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(peasseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', peasseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(peasseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(peasseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(peasseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', peasseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(peasseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(peasseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(pineappleseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', pineappleseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pineappleseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(pineappleseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(pineappleseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', pineappleseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(pineappleseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(pineappleseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(turnipseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', turnipseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(turnipseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(turnipseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(turnipseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', turnipseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(turnipseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(turnipseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(gingerseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', gingerseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(gingerseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(gingerseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(gingerseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', gingerseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(gingerseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(gingerseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(blueberryseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', blueberryseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(blueberryseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(blueberryseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(blueberryseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', blueberryseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(blueberryseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(blueberryseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(blackberryseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', blackberryseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(blackberryseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(blackberryseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(blackberryseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', blackberryseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(blackberryseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(blackberryseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(raspberryseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', raspberryseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(raspberryseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(raspberryseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(raspberryseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', raspberryseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(raspberryseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(raspberryseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(kiwiseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', kiwiseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(kiwiseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(kiwiseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(kiwiseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', kiwiseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(kiwiseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(kiwiseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(strawberryseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', strawberryseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(strawberryseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(strawberryseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(strawberryseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', strawberryseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(strawberryseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(strawberryseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(grapeseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', grapeseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(grapeseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(grapeseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(grapeseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', grapeseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(grapeseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(grapeseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(sunflowerseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', sunflowerseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sunflowerseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(sunflowerseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(sunflowerseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', sunflowerseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(sunflowerseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(sunflowerseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(mustardseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', mustardseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mustardseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(mustardseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(mustardseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', mustardseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(mustardseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(mustardseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(garlicseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', garlicseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(garlicseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(garlicseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(garlicseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', garlicseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(garlicseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(garlicseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(rottenseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', rottenseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(rottenseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(rottenseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(rottenseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', rottenseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(rottenseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(rottenseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(whitemushroomseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', whitemushroomseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(whitemushroomseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(whitemushroomseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(whitemushroomseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', whitemushroomseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(whitemushroomseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(whitemushroomseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(harvestwheatseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', harvestwheatseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(harvestwheatseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(harvestwheatseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(harvestwheatseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', harvestwheatseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(harvestwheatseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(harvestwheatseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(cottonseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cottonseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cottonseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(cottonseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(cottonseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cottonseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cottonseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(cottonseedboxItem, 1)
                     });
             //Seed Packets
             ModLoader.addRecipe(new ItemStack(candleberryseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', candleberryseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(candleberryseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(candleberryseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(candleberryseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', candleberryseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(candleberryseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(candleberryseedboxItem, 1)
                     });
           //Seed Packets
             ModLoader.addRecipe(new ItemStack(radishseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', radishseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(radishseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(radishseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(radishseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', radishseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(radishseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(radishseedboxItem, 1)
                     });
           //Seed Packets
             ModLoader.addRecipe(new ItemStack(celeryseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', celeryseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(celeryseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(celeryseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(celeryseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', celeryseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(celeryseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(celeryseedboxItem, 1)
                     });
           //Seed Packets
             ModLoader.addRecipe(new ItemStack(zucchiniseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', zucchiniseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(zucchiniseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(zucchiniseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(zucchiniseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', zucchiniseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(zucchiniseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(zucchiniseedboxItem, 1)
                     });
           //Seed Packets
             ModLoader.addRecipe(new ItemStack(chilipepperseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', chilipepperseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chilipepperseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(chilipepperseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(chilipepperseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', chilipepperseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(chilipepperseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(chilipepperseedboxItem, 1)
                     });
           //Seed Packets
             ModLoader.addRecipe(new ItemStack(cantaloupeseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cantaloupeseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cantaloupeseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(cantaloupeseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(cantaloupeseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cantaloupeseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cantaloupeseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(cantaloupeseedboxItem, 1)
                     });
           //Seed Packets
             ModLoader.addRecipe(new ItemStack(asparagusseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', asparagusseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(asparagusseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(asparagusseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(asparagusseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', asparagusseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(asparagusseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(asparagusseedboxItem, 1)
                     });
           //Seed Packets
             ModLoader.addRecipe(new ItemStack(cranberryseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cranberryseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cranberryseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(cranberryseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(cranberryseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', cranberryseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(cranberryseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(cranberryseedboxItem, 1)
                     });
           //Seed Packets
             ModLoader.addRecipe(new ItemStack(spiceleafseedpacketItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', spiceleafseedItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spiceleafseedItem, 8, 0), new Object[]
                     {
                         new ItemStack(spiceleafseedpacketItem, 1)
                     });
             //Seed Boxes
             ModLoader.addRecipe(new ItemStack(spiceleafseedboxItem, 1, 0), new Object[]
                     {
                         "###", "# #", "###", '#', spiceleafseedpacketItem
                     });
             ModLoader.addShapelessRecipe(new ItemStack(spiceleafseedpacketItem, 8, 0), new Object[]
                     {
                         new ItemStack(spiceleafseedboxItem, 1)
                     });
             //Tree Sapling Recipes
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamSapling, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.cherryItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamSapling, 1, 1), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.walnutItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamSapling, 1, 2), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pearItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamSapling, 1, 3), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.plumItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamSapling, 1, 4), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.avacadoItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamSapling, 1, 5), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.nutmegItem), new ItemStack(Block.sapling, 1, 0)
                     });
             
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.bananaItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 1), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.coconutItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 2), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.lemonItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 3), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.orangeItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 4), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.peachItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 5), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.limeItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 6), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.mangoItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 7), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.oliveItem), new ItemStack(Block.sapling, 1, 0)
                     });

             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 8), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pomegranateItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 9), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.vanillabeanItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 10), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.peppercornItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 11), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.papayaItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 12), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.starfruitItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamwarmSapling, 1, 13), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.cinnamonItem), new ItemStack(Block.sapling, 1, 0)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.barrelItem, 6, 0), new Object[]
                     {
                         "# #", "# #", "###", '#', Block.planks
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.milkbarrelItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bucketMilk), new ItemStack(Pamcombinedmod.barrelItem)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.waterbarrelItem, 1, 0), new Object[]
                     {
                         new ItemStack(Item.bucketWater), new ItemStack(Pamcombinedmod.barrelItem)
                     });
             ModLoader.addRecipe(new ItemStack(Item.silk, 1, 0), new Object[]
                     {
                         " #", "# ", '#', cottonItem
                     });
             //Woven Cloth Recipe
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.wovenclothItem, 1), new Object[]
                     {
                         " #", "# ", '#', Item.silk
                     });
             //Woven Cloth into Wool Recipe
             ModLoader.addRecipe(new ItemStack(Block.cloth, 1), new Object[]
                     {
                         " #", "# ", '#', wovenclothItem
                     });
             //Cotton Armor Recipes
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cottonHelm, 1), new Object[]
                     {
                         "XXX", "X X", "   ", 'X', wovenclothItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cottonHelm, 1), new Object[]
                     {
                         "   ", "XXX", "X X", 'X', wovenclothItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cottonChest, 1), new Object[]
                     {
                         "X X", "XXX", "XXX", 'X', wovenclothItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cottonLegs, 1), new Object[]
                     {
                         "XXX", "X X", "X X", 'X', wovenclothItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cottonBoots, 1), new Object[]
                     {
                         "X X", "X X", "   ", 'X', wovenclothItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cottonBoots, 1), new Object[]
                     {
                         "   ", "X X", "X X", 'X', wovenclothItem
                     });
             //Pressed Wax
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pressedwaxItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.beeswaxItem), new ItemStack(Pamcombinedmod.beeswaxItem), new ItemStack(Pamcombinedmod.beeswaxItem), new ItemStack(Pamcombinedmod.beeswaxItem)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pressedwaxItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.candleberryItem), new ItemStack(Pamcombinedmod.candleberryItem), new ItemStack(Pamcombinedmod.candleberryItem), new ItemStack(Pamcombinedmod.candleberryItem)
                     });
             //Hardened Leather Recipe
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.hardenedleatherItem, 1, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pressedwaxItem, 1), new ItemStack(Item.leather, 1)
                     });
             //Hardened Leather Armor Recipes
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.hardenedleatherHelm, 1), new Object[]
                     {
                         "XXX", "X X", "   ", 'X', hardenedleatherItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.hardenedleatherHelm, 1), new Object[]
                     {
                         "   ", "XXX", "X X", 'X', hardenedleatherItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.hardenedleatherChest, 1), new Object[]
                     {
                         "X X", "XXX", "XXX", 'X', hardenedleatherItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.hardenedleatherLegs, 1), new Object[]
                     {
                         "XXX", "X X", "X X", 'X', hardenedleatherItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.hardenedleatherBoots, 1), new Object[]
                     {
                         "X X", "X X", "   ", 'X', hardenedleatherItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.hardenedleatherBoots, 1), new Object[]
                     {
                         "   ", "X X", "X X", 'X', hardenedleatherItem
                     });
             //Wax Items
             ModLoader.addRecipe(new ItemStack(Block.torchWood, 4), new Object[]
                     {
                         " X ", " # ", 'X', Item.silk, '#', pressedwaxItem
                     });
             
             
             
             ModLoader.addShapelessRecipe(new ItemStack(Item.seeds, 1, 0), new Object[]
                     {
             			new ItemStack(Pamcombinedmod.harvestwheatseedItem, 1, 0)
                     });	
             
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.harvestwheatseedItem, 1, 0), new Object[]
                     {
             			new ItemStack(Item.seeds, 1, 0)
                     });	
             
             //Churn Recipe
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamChurn, 1), new Object[]
                     {
                         " X ", "# #", "# #", 'X', Item.stick, '#', Block.planks
                     });
             //Quern Recipe
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamQuern, 1), new Object[]
                     {
                         " X ", "# #", "# #", 'X', Item.stick, '#', Block.stone
                     });
             OreDictionary.registerOre("ingotZinc", Pamcombinedmod.zincingotItem);
         	OreDictionary.registerOre("ingotCopper", Pamcombinedmod.copperingotItem);
         	OreDictionary.registerOre("ingotTin", Pamcombinedmod.tiningotItem);
         	OreDictionary.registerOre("ingotBronze", Pamcombinedmod.bronzeingotItem);
         	OreDictionary.registerOre("ingotSilver", Pamcombinedmod.silveringotItem);
         	OreDictionary.registerOre("ingotRefinedIron", Pamcombinedmod.steelingotItem);
             
           //Alloy Recipes
 			CraftingManager.getInstance().getRecipeList().add(new ShapelessOreRecipe(new ItemStack(bronzeingotItem, 2, 0), "ingotCopper", "ingotTin"));
 			ModLoader.addShapelessRecipe(new ItemStack(steelingotItem, 1, 0), new Object[] 
 			{
 				new ItemStack(Item.coal, 1), new ItemStack(Item.coal, 1), new ItemStack(Item.coal, 1), new ItemStack(Item.coal, 1), new ItemStack(Item.coal, 1), new ItemStack(Item.coal, 1), new ItemStack(Item.coal, 1), new ItemStack(Item.coal, 1), new ItemStack(Item.ingotIron, 1)
 			});
 			

 			//Copper Tool & Armor Recipes
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperAxe, true, new Object[]{
 		 	 		"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotCopper"}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperPick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperAxe, true, new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperPick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperHelm, true, new Object[] {
 			"XXX", "X X", Character.valueOf('X'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperChest, true, new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperLegs, true, new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), "ingotCopper"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.copperBoots, true, new Object[] {
 			"X X", "X X", Character.valueOf('X'), "ingotCopper"
 			}));
 		
 			//Tin Tool & Armor Recipes
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinAxe, true, new Object[]{
 		 	 		"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotTin"}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinPick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinAxe, true, new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinPick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinHelm, true, new Object[] {
 			"XXX", "X X", Character.valueOf('X'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinChest, true, new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinLegs, true, new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), "ingotTin"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.tinBoots, true, new Object[] {
 			"X X", "X X", Character.valueOf('X'), "ingotTin"
 			}));

 			//Bronze Tool & Armor Recipes
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeAxe, true, new Object[]{
 		 	 		"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotBronze"}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzePick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeAxe, true, new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzePick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeHelm, true, new Object[] {
 			"XXX", "X X", Character.valueOf('X'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeChest, true, new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeLegs, true, new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), "ingotBronze"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.bronzeBoots, true, new Object[] {
 			"X X", "X X", Character.valueOf('X'), "ingotBronze"
 			}));

 			//Silver Tool & Armor Recipes
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverAxe, true, new Object[]{
 		 	 		"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotSilver"}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverPick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverAxe, true, new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverPick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverHelm, true, new Object[] {
 			"XXX", "X X", Character.valueOf('X'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverChest, true, new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverLegs, true, new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), "ingotSilver"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.silverBoots, true, new Object[] {
 			"X X", "X X", Character.valueOf('X'), "ingotSilver"
 			}));
 			
 			//Cobalt Tool & Armor Recipes
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltAxe, 1), new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltHoe, 1), new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltPick, 1), new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltShovel, 1), new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltSword, 1), new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltAxe, 1), new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltHoe, 1), new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltPick, 1), new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltShovel, 1), new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltSword, 1), new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltHelm, 1), new Object[] {
 			"XXX", "X X", Character.valueOf('X'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltChest, 1), new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltLegs, 1), new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.cobaltBoots, 1), new Object[] {
 			"X X", "X X", Character.valueOf('X'), cobaltingotItem
 			});
 			
 			//Steel Tool & Armor Recipes
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelAxe, true, new Object[]{
 		 	 		"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotRefinedIron"}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelPick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelAxe, true, new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelHoe, true, new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelPick, true, new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelShovel, true, new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelSword, true, new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelHelm, true, new Object[] {
 			"XXX", "X X", Character.valueOf('X'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelChest, true, new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelLegs, true, new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), "ingotRefinedIron"
 			}));
 			CraftingManager.getInstance().getRecipeList().add(new ShapedOreRecipe(Pamcombinedmod.steelBoots, true, new Object[] {
 			"X X", "X X", Character.valueOf('X'), "ingotRefinedIron"
 			}));
 			
 			//Platinum Tool & Armor Recipes
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumAxe, 1), new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumHoe, 1), new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumPick, 1), new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumShovel, 1), new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumSword, 1), new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumAxe, 1), new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumHoe, 1), new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumPick, 1), new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumShovel, 1), new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumSword, 1), new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumHelm, 1), new Object[] {
 			"XXX", "X X", Character.valueOf('X'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumChest, 1), new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumLegs, 1), new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), platinumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.platinumBoots, 1), new Object[] {
 			"X X", "X X", Character.valueOf('X'), platinumingotItem
 			});
 			
 			//Titanium Tool & Armor Recipes
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumAxe, 1), new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumHoe, 1), new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumPick, 1), new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumShovel, 1), new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumSword, 1), new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumAxe, 1), new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumHoe, 1), new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumPick, 1), new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumShovel, 1), new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumSword, 1), new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumHelm, 1), new Object[] {
 			"XXX", "X X", Character.valueOf('X'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumChest, 1), new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumLegs, 1), new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), titaniumingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.titaniumBoots, 1), new Object[] {
 			"X X", "X X", Character.valueOf('X'), titaniumingotItem
 			});
 			
 			//Mithril Tool & Armor Recipes
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilAxe, 1), new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilHoe, 1), new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilPick, 1), new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilShovel, 1), new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilSword, 1), new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.stick, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilAxe, 1), new Object[] {
 			"@@ ", "@X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilHoe, 1), new Object[] {
 			"@@ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilPick, 1), new Object[] {
 			"@@@", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilShovel, 1), new Object[] {
 			" @ ", " X ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilSword, 1), new Object[] {
 			" @ ", " @ ", " X ", Character.valueOf('X'), Item.bone, Character.valueOf('@'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilHelm, 1), new Object[] {
 			"XXX", "X X", Character.valueOf('X'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilChest, 1), new Object[] {
 			"X X", "XXX", "XXX", Character.valueOf('X'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilLegs, 1), new Object[] {
 			"XXX", "X X", "X X", Character.valueOf('X'), mithrilingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.mithrilBoots, 1), new Object[] {
 			"X X", "X X", Character.valueOf('X'), mithrilingotItem
 			});
 			
 			//Flint and Steel Recipes
 			ModLoader.addRecipe(new ItemStack(Item.flintAndSteel, 2), new Object[] {
 			"A ", " B", Character.valueOf('A'), cobaltingotItem, Character.valueOf('B'), Item.flint
 			});
 			ModLoader.addRecipe(new ItemStack(Item.flintAndSteel, 4), new Object[] {
 			"A ", " B", Character.valueOf('A'), steelingotItem, Character.valueOf('B'), Item.flint
 			});
 			ModLoader.addRecipe(new ItemStack(Item.flintAndSteel, 8), new Object[] {
 			"A ", " B", Character.valueOf('A'), titaniumingotItem, Character.valueOf('B'), Item.flint
 			});
 			
 			//Door Recipes
 			ModLoader.addRecipe(new ItemStack(Item.doorSteel, 2), new Object[] {
 			"##", "##", "##", Character.valueOf('#'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.doorSteel, 4), new Object[] {
 			"##", "##", "##", Character.valueOf('#'), steelingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.doorSteel, 8), new Object[] {
 			"##", "##", "##", Character.valueOf('#'), titaniumingotItem
 			});
 			
 			//Rail Recipes
 			ModLoader.addRecipe(new ItemStack(Block.rail, 4), new Object[] {
 			"X X", "X#X", "X X", Character.valueOf('X'), tiningotItem, Character.valueOf('#'), Item.stick
 			});
 			ModLoader.addRecipe(new ItemStack(Block.rail, 8), new Object[] {
 			"X X", "X#X", "X X", Character.valueOf('X'), bronzeingotItem, Character.valueOf('#'), Item.stick
 			});
 			ModLoader.addRecipe(new ItemStack(Block.rail, 32), new Object[] {
 			"X X", "X#X", "X X", Character.valueOf('X'), cobaltingotItem, Character.valueOf('#'), Item.stick
 			});
 			ModLoader.addRecipe(new ItemStack(Block.rail, 48), new Object[] {
 			"X X", "X#X", "X X", Character.valueOf('X'), steelingotItem, Character.valueOf('#'), Item.stick
 			});
 			ModLoader.addRecipe(new ItemStack(Block.rail, 64), new Object[] {
 			"X X", "X#X", "X X", Character.valueOf('X'), titaniumingotItem, Character.valueOf('#'), Item.stick
 			});
 			
 			//Powered Rail Recipes
 			ModLoader.addRecipe(new ItemStack(Block.railPowered, 1), new Object[] {
 			"X X", "X#X", "XRX", Character.valueOf('X'), copperingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('#'), Item.stick
 			});
 			ModLoader.addRecipe(new ItemStack(Block.railPowered, 3), new Object[] {
 			"X X", "X#X", "XRX", Character.valueOf('X'), silveringotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('#'), Item.stick
 			});
 			ModLoader.addRecipe(new ItemStack(Block.railPowered, 12), new Object[] {
 			"X X", "X#X", "XRX", Character.valueOf('X'), platinumingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('#'), Item.stick
 			});
 			
 			//Dector Rail Recipes
 			ModLoader.addRecipe(new ItemStack(Block.railDetector, 1), new Object[] {
 			"X X", "X#X", "XRX", Character.valueOf('X'), tiningotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('#'), Block.pressurePlateStone
 			});
 			ModLoader.addRecipe(new ItemStack(Block.railDetector, 3), new Object[] {
 			"X X", "X#X", "XRX", Character.valueOf('X'), bronzeingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('#'), Block.pressurePlateStone
 			});
 			ModLoader.addRecipe(new ItemStack(Block.railDetector, 12), new Object[] {
 			"X X", "X#X", "XRX", Character.valueOf('X'), cobaltingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('#'), Block.pressurePlateStone
 			});
 			ModLoader.addRecipe(new ItemStack(Block.railDetector, 24), new Object[] {
 			"X X", "X#X", "XRX", Character.valueOf('X'), steelingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('#'), Block.pressurePlateStone
 			});
 			ModLoader.addRecipe(new ItemStack(Block.railDetector, 48), new Object[] {
 			"X X", "X#X", "XRX", Character.valueOf('X'), titaniumingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('#'), Block.pressurePlateStone
 			});
 			
 			//Minecraft Recipes
 			ModLoader.addRecipe(new ItemStack(Item.minecartEmpty, 1), new Object[] {
 				"# #", "###", Character.valueOf('#'), tiningotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.minecartEmpty, 1), new Object[] {
 				"# #", "###", Character.valueOf('#'), bronzeingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.minecartEmpty, 2), new Object[] {
 				"# #", "###", Character.valueOf('#'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.minecartEmpty, 4), new Object[] {
 				"# #", "###", Character.valueOf('#'), steelingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.minecartEmpty, 8), new Object[] {
 				"# #", "###", Character.valueOf('#'), titaniumingotItem
 			});
 			
 			//Bucket Recipes
 			ModLoader.addRecipe(new ItemStack(Item.bucketEmpty, 1), new Object[] {
 			"# #", " # ", Character.valueOf('#'), tiningotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.bucketEmpty, 1), new Object[] {
 			"# #", " # ", Character.valueOf('#'), bronzeingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.bucketEmpty, 2), new Object[] {
 			"# #", " # ", Character.valueOf('#'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.bucketEmpty, 4), new Object[] {
 			"# #", " # ", Character.valueOf('#'), steelingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.bucketEmpty, 8), new Object[] {
 			"# #", " # ", Character.valueOf('#'), titaniumingotItem
 			});
 			
 			//Piston Recipes
 			ModLoader.addRecipe(new ItemStack(Block.pistonBase, 1), new Object[] {
 			"TTT", "#X#", "#R#", Character.valueOf('#'), Block.cobblestone, Character.valueOf('X'), cobaltingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('T'), 
 			Block.planks
 			});
 			ModLoader.addRecipe(new ItemStack(Block.pistonBase, 1), new Object[] {
 			"TTT", "#X#", "#R#", Character.valueOf('#'), Block.cobblestone, Character.valueOf('X'), steelingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('T'), 
 			Block.planks
 			});
 			ModLoader.addRecipe(new ItemStack(Block.pistonBase, 1), new Object[] {
 			"TTT", "#X#", "#R#", Character.valueOf('#'), Block.cobblestone, Character.valueOf('X'), titaniumingotItem, Character.valueOf('R'), Item.redstone, Character.valueOf('T'), 
 			Block.planks
 			});
 			
 			//Sundial Recipes
 			ModLoader.addRecipe(new ItemStack(Item.pocketSundial, 1), new Object[] {
 			" # ", "#X#", " # ", Character.valueOf('#'), platinumingotItem, Character.valueOf('X'), Item.redstone
 			});
 			
 			//Compass Recipes
 			ModLoader.addRecipe(new ItemStack(Item.compass, 1), new Object[] {
 			" # ", "#X#", " # ", Character.valueOf('#'), cobaltingotItem, Character.valueOf('X'), Item.redstone
 			});
 			ModLoader.addRecipe(new ItemStack(Item.compass, 1), new Object[] {
 			" # ", "#X#", " # ", Character.valueOf('#'), steelingotItem, Character.valueOf('X'), Item.redstone
 			});
 			
 			//Shears Recipes
 			ModLoader.addRecipe(new ItemStack(Item.shears), new Object[] {
 			" #", "# ", Character.valueOf('#'), tiningotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.shears), new Object[] {
 			" #", "# ", Character.valueOf('#'), bronzeingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.shears), new Object[] {
 			" #", "# ", Character.valueOf('#'), cobaltingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.shears), new Object[] {
 			" #", "# ", Character.valueOf('#'), steelingotItem
 			});
 			ModLoader.addRecipe(new ItemStack(Item.shears), new Object[] {
 			" #", "# ", Character.valueOf('#'), titaniumingotItem
 			});
 			
 			
        
        
}
     public void load4()
     {
    	//Colored Wood Block Recipes
			for (int i = 0; i < 16; i++)
         {
             //Dyed Plank
             //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 1), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 2), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 3), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 4), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 5), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 6), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 7), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 8), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 9), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 10), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 11), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 12), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 13), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 14), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredPlank, 4, 15), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.planks.blockID], 1, 0)
                     });
             //Dyed Wood Fence
           //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 1), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 2), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 3), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 4), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 5), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 6), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 7), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 8), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 9), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 10), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 11), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 12), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 13), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 14), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodFence, 4, 15), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fence.blockID], 1, 0)
                     });
             //Dyed Wood Stairs
             //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsWhite, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsOrange, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsMagenta, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsLightblue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsYellow, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsLime, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsPink, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsDarkgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsLightgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsCyan, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsPurple, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsBlue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsBrown, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsGreen, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsRed, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodstairsBlack, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
           //Dyed Wood Slabs
             //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabWhite, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabOrange, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabMagenta, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabLightblue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabYellow, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabLime, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabPink, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabDarkgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabLightgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabCyan, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabPurple, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabBlue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabBrown, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabGreen, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabRed, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodslabBlack, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0), new ItemStack(Item.itemsList[Block.woodSingleSlab.blockID], 1, 0)
                     });
             //Dyed Wood Paver
           //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 1), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 2), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 3), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 4), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 5), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 6), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 7), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 8), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 9), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 10), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 11), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 12), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 13), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 14), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodThin, 4, 15), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlatePlanks.blockID], 1, 0)
                     });
           //Dyed Wood Fence Gate
             //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateWhite, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateOrange, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateMagenta, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateLightblue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateYellow, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateLime, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegatePink, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateDarkgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateLightgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateCyan, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegatePurple, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateBlue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateBrown, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateGreen, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateRed, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredwoodfencegateBlack, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0), new ItemStack(Item.itemsList[Block.fenceGate.blockID], 1, 0)
                     });
             
           //Dyed Cobblestone
             //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 1), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 2), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 3), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 4), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 5), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 6), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 7), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 8), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 9), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 10), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 11), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 12), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 13), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 14), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 4, 15), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.cobblestone.blockID], 1, 0)
                     });
             
             //Dyed Cobblestone Stairs
             //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsWhite, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactPlanks.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsOrange, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsMagenta, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsLightblue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsYellow, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsLime, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsPink, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsDarkgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsLightgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsCyan, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsPurple, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsBlue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsBrown, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsGreen, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsRed, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestonestairsBlack, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.stairCompactCobblestone.blockID], 1, 0)
                     });
           //Dyed Cobblestone Slabs
             //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabWhite, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabOrange, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabMagenta, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabLightblue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabYellow, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabLime, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabPink, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabDarkgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabLightgrey, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabCyan, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabPurple, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabBlue, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabBrown, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabGreen, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabRed, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneslabBlack, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3), new ItemStack(Item.itemsList[Block.stoneSingleSlab.blockID], 1, 3)
                     });
             //Dyed Cobblestone Paver
           //White
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 0), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Orange
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 1), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Magenta
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 2), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Light Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 3), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Yellow
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 4), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Lime
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 5), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Pink
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 6), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Dark Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 7), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Light Grey
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 8), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Cyan
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 9), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Purple
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 10), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Blue
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 11), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Brown
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 12), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Green
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 13), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Red
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 14), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             //Black
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredcobblestoneThin, 4, 15), new Object[]
                     {
                         new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0), new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                     });
             
           //Colored Smoothstone to Colored Smoothstone
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 1, i), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamcoloredSmoothstone, 1, i)
                     });
             //Colored Cobblestone to Colored Smoothstone
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSmoothstone, 1, i), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamcoloredCobblestone, 1, i)
                     });
             
             //Colored Cloth Stairs
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsWhite, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 0)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsOrange, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 1)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsMagenta, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 2)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsLightblue, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 3)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsYellow, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 4)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsLime, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 5)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsPink, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 6)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsDarkgrey, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 7)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsLightgrey, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 8)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsCyan, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 9)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsPurple, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 10)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsBlue, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 11)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsBrown, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 12)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsGreen, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 13)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsRed, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 14)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothstairsBlack, 1, 0), new Object[]
                     {
                         "  X", " XX", "XXX", 'X', new ItemStack(Block.cloth, 1, 15)
                     });
             //Colored Cloth Slabs
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabWhite, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 0)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabOrange, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 1)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabMagenta, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 2)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabLightblue, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 3)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabYellow, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 4)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabLime, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 5)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabPink, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 6)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabDarkgrey, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 7)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabLightgrey, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 8)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabCyan, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 9)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabPurple, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 10)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabBlue, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 11)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabBrown, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 12)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabGreen, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 13)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabRed, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 14)
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothslabBlack, 6, 0), new Object[]
                     {
                         "XXX", 'X', new ItemStack(Block.cloth, 1, 15)
                     });
             //Colored Cloth Carpets
             ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredclothThin, 4, i), new Object[]
                     {
            	 		new ItemStack(Block.cloth, 1, i)
                     });
             
             //Metal Blocks
             	ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 0), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', zincingotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(zincingotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 0)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 1), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', tiningotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(tiningotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 1)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 2), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', copperingotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(copperingotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 2)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 3), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', silveringotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(silveringotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 3)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 4), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', cobaltingotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(cobaltingotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 4)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 5), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', platinumingotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(platinumingotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 5)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 6), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', titaniumingotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(titaniumingotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 6)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 7), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', mithrilingotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(mithrilingotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 7)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 8), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', bronzeingotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(bronzeingotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 8)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 9), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', steelingotItem
		                });
				ModLoader.addShapelessRecipe(new ItemStack(steelingotItem, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 9)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 10), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', Item.redstone
		                });
				ModLoader.addShapelessRecipe(new ItemStack(Item.redstone, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 10)
		                });
				ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pammetalBlock, 1, 11), new Object[]
		                {
		                    "XXX", "XXX", "XXX", 'X', Item.coal
		                });
				ModLoader.addShapelessRecipe(new ItemStack(Item.coal, 9, 0), new Object[]
		                {
		                    new ItemStack(Pamcombinedmod.pammetalBlock, 1, 11)
		                });
           
     		//Gem Blocks Recipe
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 15/*Black*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedonyxgemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 14/*Red*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedrubygemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 13/*Green*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedemeraldgemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 12/*Brown*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedtigerseyegemItem
                     });
             //ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 11), new Object[]
             //        {
             ///           new ItemStack(Block.blockLapis, 1, 0)
             //        });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 10/*Purple*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedamethystgemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 9/*Cyan*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedaquamarinegemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 8/*Light Grey*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedmoonstonegemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 7/*Dark Grey*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedhematitegemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 6/*Pink*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedgarnetgemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 5/*Lime*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedagategemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 4/*Yellow*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedtopazgemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 3/*Light Blue*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedsapphiregemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 2/*Magenta*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedtanzanitegemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 1/*Orange*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedcitrinegemItem
                     });
             ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamgemBlock, 1, 0/*White*/), new Object[]
                     {
                         "XXX", "XXX", "XXX", 'X', flawedquartzgemItem
                     });
             
           //Gem Blocks to Gems Recipe
             ModLoader.addShapelessRecipe(new ItemStack(flawedonyxgemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 15)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedrubygemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 14)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedemeraldgemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 13)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedtigerseyegemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 12)
                     });
            // ModLoader.addShapelessRecipe(new ItemStack(Item.dyePowder, 9, 4), new Object[]
            //         {
            //             new ItemStack(Pamcombinedmod.pamgemBlock, 1, 11)
            //         });
             ModLoader.addShapelessRecipe(new ItemStack(flawedamethystgemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 10)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedaquamarinegemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 9)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedmoonstonegemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 8)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedhematitegemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 7)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedgarnetgemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 6)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedagategemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 5)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedtopazgemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 4)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedsapphiregemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 3)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedtanzanitegemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 2)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedcitrinegemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 1)
                     });
             ModLoader.addShapelessRecipe(new ItemStack(flawedquartzgemItem, 9, 0), new Object[]
                     {
                         new ItemStack(Pamcombinedmod.pamgemBlock, 1, 0)
                     });
             
           //Dyed Clay
             //White
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 0), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Orange
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 1), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Magenta
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 2), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Light Blue
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 3), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Yellow
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 4), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Lime
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 5), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Pink
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 6), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Dark Grey
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 7), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Light Grey
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 8), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Cyan
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 9), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Purple
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 10), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Blue
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 11), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Brown
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 12), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Green
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 13), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Red
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 14), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               //Black
               ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredClay, 4, 15), new Object[]
                       {
                           new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0), new ItemStack(Item.itemsList[Block.blockClay.blockID], 1, 0)
                       });
               
             //Dyed Sand
               //White
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 0), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Orange
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 1), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Magenta
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 2), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Light Blue
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 3), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Yellow
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 4), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Lime
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 5), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Pink
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 6), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Dark Grey
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 7), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Light Grey
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 8), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Cyan
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 9), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Purple
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 10), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Blue
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 11), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Brown
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 12), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Green
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 13), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Red
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 14), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 //Black
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredSand, 4, 15), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0), new ItemStack(Item.itemsList[Block.sand.blockID], 1, 0)
                         });
                 
     			//Dyed Bookshelves
                 //White
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 0), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Orange
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 1), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Magenta
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 2), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Light Blue
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 3), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Yellow
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 4), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Lime
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 5), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Pink
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 6), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Dark Grey
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 7), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Light Grey
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 8), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Cyan
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 9), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Purple
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 10), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Blue
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 11), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Brown
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 12), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Green
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 13), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Red
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 14), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   //Black
                   ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredBookshelf, 4, 15), new Object[]
                           {
                               new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0), new ItemStack(Item.itemsList[Block.bookShelf.blockID], 1, 0)
                           });
                   
       			//Dyed Leaves
                   //White
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 0), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Orange
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 1), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Magenta
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 2), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Light Blue
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 3), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Yellow
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 4), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Lime
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 5), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Pink
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 6), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Dark Grey
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 7), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Light Grey
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 8), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Cyan
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 9), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Purple
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 10), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Blue
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 11), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Brown
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 12), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Green
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 13), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Red
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 14), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     //Black
                     ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredLeaves, 4, 15), new Object[]
                             {
                                 new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0), new ItemStack(Item.itemsList[Block.leaves.blockID], 1, 0)
                             });
                     
                   //Dyed Wood
                     //White
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 0), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Orange
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 1), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Magenta
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 2), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Light Blue
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 3), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Yellow
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 4), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Lime
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 5), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Pink
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 6), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Dark Grey
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 7), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Light Grey
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 8), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Cyan
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 9), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Purple
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 10), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Blue
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 11), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Brown
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 12), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Green
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 13), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Red
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 14), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
                       //Black
                       ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredWood, 4, 15), new Object[]
                               {
                                   new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0), new ItemStack(Item.itemsList[Block.wood.blockID], 1, 0)
                               });
               
             //Dyed Glass
               //White
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 0), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Orange
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 1), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 14), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Magenta
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 2), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 13), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Light Blue
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 3), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Yellow
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 4), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 11), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Lime
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 5), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 10), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Pink
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 6), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 9), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Dark Grey
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 7), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Light Grey
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 8), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Cyan
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 9), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 6), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Purple
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 10), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Blue
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 11), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Brown
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 12), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 3), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Green
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 13), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Red
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 14), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 //Black
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamcoloredGlass, 4, 15), new Object[]
                         {
                             new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0), new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 
                 //Stone Paver Recipes
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 0), new Object[]
                         {
                             new ItemStack(Item.itemsList[Block.pressurePlateStone.blockID], 1, 0)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 1), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 0)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 2), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 1)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 3), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 2)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 4), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 3)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 5), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 4)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 6), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 5)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 7), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 6)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 8), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 7)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 9), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 8)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 10), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 9)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 11), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 10)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 12), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 11)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 13), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 12)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 14), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 13)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamstonePaver, 1, 15), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 14)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Block.pressurePlateStone, 1, 0), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamstonePaver.blockID], 1, 15)
                         });
                 
               //Window Recipes
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 0), new Object[]
                         {
                             new ItemStack(Item.itemsList[Block.glass.blockID], 1, 0)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 1), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 0)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 2), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 1)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 3), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 2)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 4), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 3)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 5), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 4)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 6), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 5)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 7), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 6)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 8), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 7)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 9), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 8)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 10), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 9)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 11), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 10)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 12), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 11)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 13), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 12)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 14), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 13)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Pamcombinedmod.pamWindow, 1, 15), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 14)
                         });
                 ModLoader.addShapelessRecipe(new ItemStack(Block.glass, 1, 0), new Object[]
                         {
                             new ItemStack(Item.itemsList[Pamcombinedmod.pamWindow.blockID], 1, 15)
                         });
         }
			
			ModLoader.addRecipe(new ItemStack(Pamcombinedmod.pamcropboxOne, 1, 0/*Vanilla Wheat*/), new Object[]
                    {
                        "XXX", "XXX", "XXX", 'X', Item.wheat
                    });
			ModLoader.addShapelessRecipe(new ItemStack(Item.wheat, 9, 0), new Object[]
                    {
                        new ItemStack(Item.itemsList[Pamcombinedmod.pamcropboxOne.blockID], 1, 0)
                    });

          GameRegistry.addSmelting(cactusstickItem.shiftedIndex, new ItemStack(Item.stick), 0.1F);
          GameRegistry.addSmelting(Block.sandStone.blockID, new ItemStack(Block.glass, 4), 0.1F);
          
          GameRegistry.addSmelting(doughItem.shiftedIndex, new ItemStack(Item.bread), 0.1F);
          GameRegistry.addSmelting(potatoItem.shiftedIndex, new ItemStack(bakedpotatoItem), 0.1F);
          GameRegistry.addSmelting(Item.bread.shiftedIndex, new ItemStack(toastItem), 0.1F);
          GameRegistry.addSmelting(cornmealdoughItem.shiftedIndex, new ItemStack(tortillaItem), 0.1F);
          GameRegistry.addSmelting(cornItem.shiftedIndex, new ItemStack(popcornItem), 0.1F);
          GameRegistry.addSmelting(grapeItem.shiftedIndex, new ItemStack(raisinsItem), 0.1F);
          GameRegistry.addSmelting(cornmuffinmixItem.shiftedIndex, new ItemStack(cornbreadmuffinsItem), 0.1F);
          GameRegistry.addSmelting(Item.appleRed.shiftedIndex, new ItemStack(driedappleslicesItem), 0.1F);
          GameRegistry.addSmelting(strawberryItem.shiftedIndex, new ItemStack(driedstrawberriesItem), 0.1F);
          GameRegistry.addSmelting(Item.egg.shiftedIndex, new ItemStack(scrambledeggsItem), 0.1F);
          GameRegistry.addSmelting(riceItem.shiftedIndex, new ItemStack(ricecakeItem), 0.1F);
          GameRegistry.addSmelting(coconutItem.shiftedIndex, new ItemStack(toastedcoconutItem), 0.1F);
          GameRegistry.addSmelting(eggplantItem.shiftedIndex, new ItemStack(grilledeggplantItem), 0.1F);
          GameRegistry.addSmelting(tealeafItem.shiftedIndex, new ItemStack(teaItem), 0.1F);
          GameRegistry.addSmelting(groundcoffeeItem.shiftedIndex, new ItemStack(coffeeItem), 0.1F);
          GameRegistry.addSmelting(sweetpotatoItem.shiftedIndex, new ItemStack(grilledsweetpotatoItem), 0.1F);
          GameRegistry.addSmelting(vanillabeanItem.shiftedIndex, new ItemStack(vanillaItem), 0.1F);
          GameRegistry.addSmelting(Item.rottenFlesh.shiftedIndex, new ItemStack(Item.leather), 0.1F);
          
          GameRegistry.addSmelting(zincoreItem.shiftedIndex, new ItemStack(zincingotItem), 0.2F);
          GameRegistry.addSmelting(tinoreItem.shiftedIndex, new ItemStack(tiningotItem), 0.2F);
			GameRegistry.addSmelting(copperoreItem.shiftedIndex, new ItemStack(copperingotItem), 0.5F);
			GameRegistry.addSmelting(silveroreItem.shiftedIndex, new ItemStack(silveringotItem), 0.5F);
			GameRegistry.addSmelting(cobaltoreItem.shiftedIndex, new ItemStack(cobaltingotItem), 0.2F);
			GameRegistry.addSmelting(platinumoreItem.shiftedIndex, new ItemStack(platinumingotItem), 0.8F);
			GameRegistry.addSmelting(titaniumoreItem.shiftedIndex, new ItemStack(titaniumingotItem), 0.2F);
			GameRegistry.addSmelting(mithriloreItem.shiftedIndex, new ItemStack(mithrilingotItem), 1.0F);
			GameRegistry.addSmelting(bronzealloyItem.shiftedIndex, new ItemStack(bronzeingotItem), 0.2F);
			GameRegistry.addSmelting(steelalloyItem.shiftedIndex, new ItemStack(steelingotItem), 0.2F);
			
			
  
     
     
     GameRegistry.registerWorldGenerator(new PamCombinedGenerator());
     NetworkRegistry.instance().registerGuiHandler(this, this); // ADDED
     }
     
  // ADDED
     @Override
     public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
         if (ID == churnGUI)
             return new ContainerPamChurn(player.inventory, (TileEntityPamChurn)world.getBlockTileEntity(x,y,z));
         if (ID == quernGUI)
             return new ContainerPamQuern(player.inventory, (TileEntityPamQuern)world.getBlockTileEntity(x,y,z));
         return null;
     }

     // ADDED
     @Override
     public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
         if (ID == churnGUI)
             return new GuiPamChurn(player.inventory, (TileEntityPamChurn)world.getBlockTileEntity(x,y,z));
         if (ID == quernGUI)
             return new GuiPamQuern(player.inventory, (TileEntityPamQuern)world.getBlockTileEntity(x,y,z));
         return null;
     }


	
        
}



